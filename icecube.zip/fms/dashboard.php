<?php
include('meta_script_link.php');
include('site_meta_script_link.php');
?>
<head>
 <div class="main-container">
 	<?php 
	include('includes/header.php'); ?>
    <div class="bread-crums_wrap">
    <div class="bread-crums"><a href="#">Home</a> &raquo; Dashboard</div>
</div>
  <div class="msg_wrap">
	 <?php
	if($_REQUEST['result'] == 'success') {?>
    <div class="msg_success"> Password changed Successfully. </div>
    <?php } ?>
	</div>

        <div class="dashlet-panel-full">
        

<?php include('includes/footer.php'); ?>  
</div>