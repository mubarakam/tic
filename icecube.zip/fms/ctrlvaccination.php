<?php
include('meta_script_link.php');
include("classes/fmsClass.php");
?><head>
<input type="hidden" id="curryear" name="curryear" value="<?php echo date("y"); ?>" />
<input type="hidden" id="currmon" name="currmon" value="<?php echo date("m"); ?>" />
<input type="hidden" id="currday" name="currday" value="<?php echo date("d"); ?>" />
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script type="text/javascript">
function getCategory(a)
{
	$.ajax({
	type: "post",
	url: "ajaxvalidate.php?frm=getCategory&ct="+a.value,
	success: function(data){
		document.getElementById("category").innerHTML = data;
	}
});
}

function setvalue()
{
	if($("#active").is(':checked'))
	{
		$("#activeflag").val("1");
	}
	else
	{
		$("#activeflag").val("0");
	}
}

$(document).ready(function() {
		var curYear = document.getElementById("curryear").value;
		var curMon = document.getElementById("currmon").value;
		var curDay = document.getElementById("currday").value;
		var mindat = curDay + "-" + curMon + "-" + curYear;
		
		$("#ecode").focus();

	$('#vaccination').bind('keyup paste', function(){
		this.value = this.value.replace(/[^a-zA-Z ]/g, '');
		});
		
	var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	
	$(".kpress").keypress(function (e)
	{
		e.preventDefault();
	});
	$("input[aria-controls=example]").focus();
	
	jQuery(function(){
                jQuery('#dob').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
					changeYear: true,
					yearRange:"-100:+0"
				});
            })
	jQuery(function(){
                jQuery('#doj').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
					changeYear: true,
					minDate:mindat
                });
            })
		});
function clearField(a)
{
	$('#'+a).each (function(){
		this.reset();
	}); 
}

function validate(a){var cat = $("#category").val();var val = $("#"+a).val();$.ajax({type: "post",url: "ajaxvalidate.php?cat="+cat+"&frm="+a+"&val="+val,success: function(data){if(data == "exist"){$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});document.getElementById('errdiv').style.display='inline';$("#addbtn").attr('disabled','true')}else if(data != "exist"){$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});document.getElementById('errdiv').style.display='none';$("#addbtn").removeAttr('disabled');}}});}
</script>
<div class="main-container">
<?php include('includes/header.php');
?>
<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="">Master</a>&nbsp;&raquo;&nbsp;Vaccination</div>
<div class="backlink"><a href="vwvaccination.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
<?php

$vacDetQry = "SELECT ct.ID CategoryTypeID, c.ID CategoryID, c.Name Category, v.ID, v.Name Vaccination, v.IsActive, v.Period, v.UnitID FROM ".DB."mstrvaccination v INNER JOIN ".DB."mstrcategory c ON c.ID = v.CategoryID INNER JOIN ".DB."mstrcategorytype ct ON ct.ID = c.CategoryTypeID LEFT OUTER JOIN ".DB."mstrunit u ON u.ID = v.UnitID WHERE v.ID = ".$_REQUEST['eid'];

$catTypeDetQry = mysql_query("SELECT ID CategoryTypeID, Name CategoryType, IsActive FROM ".DB."mstrcategorytype ORDER BY Name ASC");
$unitDetQry = mysql_query("SELECT ID UnitID, Name UnitName FROM ".DB."mstrunit ORDER BY Name ASC");

if($_REQUEST['mode'] == 'add')
{
?>
<form name="categoryform" action="" method="post" id="categoryform" >
<input type="hidden" id="mode" name="mode" value="add" />
<table width="100%" border="0" id="workflowtable">
<tr>
<td width="14%">Category Type<span class="validationerrornotify">&nbsp;*</span></td>
<td>
<select id="categorytype" name="categorytype" required onchange="getCategory(this)">
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($catTypeDetQry))
{
?>
	<option value="<?php echo $rs['CategoryTypeID']; ?>" <?php if($rs['CategoryTypeID'] == $_REQUEST['categorytype']){?> selected <?php }?> ><?php echo $rs['CategoryType']; ?></option>
<?php
}
?>
</select>
</td>
</tr>

<tr>
<td width="14%">Category<span class="validationerrornotify">&nbsp;*</span></td>
<td>
<select id="category" name="category" required >
<option value="">--Select--</option>
</select>
</td>
</tr>
<tr>
<td width="14%">Vaccination<span class="validationerrornotify">&nbsp;*</span></td>
<td><input type="text" name="vaccination" id="vaccination" required onChange="validate('vaccination');" value="<?php echo $_REQUEST['vaccination'];?>" />
<div id="errdiv" class="msg_exists" style="display:none;">&nbsp;vaccination already exists &nbsp;</div></td>
</tr>
<tr>
<td width="14%">Period<span class="validationerrornotify">&nbsp;*</span></td>
<td><input type="number" name="period" id="period" required value="<?php echo $_REQUEST['period'];?>" />
<select id="unit" name="unit" required >
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($unitDetQry))
{
?>
	<option value="<?php echo $rs['UnitID']; ?>" <?php if($rs['UnitID'] == $_REQUEST['unit']){?> selected <?php }?> ><?php echo $rs['UnitName']; ?></option>
<?php
}
?>
</select>
</td>
</tr>
<tr>
<td colspan="2" style="text-align:center;">
<input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />&nbsp;<input name="Cancel" type="button" onclick="clearField('categoryform')" value="Cancel"/>
</td>
</tr>
</table>
</form>
<?php
}


if($_REQUEST['mode'] == 'edit')
{
	$catRS = mysql_fetch_array(mysql_query($vacDetQry));
	//print_r($empRS);
?>
<form name="categoryform" action="" method="post" id="categoryform" >
<input type="hidden" id="mode" name="mode" value="edit" />
<input type="hidden" id="activeflag" name="activeflag" value="<?php echo $catRS['IsActive'];?>" />
<table width="100%" border="0" id="workflowtable">
<tr>
<td width="14%">Category Type<span class="validationerrornotify">&nbsp;*</span></td>
<td>
<select id="categorytype" name="categorytype" required onchange="getCategory(this)">
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($catTypeDetQry))
{
?>
	<option value="<?php echo $rs['CategoryTypeID']; ?>" <?php if($rs['CategoryTypeID'] == $catRS['CategoryTypeID']){?> selected <?php }?> ><?php echo $rs['CategoryType']; ?></option>
<?php
}
?>
</select>
</td>
</tr>

<tr>
<td width="14%">Category<span class="validationerrornotify">&nbsp;*</span></td>
<td>
<select id="category" name="category" required >
<option value="<?php echo $catRS['CategoryID']; ?>"><?php echo $catRS['Category']; ?></option>
</select>
</td>
</tr>

<tr>
<td width="14%">Vaccination<span class="validationerrornotify">&nbsp;*</span></td>
<td><input type="text" name="vaccination" id="vaccination" required onChange="validate('vaccination');" value="<?php echo $catRS['Vaccination'];?>" />
<div id="errdiv" class="msg_exists" style="display:none;">&nbsp;vaccination already exists &nbsp;</div></td>
</tr>
<tr>
<td width="14%">Period<span class="validationerrornotify">&nbsp;*</span></td>
<td><input type="number" name="period" id="period" required value="<?php echo $catRS['Period'];?>" />
<select id="unit" name="unit" required >
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($unitDetQry))
{
?>
	<option value="<?php echo $rs['UnitID']; ?>" <?php if($rs['UnitID'] == $catRS['UnitID']){?> selected <?php }?> ><?php echo $rs['UnitName']; ?></option>
<?php
}
?>
</select>
</td>
</tr>
<tr>
<td>Active</td>
<td><input type="checkbox" id="active" name="active" <?php if($catRS['IsActive'] == 1){ ?> checked <?php } ?> onclick="setvalue()" /></td>
</tr>
<tr>
<td colspan="2" style="text-align:center;">
<input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />&nbsp;<input name="Cancel" type="button" onclick="clearField('categoryform')" value="Cancel"/>
</td>
</tr>
</table>
</form>
<?php
}


?>	
</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>
<?php
echo "<pre>";
//print_r($_REQUEST);
//exit;

$cid = $_REQUEST['eid'];
$categorytype = $_REQUEST['category'];
$vaccination = $_REQUEST['vaccination'];
$activeflag = $_REQUEST['activeflag'];
$userid = $_SESSION['UserID'];
$period = $_REQUEST['period'];
$unit = $_REQUEST['unit'];
$vac = new fmsClass();

if($_REQUEST['mode'] == 'add' && $_REQUEST['addbtn'] == 'Submit')
{
	$vac->addVaccination($categorytype, $vaccination, $userid, $period, $unit);
}
if($_REQUEST['mode'] == 'edit' && $_REQUEST['addbtn'] == 'Submit')
{
	$vac->updateVaccination($cid, $categorytype, $vaccination, $userid, $activeflag, $period, $unit);
}
if($_REQUEST['mode'] == 'del')
{
	$vac->deleteVaccination($cid, $userid);
}
?>