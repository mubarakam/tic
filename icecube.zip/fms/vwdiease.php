<?php
include('meta_script_link.php');
?>
<script type="text/javascript">
jQuery(document).ready(function(){
	
	$('#example').dataTable().fnDestroy();
	
	$('#example').dataTable({
			"bJQueryUI" : true, 
			"bFilter": true,
			"aaSorting": [],
			"bPaginate": true,
			//"sScrollX": "100%",
			//"sScrollXInner": "100%",
			//"sScrollY": "400px",
			//"sScrollYInner": "100%",
			//"bScrollCollapse": true,
            });
});
</script>
<div class="main-container">
	<?php include('includes/header.php');?>
<!-- Bread-Crumb Starts -->
<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="#">Master</a>&nbsp;&raquo;&nbsp;Disease</div>
	<div class="msg_wrap">
    <?php 
   if($_REQUEST['v'] == 's')
        {?>
        <div class="msg_success">
           Data Created Successfully !!! Password - Fms@321)
        </div>
	<?php }	
        if($_REQUEST['v'] == '0')
        {
		?>
		<div class="msg_success">
           Data Updated Successfully !!
        </div>
		<?php
		//header("location: vwEmployee.php");
       	}
		?>
        </div>
    <div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>

<div class="clear"></div>
<!-- Bread-Crumb Ends -->
        <div class="dashlet-panel-full">

                <div class="backlink">            
                    <a href="ctrldiease.php?mode=add"><img src="images/new.png" title="Add Disease" border="0" />&nbsp;New Disease</a>
                </div> 
        <div class="clear"></div>
   			<div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; left: 0px; top: 0px;">				
					<div class="ui-widget-header ui-corner-top">
						<h2 class="arial12-nrml-medium-dark-gry">Disease</h2>						
					</div>	
						 <!--<form name="listUser" action="" method="post" >	-->						
							<table cellspacing="0" cellpadding="0" border="0" width="100%" class="display" id="example">
								<thead>
									<tr>
										<th>Disease</th>
                                        <th>Reason</th>
										<th>Treatment</th>
										<th>Active</th>
										<th>Action</th>															
									</tr>
								</thead>                                                    
								<tbody>
								<?php
								$dieaseList = mysql_query("SELECT d.ID, d.Name, d.Reason, d.Treatment, IF(d.IsActive = 1, 'Yes', 'No') Active FROM ".DB."mstrdiease d ORDER BY d.IsActive DESC, d.Name ASC");
								while($rs = mysql_fetch_array($dieaseList)){
									?>
									<tr>
										<td align="center" width="10%"><?php echo $rs['Name']; ?></td>
                                        <td width="20%"><?php echo $rs['Reason']; ?></td>
                                        <td width="20%"><?php echo $rs['Treatment']; ?></td>
										<td align="center" width="10%"><?php echo $rs['Active']; ?></td>
										<td style="font-weight:bold" align="center" width="10%">
										<a href="ctrldiease.php?mode=edit&eid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a> &nbsp; 
										<a onclick="javascript:if(confirm('Are you sure you want to delete?')){return true;}return false;" href="ctrldiease.php?mode=del&eid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/del.png" title="Delete" border="0" /> </a>
										</td>															
									</tr>									
								<?php $i++; } ?>								
								</tbody>
							</table>
												
			</div>
   </div>
   
   <!-- Dashlet-Panel Ends -->	
   <?php include('footer.php'); ?> 
</div>