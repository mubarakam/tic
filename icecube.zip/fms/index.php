<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> :: CRESCENT apps :: </title>
<!--<link rel="short icon" href="images/favicon.ico"/>-->
<link rel="stylesheet" type="text/css" href="css/xpub.css" />
<script type="text/javascript" src="js/jquery-Library-Latest 1.6.2.js"></script>
<script type="text/javascript" src="js/validator.js"></script>

</head>

<body class="blue-bg" OnLoad="document.login.username.focus();">
<div class="login-header">
	<!--<img src="images/enduralogo.png" alt="" border="0" style="margin-top:5px;height:80px;"/>-->
</div>
<div class="clear"></div>
<div class="login-bg">
	
	<form action="loginValidation.php" method="post" onsubmit="return validate('username', 'password')" name="login">	
	<div class="form-trans-outer-bg">
		<div class="xpub-form">
			
			<div class="xpub-title-bg">Login</div>
			
			<?php  extract($_GET); if($result == 'logout'){ ?>
				<div class="InfoMsg">You have Logged out Successfully.</div> <? } ?>
                
                <?php if($_REQUEST['result'] == 'ssofail'){ ?>
				<div class="errorMsg">Please use valid SSO login credentials</div> <? } ?>
                
                 <?php if($_REQUEST['result'] == 'nouserssofail'){ ?>
				<div class="errorMsg">There is no user in SSO. Please contact support</div> <? } ?>
                <?php if($_REQUEST['result'] == 'mgnfail'){ ?>
				<div class="errorMsg">Username is not available. Please contact admin</div> <? } ?>
                
                 <?php if($_REQUEST['result'] == 'noempidfail'){ ?>
				<div class="errorMsg">Employee ID is not available. Please contact admin</div> <? } ?>
                
                
			<?php if($result == 'fail'){ ?>
				<div class="errorMsg">Sorry, Wrong Username(OR)Password.</div>	 <? } ?>		
			<?php if($result == 'success'){ ?>
				<div class="InfoMsg">Account Created , LogIn!!!</div>
			<?php }?>
            	<div class="clear"></div>
				<div class="textfield-container">
					
						<div class="username">
							<input id="username" class="username-field"  type="text" name="username" placeholder="Username"/>
							<span class="validMsg" id="validUser" style=""><img src="images/validDownArr.png" style="position:absolute; top:22px; left:10px;"/>User Name Required </span>
						</div>

					<div class="clear"></div>
						<div class="username">
							<input  id="password" class="username-field"  type="password" name="password" placeholder="Password"/>
							<span class="validMsg" id="validPwd"><img src="images/validDownArr.png" style="position:absolute; top:22px; left:10px;"/>Password Required </span>
						</div>

					
                    <div class="clear"></div>
					<div class="login">
                    	<input type="submit" class="button-skyblue" value="Login" />&nbsp;&nbsp;&nbsp;
						<input type="button" class="button-skyblue" value="Reset" onclick="resetUsernamePassword()"/>
                    </div>
                    <div class="clear"></div>
					<div class="remember-check">
                    	<input type="checkbox" name="rememberMe" id="rememberMe" style="float:left; margin-right:5px; margin-top: 5px; margin-bottom: 5px;" <?php if(isset($_COOKIE['username'])){echo "checked='checked'"; }?> /> 
						<label for="rememberMe">Remember me on this computer</label>
                    </div>
                   
				</div>
				
		</div>
			
		</div>
	</form>		
			
		
	</div>
</div>


<script type="text/javascript">
  function resetUsernamePassword()
  {
	  document.getElementById('username').value = '';
	  document.getElementById('password').value = '';
	  document.login.username.focus();
  }

</script>
</body>
</html>
