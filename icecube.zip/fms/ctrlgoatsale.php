<?php
include('meta_script_link.php');
?><head>
<input type="hidden" id="curryear" name="curryear" value="<?php echo date("y"); ?>" />
<input type="hidden" id="currmon" name="currmon" value="<?php echo date("m"); ?>" />
<input type="hidden" id="currday" name="currday" value="<?php echo date("d"); ?>" />
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script type="text/javascript">
var curdate = "";
var transid = "";
var loc = "";

$(document).ready(function() {
	
	transid = $("#transid").val();
		var curYear = document.getElementById("curryear").value;
		var curMon = document.getElementById("currmon").value;
		var curDay = document.getElementById("currday").value;
		var mindat = curDay + "-" + curMon + "-" + curYear;
		curdate = mindat;
		var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	generateTotal();
});

function printarea(el)
{
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;
}


function proceed()
{
	loc = $("#location").val();
	transid = $("#transid").val();
	//alert(loc);
	//alert(transid);

	if(loc)
	{
		$.ajax({
			type: "post",
			url: "ajaxvalidate.php?frm=getgoat&loc="+loc+"&transid="+transid,
			success: function(data){
				document.getElementById("goatlist").innerHTML = data;
			}
		});
	}
	else
	{
		alert("Please select the Location & proceed.");
		return false;
	}
}

function rem4cart(goatid)
{
	transid = $("#transid").val();
	$.ajax({
	type: "post",
	url: "ajaxvalidate.php?frm=remfrmcart&goat="+goatid+"&transid="+transid,
	success: function(data){
		var splitstr = data.split("|");
		var mycartlbl = "";
		if(splitstr[1])
		{
			mycartlbl = "Generate Inv. (" + splitstr[1] + ")";
		}
		else
		{
			mycartlbl = "Generate Inv.";
		}
		document.getElementById("mycart").value = mycartlbl;
		document.getElementById("transid").value = splitstr[0];
		proceed(loc);
		}
	});
}

function addtocart(goatid)
{
	transid = $("#transid").val();
	$.ajax({
	type: "post",
	url: "ajaxvalidate.php?frm=mycart&goat="+goatid+"&transid="+transid,
	success: function(data){
		var splitstr = data.split("|");
		
		if(splitstr[2] == 2)
		{
			alert("Selected goat already sold or being sold...");
		}		
		document.getElementById("mycart").value = "Generate Inv. (" + splitstr[1] + ")";
		document.getElementById("transid").value = splitstr[0];

		proceed(loc);
		}
	});
}

function getGoatList(loc)
{
	document.getElementById("spandate").innerHTML = curdate;
}

function pendingsale()
{
	$.ajax({
	type: "post",
	url: "ajaxvalidate.php?frm=pendingsale&loc="+loc+"&transid="+transid,
	success: function(data){
			document.getElementById("pendingsale").innerHTML = data;
		}
	});
}

function generateinvoice()
{
	if (transid) {
		window.open('ctrlgoatsale.php?i=' + transid + '&des=' + loc, 'blank');
    }
}

function generateTotal()
{
	var tot = 0;
	var test_arr = $("input[name*='rate']");
	$.each(test_arr, function(i, item) {  //i=index, item=element in array
		//alert($(item).val());
	});
		
	for(var i=0;i<test_arr.length;i++) {
		//alert($(test_arr[i]).val());
		tot = parseFloat(tot) + parseFloat($(test_arr[i]).val());
	}
	if(!tot)
	{
		tot = 0;
	}
	document.getElementById("itot").innerHTML = tot.toFixed(2);
	document.getElementById("hitot").value = tot.toFixed(2);
	genGrantTot();
}
function genGrantTot()
{
	var tax = 0;
	var tot = 0;
	var cgst = 0;
	var sgst = 0;

	cgst = parseFloat($("#icgst").val());
	if(!cgst)
	{
		cgst = 0;
	}
	sgst = parseFloat($("#isgst").val());
	if(!sgst)
	{
		sgst = 0;
	}
	tot = parseFloat($("#itot").text());
	if(!tot)
	{
		tot = 0;
	}
	var iotot = 0;
	iotot = sgst + cgst + tot;
	document.getElementById("igtot").innerHTML = iotot.toFixed(2);
	document.getElementById("higtot").value = iotot.toFixed(2);
}
</script>
<input type="hidden" id="transid" name="transid" value="" />
<div class="main-container">
<?php include('includes/header.php');
?>
<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="">Transactions</a>&nbsp;&raquo;&nbsp;Goat Sale</div>
<!--<div class="msg_wrap">
	<div class="msg_error">Data Already Exists</div>
	<div class="msg_error">Error while processing your request, please try again!!!</div>
</div>-->
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
<?php
if(!$_REQUEST['i'] && !$_REQUEST['sale'])
{
?>
	<div id="dashlet-panel" class="dashlet-panel-full">
	<?php
	$locQry = mysql_query("SELECT l.ID, l.Name Location FROM ".DB."mstrlocation l WHERE l.IsActive = 1 ORDER BY l.Name") or die(mysql_error());
	?>

	<table width="75%" border="0" id="workflowtable" align="center">
	<tr>
	<td>Location:&nbsp;
	<select id="location" name="location" >
	<option value="">--Select--</option>
	<?php
	while($rs = mysql_fetch_array($locQry))
	{
	?>
		<option value="<?php echo $rs['ID']; ?>" <?php if($rs['ID'] == $_REQUEST['location']){?> selected <?php }?> ><?php echo $rs['Location']; ?></option>
	<?php
	}
	?>
	</select>&nbsp;&nbsp;<input type="button" value="get goat list" name="go" id="go" onclick="proceed()" />
	</td>
	<td align="right">
	<input type="button" id="mycart" name="mycart" value="Generate Inv." onclick="generateinvoice()"/>
	</td>
	</tr>
	</table>
	<br/>
	<table width="100%" border="0" id="workflowtable" align="center">
	<tr>
	<td colspan="6">
	<div id="goatlist"></div>
	</td>
	</tr>
	</table>
	</div>
<?php
}
if($_REQUEST['i'])
{
?>
<form name="saleinvoice" action="ctrlgoatsale.php" method="post" id="dispatch">
<input type="hidden" id="transid" name="transid" value="<?php echo $_REQUEST['i']; ?>" />
<input type="hidden" id="locationid" name="locationid" value="<?php echo $_REQUEST['des']; ?>" />
	<div id="dashlet-panel" class="dashlet-panel-full">
	<?php
		//echo $_REQUEST['i'];
		$myCartQry = "SELECT ge.ID, ge.TokenNo, g.Name Gender
				, CASE ge.NatureOfEntry
				WHEN 1 THEN 'Birth'
				WHEN 2 THEN 'Supplier'
				WHEN 3 THEN 'Member'
				END NatureOfEntry
				, pge.TokenNo ParentTokenNo
				, CONCAT(s.Code, ' - ', s.Name) Supplier
				, CONCAT(m.UserName, ' - ', m.Name) Member
				, c.Name Category
			FROM ".DB."opnmycart mc
			INNER JOIN ".DB."opngoatentry ge on ge.ID = mc.GoatEntryID
			INNER JOIN ".DB."lkpgender g ON g.ID = ge.GenderID
			INNER JOIN ".DB."mstrcategory c ON c.ID = ge.CategoryID
			LEFT OUTER JOIN fmsopngoatentry pge ON pge.ID = ge.ParentTokenNo
			LEFT OUTER JOIN fmsmstrsupplier s ON s.ID = ge.SupplierID
			LEFT OUTER JOIN fmsmstremployee m ON m.ID = ge.MemberID AND m.RoleID = 4
			WHERE mc.CreatedBy = ".$_SESSION['UserID']."
			AND mc.SessionID = '".$_REQUEST['i']."'";

		$myCartExe = mysql_query($myCartQry);
		$myCartCnt = mysql_num_rows($myCartExe);
		
		if($myCartCnt > 0)
		{
	?>
			<table width="100%" border="0" id="workflowtable">
			<tbody>
			<tr>
				<td>Customer Name</td>
				<td><input type="text" id="cname" name="cname" required /></td>
				<td>Customer Mobile</td>
				<td><input type="text" id="cmob" name="cmob" required /></td>
			</tr>
			<tr>
				<td>Customer Address</td>
				<td colspan="3"><textarea id="caddr" name="caddr" required ></textarea></td>
			</tr>
			</tbody>
			</table>
			<table width="100%" border="0" id="workflowtable">
				<thead>
				<tr>
				<th>Token #</th>
				<th>Category</th>
				<th>Gender</th>
				<th align='center'>Goat Entry Info</th>
				<th>Amount</th>
				</tr>
				</thead>
				<tbody>
			<?php	
			while($mcrs = mysql_fetch_array($myCartExe))
			{
			?>
				<tr>
				<td><?php echo $mcrs['TokenNo']; ?></td>
				<td><?php echo $mcrs['Category']; ?></td>
				<td><?php echo $mcrs['Gender']; ?></td>
				<td><?php echo $mcrs['NatureOfEntry']." - ".$mcrs['ParentTokenNo'].$mcrs['Supplier'].$mcrs['Member']; ?></td>
				<td align="right">
				<input type="hidden" id="goatid[]" name="goatid[]" value="<?php echo $mcrs['ID']; ?>" />
				<input type="number" id="rate[]" name="rate[]" style="width:100px;text-align:right;" required onchange="generateTotal()" /></td>
				</tr>
			<?php
			}
			?>
			<tr>
				<td colspan="3"></td>
				<td align="right">Total</td>
				<td align="right">
				<input type="hidden" id="hitot" name="hitot" />
				<span id="itot" name="itot"></span></td>
			</tr>
			<tr>
				<td colspan="3"></td>
				<td align="right">SGST</td>
				<td align="right"><input type="number" id="isgst" name="isgst" min="0" style="width:100px;" required onchange="genGrantTot()" /></td>
			</tr>
			<tr>
				<td colspan="3"></td>
				<td align="right">CGST</td>
				<td align="right"><input type="number" id="icgst" name="icgst" min="0" style="width:100px;" required onchange="genGrantTot()" /></td>
			</tr>
			<tr>
				<td colspan="3"></td>
				<td align="right">Grand Total</td>
				<td align="right">
				<input type="hidden" id="higtot" name="higtot" />
				<span id="igtot" name="igtot"></span></td>
			</tr>
			<tr>
			<td colspan="5" align="center"><input type="submit" id="isubmit" name="isubmit" value="submit" /></td>
			</tr>
			</tbody>
			</table>
		<?php
		}
		?>
	
	</div>
</form>
<?php
}


if($_REQUEST['sale'])
{
?>
	<div id="dashlet-panel" class="dashlet-panel-full">
	<?php
		//echo $_REQUEST['i'];
		$mySaleQry = "SELECT l.Name Location, gs.InvoiceNumber, gs.CustomerName, gs.CustomerContact, gs.CustomerAddress , gs.Total, gs.CGST, gs.SGST, gs.GrandTotal FROM ".DB."opngoatsale gs INNER JOIN ".DB."mstrlocation l ON l.ID = gs.LocationID WHERE gs.ID = ".$_REQUEST['sale'];
		
		$mySaleRS = mysql_fetch_array(mysql_query($mySaleQry));

	?>
	<div id="printcontent">
		<table width="100%" border="0" id="workflowtable">
		<tbody>
		<tr>
			<td>Location</td>
			<td><?php echo $mySaleRS['Location']; ?></td>
			<td>Invoice Number</td>
			<td><?php echo $mySaleRS['InvoiceNumber']; ?></td>
		</tr>
		<tr>
			<td>Customer Name</td>
			<td><?php echo $mySaleRS['CustomerName']; ?></td>
			<td>Customer Mobile</td>
			<td><?php echo $mySaleRS['CustomerContact']; ?></td>
		</tr>
		<tr>
			<td>Customer Address</td>
			<td colspan="3"><?php echo $mySaleRS['CustomerAddress']; ?></td>
		</tr>
		</tbody>
		</table>
		<br/>
		<table width="100%" border="0" id="workflowtable">
			<thead>
			<tr>
			<th>Token #</td>
			<th>Category</td>
			<th>Gender</td>
			<th>Par. Token #</td>
			<th>Member Code</td>
			<th>Owner</td>
			<th>Rate</td>
			</tr>
			</thead>
			<tbody>
		<?php
		$mySaleItemQry = "SELECT ge.TokenNo, g.Name Gender, ge.ParentTokenNo, ge.MemberCode, ge.Owner, c.Name Category, gsi.Rate FROM ".DB."opngoatsaleitem gsi INNER JOIN ".DB."opngoatentry ge ON ge.ID = gsi.GoatEntryID INNER JOIN ".DB."mstrcategory c ON c.ID = ge.CategoryID INNER JOIN ".DB."lkpgender g ON g.ID = ge.GenderID WHERE gsi.GoatSaleID = ".$_REQUEST['sale'];	
		$mySaleItemExe = mysql_query($mySaleItemQry);
		while($msrs = mysql_fetch_array($mySaleItemExe))
		{
		?>
			<tr>
			<td><?php echo $msrs['TokenNo']; ?></td>
			<td><?php echo $msrs['Category']; ?></td>
			<td><?php echo $msrs['Gender']; ?></td>
			<td><?php echo $msrs['ParentTokenNo']; ?></td>
			<td><?php echo $msrs['MemberCode']; ?></td>
			<td><?php echo $msrs['Owner']; ?></td>
			<td align="right"><?php echo $msrs['Rate']; ?></td>
			</tr>
		<?php
		}
		?>
		<tr>
			<td colspan="5"></td>
			<td align="right">Total</td>
			<td align="right"><?php echo $mySaleRS['Total']; ?></td>
		</tr>
		<tr>
			<td colspan="5"></td>
			<td align="right">SGST</td>
			<td align="right"><?php echo $mySaleRS['SGST']; ?></td>
		</tr>
		<tr>
			<td colspan="5"></td>
			<td align="right">CGST</td>
			<td align="right"><?php echo $mySaleRS['CGST']; ?></td>
		</tr>
		<tr>
			<td colspan="5"></td>
			<td align="right">Grand Total</td>
			<td align="right"><?php echo $mySaleRS['GrandTotal']; ?></td>
		</tr>
		<tr>
		<td colspan="7" align="right">
		<input type="button" class="stage" name="addbtn" value="Print" id="addbtn" onclick="printarea('printcontent')" />&nbsp;<input type="button" class="stage" name="addbtn" value="Close" id="addbtn" onclick="window.location = 'vwinvoice.php'"/>
		</td>
		</tr>
		</tbody>
		</table>
	</div>	
	
	</div>
<?php
}

?>
<!-- Dashlet-Panel Ends -->	
<?php include('footer.php'); ?> 
</div>
<?php
include("classes/fmsClass.php");
$fmsInvoice = new fmsClass();

if($_REQUEST['transid'])
{
	$fmsInvoice->generateInvoice($_REQUEST['transid'], $_REQUEST['locationid'], $_REQUEST['cname'], $_REQUEST['cmob'], $_REQUEST['caddr'], $_REQUEST['goatid'], $_REQUEST['rate'], $_REQUEST['hitot'], $_REQUEST['isgst'], $_REQUEST['icgst'], $_REQUEST['higtot'], $_SESSION['UserID']);
}
?>