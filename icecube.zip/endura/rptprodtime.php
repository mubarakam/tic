<?php
include('meta_script_link.php');
//print_r($_REQUEST);
?>

<style>
input.error {
	border: 2px thin red;
	background-color:#F00 !important;
}
<!--table#example tr td   { border:1px groove black; }-->

</style>
<script type="text/javascript" src="script/jquery.chosen.min.js"></script>
<script type="text/javascript" src="script/jquery-ui.min.js"></script>
<script type="text/javascript" src="script/jquery.multiselect.min.js"></script>
<script type="text/javascript" src="script/moment.js"></script>
<script>
function datechange(val)
{
	var selval = val.value;
	var date = new Date();
	var frmdate;
	var todate;
	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	if(selval == 1)
	{
		var day = date.getDate();
		var monthIndex = date.getMonth();
		var year = date.getFullYear();		
		day = day - 1;
		frmdate = day + '-' + monthNames[monthIndex] + '-' + year;
		todate = frmdate;
	}
	if(selval == 2)
	{
		frmdate = moment().day(-6);
		todate = moment().day(-1);		
	}
	if(selval == 3)
	{
		var lastday  = new Date(date.getFullYear(), date.getMonth(), 0);
		var firstday = new Date(lastday.getFullYear(), lastday.getMonth(), 1);
		frmdate = firstday.getDate()+'-'+ monthNames[firstday.getMonth()] +'-'+firstday.getFullYear();
		todate = lastday.getDate()+'-'+ monthNames[firstday.getMonth()] +'-'+lastday.getFullYear();
	}
	
	document.getElementById('cddf').value = frmdate;
	document.getElementById('cddt').value = todate;
}
function fnShowHide( iCol )
{
	/* Get the DataTables object again - this is not a recreation, just a get of the object */
	var oTable = $('#example').dataTable();
	
	var bVis = oTable.fnSettings().aoColumns[iCol].bVisible;
	oTable.fnSetColumnVis( iCol, bVis ? false : true );
}
	  $(document).ready(function() {
		$('#example').dataTable().fnDestroy();
		
			  var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	 
	// This will help DataTables magic detect the "dd-MMM-yyyy" format; Unshift so that it's the first data type (so it takes priority over existing)
	jQuery.fn.dataTableExt.aTypes.unshift(
		function (sData) {
			"use strict"; //let's avoid tom-foolery in this function
			if (/^([0-2]?\d|3[0-1])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-\d{2}/i.test(sData)) {
				return 'date-dd-mmm-yyyy';
			}
			return null;
		}
	);
	 
	// define the sorts
	jQuery.fn.dataTableExt.oSort['date-dd-mmm-yyyy-asc'] = function (a, b) {
		"use strict"; //let's avoid tom-foolery in this function
		var ordA = customDateDDMMMYYYYToOrd(a),
			ordB = customDateDDMMMYYYYToOrd(b);
		return (ordA < ordB) ? -1 : ((ordA > ordB) ? 1 : 0);
	};
	 
	jQuery.fn.dataTableExt.oSort['date-dd-mmm-yyyy-desc'] = function (a, b) {
		"use strict"; //let's avoid tom-foolery in this function
		var ordA = customDateDDMMMYYYYToOrd(a),
			ordB = customDateDDMMMYYYYToOrd(b);
		return (ordA < ordB) ? 1 : ((ordA > ordB) ? -1 : 0);
	};
		$('#example').dataTable({
			"bJQueryUI" : true, 
			"bFilter": true,
			"aaSorting": [],
			"bPaginate": false,
			"sScrollX": "100%",
			"sScrollXInner": "100%",
			"sScrollY": "400px",
			"sScrollYInner": "100%",
			"bScrollCollapse": true,
			"text": "export",
			buttons:['excel']
            });
			len = $("#example").find(".ui-state-default").length;
			if(len != 0){
				var out;
				acnt = 0;
				$(".dataTables_scrollHeadInner").find('.ui-state-default').each(function(){
						 out = $(this).attr('aria-label');
							if(typeof(out)  !== "undefined"){
							test = out.split(":");
							label =test[0];
							$("#labels").append("<option selected='selected' value='"+acnt+"'>"+label+"</option>");
							acnt++;
							}
				});
			}
			jQuery("#labels").multiselect({
				header:false,
				});
			
			$("input[name=multiselect_labels]").live('click',function(){
				val = $(this).val();
				fnShowHide(val);	
			});

$(".kpress").keypress(function (e)
{
    e.preventDefault();
});$("input[aria-controls=example]").focus();

		   
	
jQuery(function(){
                jQuery('#rddf').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
					  jQuery( this ).datepicker('option','maxDate', jQuery('#rddt').val() );
						
                    }
                });
                jQuery('#rddt').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
                        jQuery( this ).datepicker('option','minDate', jQuery('#rddf').val() );
                    }
                });
            })
			jQuery(function(){
                jQuery('#cddf').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true/*,
                    beforeShow : function(){
					  jQuery( this ).datepicker('option','maxDate', jQuery('#cddt').val() );
						
                    }*/
                });
                jQuery('#cddt').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true/*,
                    beforeShow : function(){
                        jQuery( this ).datepicker('option','minDate', jQuery('#cddf').val() );
                    }*/
                });
            })
			jQuery(function(){
                jQuery('#dddf').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
					  jQuery( this ).datepicker('option','maxDate', jQuery('#dddt').val() );
						
                    }
                });
                jQuery('#dddt').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
                        jQuery( this ).datepicker('option','minDate', jQuery('#dddf').val() );
                    }
                });
            })
				var oTable = $('#example').dataTable();
				$("#example tbody tr").live("click", function(event){
				   $(this).toggleClass( 'row_selected' );
				});
			
	  });

function projectbindd()
{
	
	var rid=document.getElementById("rid").value
		var date=document.getElementById("date").value
		var rddf=document.getElementById("rddf").value
		var rddt=document.getElementById("rddt").value
		var cddf=document.getElementById("cddf").value
		var cddt=document.getElementById("cddt").value
		var dddf=document.getElementById("dddf").value
		var dddt=document.getElementById("dddt").value
	 window.location = "report_project.php?date="+document.getElementById("date").value+"&rid="+rid


}
function validation()
{
	$("#rid, #date").css({
		'border': '1px solid #8C8C8C',
		"background": "#F7F7F7"
	});
	
	if(document.getElementById("rid").value==0)
	{
		//alert("Please select the round");
		$("#rid").css({
			'border': '1px dashed #FF3F3F',
			"background": "#FAEBE7"
		});	
		return false;
	}
	else if(document.getElementById("date").value=='cho')
	{
		//alert("Please select the criteria");
		$("#date").css({
			'border': '1px dashed #FF3F3F',
			"background": "#FAEBE7"
		});	
		return false;
	}
}
</script>
<div class="main-container">
  <?php include('includes/header.php');?>
</div>
<div class="bread-crums_wrap">
  <div class="bread-crums"><a href="dashboard.php">Home</a> &raquo; <a href="#">Production</a> &raquo; Report</div>
  <div class="msg_wrap"> </div>
  <div class="backlink"><a href="dashboard.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a></div>
</div>
<div class="clear"></div>
<div id="dashlet-panel" class="dashlet-panel-full">
  <form action="" id="report" class="" name="report" onSubmit="projectbindd()" method="post"  >
    <table class="" id="workflowtable" width="100%" >
      <tr>
        <td>Criteria :</td>
        <td>
					<?php 					 
					 $round = mysql_query("SELECT ID, Code FROM ".APP."txnworkorder WHERE IsActive = 1 ORDER BY Code ASC");
					 ?>
          <select name="rid" id="rid" required onchange="datechange(this)" >
            <option value="">--Select--</option>
            <option value="1" <?php if($_REQUEST['rid'] == 1){?> selected <?php } ?> >Daily</option>
			<option value="2" <?php if($_REQUEST['rid'] == 2){?> selected <?php } ?> >Weekly</option>
			<option value="3" <?php if($_REQUEST['rid'] == 3){?> selected <?php } ?> >Monthly</option>
        </select>&nbsp;
		From
		<input type="text" name="cddf" style="width:100px;" class="kpress" value="<?php echo $_REQUEST['cddf']; ?>" id="cddf" />&nbsp;To
		<input type="text" name="cddt" style="width:100px;" class="kpress" value="<?php echo $_REQUEST['cddt']; ?>" id="cddt" />
		&nbsp;<input type="submit" id="sub" onClick="return validation();" value="get detail(s)" name="submit" />
		</td>
         
           <td width="17%" align="right"><a href="rptexlprodtime.php?rid=<?php echo $_REQUEST['rid'] ?>&cddf=<?php echo $_REQUEST['cddf'] ?>&cddt=<?php echo $_REQUEST['cddt'] ?>" ><img src="images/xcel.png" style="border:none;margin-top:5px;" width="20" height="20" alt="Download Report" title="Download Report"> </a>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		</tr>
    </table>
  </form>
 <!-- <br />
 <span style="margin-left:10px;"> Show/Hide Report Fields:</span> <select id="labels" name="labels" multiple="multiple" style="display:none" title="Show/Hide Report Fields"></select>
 </br>--><br/>
 <?php
$rptQuery = "SELECT DISTINCT wo.Code, mp.ProductName, s.StageName, msl.InputQuantity, msl.OutputQuantity, msl.RejectedQuantity, me.Name Employee, st.Description Status, TIMEDIFF(msl.EndTime, msl.StartTime) ProdTime, DATE_FORMAT(msl.StartTime, '%H:%i:%s') StartTime, DATE_FORMAT(msl.EndTime, '%H:%i:%s') EndTime, DATE_FORMAT(msl.StartTime, '%Y-%m-%d') ProdDate, m.MachineName, wot.Target
, wot.Target, (wot.Target/3600) TargetPerSec
, TIME_TO_SEC(TIMEDIFF(msl.EndTime, msl.StartTime)) ActProdInSecs
, msl.OutputQuantity/TIME_TO_SEC(TIMEDIFF(msl.EndTime, msl.StartTime)) OutputPerSec
, CAST(((msl.OutputQuantity/TIME_TO_SEC(TIMEDIFF(msl.EndTime, msl.StartTime)))/(wot.Target/3600))*100 AS DECIMAL(5, 2)) Efficiency
, NULL Remarks
FROM ".APP."txnworkorder wo
INNER JOIN ".APP."txnmetadatastage ms ON ms.WorkOrderID = wo.ID
INNER JOIN ".APP."txnmetadatastagelog msl ON msl.MetadataStageID = ms.ID
INNER JOIN ".APP."mstremployee me ON me.ID = msl.DoneBy
INNER JOIN ".APP."mstrproduct mp ON mp.ID = wo.ProductID
INNER JOIN ".APP."lustage s ON s.ID = ms.StageID
INNER JOIN ".APP."lustatus st ON st.ID = ms.StatusID
LEFT OUTER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageLogID = msl.ID
LEFT OUTER JOIN ".APP."lumachine m ON m.ID = sl.MachineID
LEFT OUTER JOIN ".APP."txnworkordertarget wot ON wot.WorkOrderID = wo.ID AND wot.WorkflowID = ms.WorkflowID AND wot.StageID = ms.StageID AND IF(wot.MachineID IS NULL, 1, wot.MachineID) = IF(sl.MachineID IS NULL, 1, sl.MachineID)
WHERE CAST(msl.StartTime AS DATE) >= STR_TO_DATE('".$_REQUEST['cddf']."', '%d-%b-%Y')
AND CAST(msl.StartTime AS DATE) <= STR_TO_DATE('".$_REQUEST['cddt']."', '%d-%b-%Y')
UNION ALL
SELECT NULL Code, NULL ProductName, s.StageName
, NULL InputQuantity, NULL OutputQuantity, NULL RejectedQuantity
, me.Name Employee, st.Description Status
, TIMEDIFF(ts.EndTime, ts.StartTime) ProdTime, DATE_FORMAT(ts.StartTime, '%H:%i:%s') StartTime
, DATE_FORMAT(ts.EndTime, '%H:%i:%s') EndTime, DATE_FORMAT(ts.StartTime, '%Y-%m-%d') ProdDate
, m.MachineName MachineName, NULL Target, NULL Target, NULL TargetPerSec, NULL ActprodInSecs, NULL OutputPerSsec, NULL Efficiency
, ts.Remarks
FROM ".APP."txntimesheet ts
INNER JOIN ".APP."lustage s ON s.ID = ts.StageID
INNER JOIN ".APP."mstremployee me ON me.ID = ts.DoneBy
INNER JOIN ".APP."lustatus st ON st.ID = ts.StatusID
LEFT OUTER JOIN ".APP."lumachine m ON m.ID = ts.MachineID
WHERE CAST(ts.StartTime AS DATE) >= STR_TO_DATE('".$_REQUEST['cddf']."', '%d-%b-%Y')
AND CAST(ts.StartTime AS DATE) <= STR_TO_DATE('".$_REQUEST['cddt']."', '%d-%b-%Y')";
//echo $rptQuery;
$rptExe = mysql_query($rptQuery) or die(mysql_error());
?>
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" width="100%" border="0" class="display" id="example">
        <thead>
          
          <tr>
            <th width="4%">WO Code</th>
            <th width="10%">Component</th>
            <th width="7%">Process</th>
			<th width="7%">Machine</th>
			<th width="7%">Target/Hour</th>
			<th width="5%">Prod. Date</th>
            <th width="5%">Start Time</th>
            <th width="5%">End Time</th>
			<th width="5%">Tot. Prod. Time</th>
            <th width="3%">Input Qty</th>
            <th width="3%">Output Qty</th>
			<th width="3%">Rej. Qty</th>
            <th width="15%">Operator</th>
            <th width="5%">Status</th>
			<th width="5%">Efficiency (%)</th>
			<th width="5%">Remarks</th>
          </tr>
          
        </thead>
        <tbody>
<?php
while($rptRS = mysql_fetch_array($rptExe))
{
?>
	<tr>
	<td><?php echo $rptRS['Code']; ?></td>
	<td><?php echo $rptRS['ProductName']; ?></td>
	<td><?php echo $rptRS['StageName']; ?></td>
	<td><?php echo $rptRS['MachineName']; ?></td>
	<td><?php echo $rptRS['Target']; ?></td>
	<td><?php echo $rptRS['ProdDate']; ?></td>
	<td><?php echo $rptRS['StartTime']; ?></td>
	<td><?php echo $rptRS['EndTime']; ?></td>
	<td><?php echo $rptRS['ProdTime']; ?></td>
	<td><?php echo $rptRS['InputQuantity']; ?></td>
	<td><?php echo $rptRS['OutputQuantity']; ?></td>
	<td><?php echo $rptRS['RejectedQuantity']; ?></td>
	<td><?php echo $rptRS['Employee']; ?></td>
	<td><?php echo $rptRS['Status']; ?></td>
	<td><?php echo $rptRS['Efficiency']; ?></td>
	<td><?php echo $rptRS['Remarks']; ?></td>
	</tr>
<?php
}
?>
        </tbody>
      </table>
</div>
</div>
</td>
</tr>
</td>
</tr>
</div>
</div>
</div>
<?php include('includes/footer.php'); ?>
</div>
</body></html>