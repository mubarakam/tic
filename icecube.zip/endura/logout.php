<?php
//session_start();
//include("config.php");
//mysql_query("UPDATE login_info SET system_logout_time = now() WHERE login_info_id = ".$_SESSION['login_info_id']);
//session_destroy();
//session_unset();
header("location: index.php");
?>