<?php
include('config.php');
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2012 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2012 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);

date_default_timezone_set('Europe/London');

/** Include PHPExcel */
require_once 'includes/classes/PHPExcel.php';


// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);

$styleArray = array(
  'borders' => array(
    'allborders' => array(
      'style' => PHPExcel_Style_Border::BORDER_THIN
    )
  )
);

$objPHPExcel->getActiveSheet()->getStyle('A2:B3')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('A1:C1')->applyFromArray($styleArray);

$columnQry = mysql_query("SELECT DISTINCT CAST(msl.StartTime AS DATE) StartTime, DATE_FORMAT(msl.StartTime, '%d-%b-%y') DisplayData FROM ".APP."txnmetadatastagelog msl
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageLogID = msl.ID
WHERE msl.StartTime BETWEEN DATE_SUB(NOW(), INTERVAL 1 MONTH) AND NOW()
ORDER BY msl.StartTime ASC") or die(mysql_error());

$data = array();
$displaydata = array();
while($rs = mysql_fetch_array($columnQry))
{
	array_push($data, $rs['StartTime']);
	array_push($displaydata, $rs['DisplayData']);
}
array_push($displaydata, 'Grand Total');
$excelColumn = array("G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1");
$excelDataColumn = array("C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG");
$row = 5;

$fromdate = MIN($data);
$todate = MAX($data);

$objPHPExcel->getActiveSheet()->mergeCells('A1:C1');
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->setSize(16);

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Machine vs Operator')
            ->setCellValue('A2', 'From Date')
            ->setCellValue('A3', 'To Date')
			->setCellValue('B2', $fromdate)
			->setCellValue('B3', $todate);

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, 'Machine')
            ->setCellValue('B'.$row, 'Operator');
$objPHPExcel->getActiveSheet()->getStyle('A'.$row)->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B'.$row)->applyFromArray($styleArray);

for($c=0;$c<=COUNT($data);$c++)
{
	$objPHPExcel->getActiveSheet()->getColumnDimension($excelDataColumn[$c])->setWidth(10);
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue($excelDataColumn[$c].$row, $displaydata[$c]);
	$objPHPExcel->getActiveSheet()->getStyle($excelDataColumn[$c].$row)->applyFromArray($styleArray);
}
$row = $row + 2;

$machineqry = mysql_query("SELECT DISTINCT sl.MachineID, m.MachineName, msl.DoneBy, e.Name FROM ".APP."txnmetadatastagelog msl
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageLogID = msl.ID
INNER JOIN ".APP."lumachine m ON m.ID = sl.MachineID
INNER JOIN ".APP."mstremployee e ON e.ID = msl.DoneBy
WHERE msl.StartTime BETWEEN '".$fromdate."' AND '".$todate."'
ORDER BY m.MachineName ASC;");

$curmachine = '';
$premachine = '';
while($macrs = mysql_fetch_array($machineqry))
{
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, $macrs['MachineName'])
			->setCellValue('B'.$row, $macrs['Name']);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$row)->applyFromArray($styleArray);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$row)->applyFromArray($styleArray);
	
	$grandtot = 0;
	for($c=0;$c<COUNT($data);$c++)
	{
		$getValueQry = "SELECT msl.DoneBy, e.Name, (msl.OutputQuantity) OutputQuantity FROM ".APP."txnmetadatastagelog msl
						INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageLogID = msl.ID
						INNER JOIN ".APP."lumachine m ON m.ID = sl.MachineID
						INNER JOIN ".APP."mstremployee e ON e.ID = msl.DoneBy
						WHERE CAST(msl.StartTime AS DATE) = '".$data[$c]."'
						AND sl.MachineID = ".$macrs['MachineID']."
						AND msl.DoneBy = ".$macrs['DoneBy']."
						GROUP BY msl.DoneBy, e.Name";
		$getValuers = mysql_fetch_array(mysql_query($getValueQry));
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue($excelDataColumn[$c].$row, $getValuers['OutputQuantity']);
		$grandtot = $grandtot + $getValuers['OutputQuantity'];
		$objPHPExcel->getActiveSheet()->getStyle($excelDataColumn[$c].$row)->applyFromArray($styleArray);
	}
	$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue($excelDataColumn[$c].$row, $grandtot);
	$objPHPExcel->getActiveSheet()->getStyle($excelDataColumn[$c].$row)->applyFromArray($styleArray);
	$row++;
}

// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle("MachineVsOperator");

// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="MachineVsOperator.xlsx"');
header('Cache-Control: max-age=0');
PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
