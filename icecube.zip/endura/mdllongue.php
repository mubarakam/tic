<?php
session_start();
ob_start();
include("config.php");
include("includes/classes/erpClass.php");
$erp = new erpClass();
echo "<pre>";
print_r($_REQUEST);

$createdby = $_SESSION['UserID'];
$process = $_REQUEST['process'];
$doneby = $_REQUEST['ddEmployee'];
$proddate = $_REQUEST['proddate'];
$starttime = $_REQUEST['fromhour'].":".$_REQUEST['fromminute'];
$endtime = $_REQUEST['tohour'].":".$_REQUEST['tominute'];
$startdatetime = date('Y-m-d', strtotime($proddate))." ".$starttime;
$enddatetime = date('Y-m-d', strtotime($proddate))." ".$endtime;
$machine = $_REQUEST['machine'];
$remark = $_REQUEST['remark'];

if(!$machine)
{
	$machine = NULLVALUE;
}

$erp->LongueActivity($process, $doneby, $startdatetime, $enddatetime, $createdby, $machine, $remark);

?>