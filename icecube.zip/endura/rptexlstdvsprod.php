<?php
include('config.php');
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2012 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2012 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);

date_default_timezone_set('Europe/London');

/** Include PHPExcel */
require_once 'includes/classes/PHPExcel.php';


// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");

//$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(18);

$wo = $_REQUEST['rid'];
//$wo = 31;
$columnQry = mysql_query("SELECT DISTINCT sl.CreatedOn AS CreatedOn, sl.MetadataStageID FROM ".APP."txnmetadatastage tms
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID
WHERE tms.WorkOrderID = ".$wo."
ORDER BY sl.CreatedOn ASC") or die(mysql_error());

$data = array();
$metaStdId = array();
while($rs = mysql_fetch_array($columnQry))
{
	array_push($data, $rs['CreatedOn']);
	array_push($metaStdId, $rs['MetadataStageID']);
}

$excelColumn = array("G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1");
$excelDataColumn = array("G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U1", "V1", "W1", "X1", "Y1", "Z1");
$row = 1;
// Header data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'WO Code')
            ->setCellValue('B1', 'Parameter Name')
            ->setCellValue('C1', 'Process')
			->setCellValue('D1', 'Machine')
			->setCellValue('E1', 'Std. Setting')
            ->setCellValue('F1', 'WO Setting');

for($c=0;$c<COUNT($data);$c++)
{
	$objPHPExcel->getActiveSheet()->getColumnDimension($excelDataColumn[$c])->setWidth(18);
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue($excelDataColumn[$c].$row, $data[$c]);
}

$mainqry = mysql_query("SELECT DISTINCT wo.ID, wo.Code, wos.AttributeID, wa.Description Attribute, wos.StageID, ws.StageName StageName, wos.Value WOValue, tss.Value StandardValue, wos.MachineID, wm.MachineName, sl.ValueSequence
FROM ".APP."txnworkorder wo
INNER JOIN ".APP."txnworkordersetting wos ON wos.WorkOrderID = wo.ID
INNER JOIN ".APP."mstrstandard ms ON ms.ID = wo.StandardID
INNER JOIN ".APP."txnstandardsetting tss ON tss.StandardID = ms.ID AND tss.StageID = wos.StageID AND tss.MachineID = wos.MachineID AND tss.AttributeID = wos.AttributeID AND tss.ValueSequence = wos.ValueSequence
INNER JOIN ".APP."luattribute wa ON wa.ID = wos.AttributeID
INNER JOIN ".APP."lustage ws ON ws.ID = wos.StageID
INNER JOIN ".APP."lumachine wm ON wm.ID = wos.MachineID
INNER JOIN ".APP."txnmetadatastage tms ON tms.WorkOrderID = wo.ID AND tms.StageID = wos.StageID
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID AND sl.AttributeID = wos.AttributeID AND sl.MachineID = wos.MachineID AND sl.ValueSequence = wos.ValueSequence
WHERE wo.ID = ".$wo." AND wos.AttributeID IS NOT NULL");

$row = 2;
while($rs = mysql_fetch_array($mainqry))
{

// Header data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, $rs['Code'])
            ->setCellValue('B'.$row, $rs['Attribute'])
            ->setCellValue('C'.$row, $rs['StageName'])
			->setCellValue('D'.$row, $rs['MachineName'])
			->setCellValue('E'.$row, $rs['StandardValue'])
            ->setCellValue('F'.$row, $rs['WOValue']);

for($c=0;$c<COUNT($data);$c++)
{
	$getValueQry = "SELECT sl.Value FROM ".APP."txnmetadatastage tms INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID WHERE sl.MetadataStageID = ".$metaStdId[$c]." AND sl.AttributeID = ".$rs['AttributeID']." AND sl.MachineID = ".$rs['MachineID']." AND sl.CreatedOn = '".$data[$c]."' AND tms.StageID = ".$rs['StageID']." AND sl.ValueSequence = ".$rs['ValueSequence'];
	$getValuers = mysql_fetch_array(mysql_query($getValueQry));
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue($excelDataColumn[$c].$row, $getValuers['Value']);
}
$row = $row + 1;
}

// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle("StdVsProdSetting(s)");

// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="StdVsProdSetting.xlsx"');
header('Cache-Control: max-age=0');
PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
