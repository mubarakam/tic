// JavaScript Document
function popUp() {
	centeringPopup("#popup");
	$("#popup").fadeIn("slow");
	popupStatus = 1;
}
function centeringPopup(div_id) {
	$("body").addClass("ieerror_fix");
	$("html").addClass("ieerror_fix");
	var window_width = document.documentElement.clientWidth;
	var popup_width = $("#popup").width();
//	alert(window_width);
//	alert(popup_width);
	$("#popup").css({
		"top" : 100,
		"left" : window_width/2 - popup_width/2	
	});
}
function closePopup() {
	if(popupStatus == 1) {
		$("body").removeClass("ieerror_fix");
		$("html").removeClass("ieerror_fix");
		$("body").removeAttr("class");
		$("html").removeAttr("class");
		$("#popup").fadeOut("slow");
		popupStatus = 0;
	}
}
function opener(){
	var txt = '<label class="signinhead">Select</label>'
	txt+= '<label class="displayprompterror"></label>';
	txt+= '<span><label for="username" class="signuplabel">Email </label></span>';
	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}
function bib(){	
	
	var txt = '<label class="signinhead" style="margin-bottom:30px">Add Bibliography </label>'
	txt+= '<span><label class="signuplabel" style="margin-left:20px;"><strong>Bibliography : </strong></label><select class="bibTextField" name="type" id="bjtype" style="width:150px;" onchange="bjtype();"><option value="--select--">--Select--</option><option value="book">Book</option><option value="epath">ePath</option><option value="journal">Journal</option><option value="other">Other</option><option value="patent">Patent</option><option value="proceeding">Proceeding</option></select></span><br><br>';

	//journal  sssssssss
	txt+= '<div id="journals" style="display:none;"><form name="fjournal" id="formj" method="post"><span><label style="margin-left:20px;text-decoration:underline;"><strong>Author</strong></label></span><br><br>';
	txt+= '<span id="jaddMore" style="display:block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="jfname" name="jfname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="jsname" name="jsname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'journal\');">Add More +</a></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:15px;clear:left;"><strong>Journal Title:</strong></label><input class="bibTextField" style="width:200px" type="text" id="journalTit" name="journal"/><strong style="margin-left:20px;">Volume:</strong></label>&nbsp;<input class="bibTextField" style="width:80px" type="text" id="jvolume" name="jvolume"/><strong style="margin-left:20px;">Issue:</strong></label>&nbsp;<input class="bibTextField" style="width:80px" type="text" id="jissue" name="jissue"/></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:2px;"><strong>First Page:</strong></label><input class="bibTextField" style="width:80px" type="text" id="jfpage" name="jfpage"/><strong style="margin-left:20px;">Last Page:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:80px" type="text" id="jlpage" name="jlpage"/><strong style="margin-left:20px;">Pub Year:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:80px" type="text" id="pubYear" name="pubYear"/></span><br><br>';
	txt+= '<span><input style="margin-left:550px" type="button" id="jtype" name="jtype" value="Add" onclick="jrnls(\'jtype\');"/></span><br><br></form></div>';

	//book
	txt+= '<div id="books" style="display:none;"><form name="fbook" id="formb" method="post"><span onClick="beaSlide(\'authSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Author</strong></label></span><br><br>';
	txt+= '<span id="baddMore" style="display:display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="bfname" name="bfname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="bsname" name="bsname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'book\');">Add More +</a></span><br><br><br>';
	txt+= '<span onClick="beaSlide(\'editSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Editor</strong></label></span><br><br>';
	txt+= '<span id="beaddMore" style="display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="befname" name="befname[]" />&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="besname" name="besname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'editr\');">Add More +</a></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:0px;clear:left;"><strong>Book Title:</strong></label><input class="bibTextField" style="width:200px" type="text" id="booktit" name="booktit"/><strong style="margin-left:29px;">Volume:</strong></label>&nbsp;<input class="bibTextField" style="width:200px" type="text" id="bvol" name="bvol"/></span><br><br><br>';
	txt+= '<span><label style="width:200px;margin-left:20px;clear:left;"><strong>Publisher Name:</strong></label><input class="bibTextField" style="width:200px" type="text" id="pubname" name="pubname"/><strong style="margin-left:29px;">Publisher Loc:</strong></label>&nbsp;<input class="bibTextField" style="width:200px" type="text" id="publoc" name="publoc"/></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:4px;"><strong>First Page:</strong></label><input class="bibTextField" style="width:80px" type="text" id="bfpage" name="bfpage"/><strong style="margin-left:20px;">Last Page:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:80px" type="text" id="blpage" name="blpage"/><strong style="margin-left:10px">Pub Year:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="bpubyear" name="bpubyear"/></span><br><br><br>';	
	txt+= '<span><input style="margin-left:550px" type="button" id="btype" name="btype" value="Add" onclick="booker(\'btype\');"/></span><br><br></form></div>';

	//ePath
	txt+= '<div id="epath" style="display:none;"><form name="fepath" id="forme" method="post"><span onClick="beaSlide(\'authSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Author</strong></label></span><br><br>';
	txt+= '<span id="baddMore" style="display:display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="efname" name="efname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="esname" name="esname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'book\');">Add More +</a></span><br><br><br>';
	txt+= '<span>&nbsp;&nbsp;<strong style="margin-left:10px">Pub Year:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="epubyear" name="epubyear"/></span><br><br><br>';
	txt+= '<span><label style="width:200px;margin-left:20px;clear:left;"><strong>URL :</strong></label><input class="bibTextField" style="width:200px" type="text" id="url" name="url"/></span><br><br><br>';
	txt+= '<span><input style="margin-left:550px" type="button" id="etype" name="etype" value="Add" onclick="epath(\'etype\');"/></span><br><br></form></div>';

	//otherCit
	txt+= '<div id="othCit" style="display:none;"><form name="focit" id="forme" method="post"><span onClick="beaSlide(\'authSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Author</strong></label></span><br><br>';
	txt+= '<span id="baddMore" style="display:display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="ofname" name="ofname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="osname" name="osname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'book\');">Add More +</a></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:0px;clear:left;"><strong>Other Title:</strong></label><input class="bibTextField" style="width:200px" type="text" id="othertit" name="othertit"/></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:4px;"><strong>First Page:</strong></label><input class="bibTextField" style="width:80px" type="text" id="ofpage" name="ofpage"/><strong style="margin-left:20px;">Last Page:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:80px" type="text" id="olpage" name="olpage"/><strong style="margin-left:10px">Pub Year:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="opubyear" name="opubyear"/></span><br><br><br>';
	txt+= '<span><input style="margin-left:550px" type="button" id="otype" name="otype" value="Add" onclick="othercit(\'otype\');"/></span><br><br></form></div>';

	//patentCit
	txt+= '<div id="patentCit" style="display:none;"><form name="fpcit" id="forme" method="post"><span onClick="beaSlide(\'authSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Author</strong></label></span><br><br>';
	txt+= '<span id="baddMore" style="display:display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="pfname" name="pfname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="psname" name="psname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'book\');">Add More +</a></span><br><br><br>';
	txt+= '<span>&nbsp;&nbsp;<strong style="margin-left:10px">Pub Year:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="ppubyear" name="ppubyear"/></span><br><br><br>';
	txt+= '<span>&nbsp;&nbsp;<strong style="margin-left:10px">Patent Info:&nbsp;&nbsp;</strong></span><br><br>';
	txt+= '<span>&nbsp;&nbsp;<strong style="margin-left:10px">Jurisdiction:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="pjurisdiction" name="pjurisdiction"/>&nbsp;&nbsp;<strong style="margin-left:10px">Number:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="pnumber" name="pnumber"/></span><br><br><br>';
	txt+= '<span><input style="margin-left:550px" type="button" id="ptype" name="ptype" value="Add" onclick="patentcit(\'ptype\');"/></span><br><br></form></div>';

	//proceedingsCit
	txt+= '<div id="proceedingCit" style="display:none;"><form name="fproceed" id="formb" method="post"><span onClick="beaSlide(\'authSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Author</strong></label></span><br><br>';
	txt+= '<span id="baddMore" style="display:display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="prfname" name="prfname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="prsname" name="prsname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'book\');">Add More +</a></span><br><br><br>';
	txt+= '<span onClick="beaSlide(\'editSlide\')"><label style="margin-left:20px;text-decoration:underline;cursor:pointer;"><strong>Editor</strong></label></span><br><br>';
	txt+= '<span id="beaddMore" style="display:inline-block;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="prefname" name="prefname[]" />&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" id="presname" name="presname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addMore(\'editr\');">Add More +</a></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:0px;clear:left;"><strong>Article Title:</strong></label><input class="bibTextField" style="width:200px" type="text" id="prartitletit" name="prartitletit"/>&nbsp;&nbsp;<strong>Chapter Name:</strong></label><input class="bibTextField" style="width:200px" type="text" id="prchapname" name="prchapname"/><br><br><br>';
	txt+= '<span><label style="width:200px;margin-left:20px;clear:left;"><strong>Publisher Name:</strong></label><input class="bibTextField" style="width:200px" type="text" id="prpubname" name="prpubname"/><strong style="margin-left:29px;">Publisher Loc:</strong></label>&nbsp;<input class="bibTextField" style="width:200px" type="text" id="prpubloc" name="prpubloc"/></span><br><br><br>';
	txt+= '<span><label class="signuplabel" style="margin-left:4px;"><strong>First Page:</strong></label><input class="bibTextField" style="width:80px" type="text" id="prfpage" name="prfpage"/><strong style="margin-left:20px;">Last Page:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:80px" type="text" id="prlpage" name="prlpage"/><strong style="margin-left:10px">Pub Year:&nbsp;&nbsp;</strong><input class="bibTextField" style="width:80px" type="text" id="prpubyear" name="prpubyear"/></span><br><br><br>';	
	txt+= '<span><input style="margin-left:550px" type="button" id="prtype" name="prtype" value="Add" onclick="proceeding(\'prtype\');"/></span><br><br></form></div>';

	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}

function bjtype(){
	var bjtype = $("#bjtype").val();
	if(bjtype == 'journal'){
	$("#books").css('display','none');
	$("#journals").css('display','block');
	$("#epath").css('display','none');
	$("#othCit").css('display','none');
	$("#patentCit").css('display','none');
	$("#proceedingCit").css('display','none');
	}
	else if(bjtype == 'book'){
	$("#journals").css('display','none');
	$("#books").css('display','block');
	$("#epath").css('display','none');
	$("#othCit").css('display','none');
	$("#patentCit").css('display','none');
	$("#proceedingCit").css('display','none');
	}
	else if(bjtype == 'epath'){
		$("#journals").css('display','none');
		$("#books").css('display','none');
		$("#epath").css('display','block');
		$("#othCit").css('display','none');
		$("#patentCit").css('display','none');
		$("#proceedingCit").css('display','none');
	}
	else if(bjtype == 'other'){
		$("#journals").css('display','none');
		$("#books").css('display','none');
		$("#epath").css('display','none');
		$("#othCit").css('display','block');
		$("#patentCit").css('display','none');
		$("#proceedingCit").css('display','none');
	}
	else if(bjtype == 'patent'){
		$("#journals").css('display','none');
		$("#books").css('display','none');
		$("#epath").css('display','none');
		$("#othCit").css('display','none');
		$("#patentCit").css('display','block');
		$("#proceedingCit").css('display','none');
	}
	else if(bjtype == 'proceeding'){
		$("#journals").css('display','none');
		$("#books").css('display','none');
		$("#epath").css('display','none');
		$("#othCit").css('display','none');
		$("#patentCit").css('display','none');
		$("#proceedingCit").css('display','block');
	}

	
}

function beaSlide(slideType){
	if(slideType == 'editSlide'){
	/*$("#books").css('display','none');*/
	$("#beaddMore").slideToggle('slow');
	}
	if(slideType == 'authSlide'){
	/*$("#journals").css('display','none');*/
	$("#baddMore").slideToggle('slow');
	}
}
function addMore(type){
	if(type == 'journal' ){
		jcount++;
		if(jcount<=10){
			$("#jaddMore").append('<br><br><span style="float:left;clear:left;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text"  name="jfname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text"  name="jsname[]"/><br><br></span>');
		}
	}
	 if(type == 'book'){
			bcount++;
		if(bcount<=10)
		{
			$("#baddMore").append('<br><br><span style="float:left;clear:left;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text"  name="bfname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" name="bsname[]"/><br><br></span>');
		}
	}
	if(type == 'editr'){
			bcount++;
		if(bcount<=10)
		{
			$("#beaddMore").append('<br><br><span style="float:left;clear:left;"><label style="margin-left:20px;"><strong>Forename:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text"  name="befname[]"/>&nbsp;&nbsp;<strong>Surname:&nbsp;&nbsp;</strong></label><input class="bibTextField" style="width:200px" type="text" name="besname[]"/><br><br></span>');
		}
	}
}
function addb(type){

	if(type== 'jtype'){
		//Author's Forename & Surname
		var jfornames = $("input[name^=jfname]").serializeArray();
		var jsnames = $("input[name^=jsname]").serializeArray();
		//alert(jfornames.length);
		if(jfornames[0].value == ''){
			authorname='';			
		} else {
			authorname='';
			for(i=0;i<jfornames.length;i++){
				var cntj = jfornames.length;
				if(i== cntj){
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+jfornames[i].value+'</div><!--forenames--><div class="surname">'+jsnames[i].value+'</div><!--surname-->';	
					authorname +='</div><!--author-->.';
				} else if(i== cntj-1 && cntj !=1){
					authorname +=' and <div class="author">';
					authorname +='<div class="forenames">'+jfornames[i].value+'</div><!--forenames--><div class="surname">'+jsnames[i].value+'</div><!--surname-->';	
					authorname +='</div><!--author-->';
				} else {
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+jfornames[i].value+'</div><!--forenames--><div class="surname">'+jsnames[i].value+'</div><!--surname-->';	
					authorname +='</div><!--author-->,';
				}
			}
			
		}		
		//Journal		
		var jurntit = $("#journalTit").val();
		if(jurntit==''){
			var jurntitres = '';
		}else{
			var jurntitres = '<div class="journalTitle">'+jurntit+'</div><!--journalTitle-->,';
		}
		//Volume
		var jvol = $("#jvolume").val();		
		if(jvol==''){
			var jvolres = '';
		}else{
			var jvolres = '<div class="vol">'+jvol+'</div><!--vol-->,';
		}
		//Issue
		var jissue = $("#jissue").val();		
		if(jissue==''){
			var jissueres = '';
		}else{
			var jissueres = '<div class="issue">'+jissue+'</div><!--issue-->,';
		}
		//First Page
		var jfpage = $("#jfpage").val();		
		if(jfpage==''){
			var jfpageres = '';
		}else{
			var jfpageres = '<div class="firstPage">'+jfpage+'</div><!--firstPage-->';
		}
		//Last Page
		var jlpage = $("#jlpage").val();		
		if(jlpage==''){
			var jlpageres = '';
		}else{
			var jlpageres = '<div class="lastPage">'+jlpage+'</div><!--lastPage-->,';
		}
		//Pub Year
		var pubYear = $("#pubYear").val();		
		if(pubYear==''){
			var pubYearres = '';
		}else{
			var pubYearres = '(<div class="pubYear" year="'+pubYear+'">'+pubYear+'</div><!--pubYear-->).';
		}
	var finalJourCit ='<div class="bib" id="journal"><div class="journalCit">'+authorname+jurntitres+jvolres+jissueres+jfpageres+jlpageres+pubYearres+'</div><!--journalCit--></div><!--bib-->&nbsp;';
	closePopup();
	tinyMCE.execCommand('mceInsertContent',false,finalJourCit);

	}
	else if(type == 'btype'){
		//Author's Forename & Surname
		var bfnames = $("input[name^=bfname]").serializeArray();
		var bsnames = $("input[name^=bsname]").serializeArray();
		if(bfnames[0].value == ''){
			authorname='';			
		} else {
			authorname='';
			for(i=0;i<bfnames.length;i++){
				var cnt = bfnames.length;
				if(i== cnt){
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+bfnames[i].value+'</div><!--forenames--><div class="surname">'+bsnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->.';
				} else if(i== cnt-1 && cnt !=1){
					authorname +=' and <div class="author">';
					authorname +='<div class="forenames">'+bfnames[i].value+'</div><!--forenames--><div class="surname">'+bsnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->';
				} else {
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+bfnames[i].value+'</div><!--forenames--><div class="surname">'+bsnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->,';
				}
			}
		}
		//Editor's Forename & Surame
		var befnames = $("input[name^=befname]").serializeArray();
		var besnames = $("input[name^=besname]").serializeArray();
		if(befnames[0].value == ''){
			editorname='';			
		} else {
			editorname ='';
			for(j=0;j<befnames.length;j++){
				var cnte = befnames.length;
				if(j== cnte){
					editorname +='<div class="editor">';
					editorname +='<div class="forenames">'+befnames[j].value+'</div><!--forenames--><div class="surname">'+besnames[j].value+'</div><!--surname-->';	
					editorname +='</div><!--editor-->.';
				} else if(j== cnte-1 && cnte !=1){
					editorname +=' and <div class="editor">';
					editorname +='<div class="forenames">'+befnames[j].value+'</div><!--forenames--><div class="surname">'+besnames[j].value+'</div><!--surname-->';	
					editorname +='</div><!--editor-->';
				} else {				
					editorname +='<div class="editor">';
					editorname +='<div class="forenames">'+befnames[j].value+'</div><!--forenames--><div class="surname">'+besnames[j].value+'</div><!--surname-->';	
					editorname +='</div><!--editor-->,';
				}
			}			
		}
		//Book title		
		var booktit = $("#booktit").val();
		if(booktit==''){
			var booktitres = '';
		}else{
			var booktitres = '<div class="bookTitle">'+booktit+'</div><!--bookTitle-->,';
		}
		//Volume
		var bvol = $("#bvol").val();		
		if(bvol==''){
			var bvolres = '';
		}else{
			var bvolres = '<div class="vol">'+bvol+'</div><!--vol-->,';
		}
		//Publisher Name
		var pubname = $("#pubname").val();		
		if(pubname==''){
			var pubnameres = '';
		}else{
			var pubnameres = '<div class="publisherName">'+pubname+'</div><!--publisherName-->,';
		}
		//Publisher Loc
		var publoc = $("#publoc").val();		
		if(publoc==''){
			var publocres = '';
		}else{
			var publocres = '<div class="publisherLoc">'+publoc+'</div><!--publisherLoc-->,';
		}
		//First Page
		var bfpage = $("#bfpage").val();		
		if(bfpage==''){
			var bfpageres = '';
		}else{
			var bfpageres = '<div class="firstPage">'+bfpage+'</div><!--firstPage-->';
		}
		//Last Page
		var blpage = $("#blpage").val();		
		if(blpage==''){
			var blpageres = '';
		}else{
			var blpageres = '<div class="lastPage">'+blpage+'</div><!--lastPage-->,';
		}
		//Pub Year
		var bpubyear = $("#bpubyear").val();		
		if(bpubyear==''){
			var bpubyearres = '';
		}else{
			var bpubyearres = '(<div class="pubYear" year="'+bpubyear+'">'+bpubyear+'</div><!--pubYear-->).';
		}
	var finalBookCit ='<div class="bib" id="book"><div class="bookCit">'+authorname+editorname+booktitres+bvolres+pubnameres+publocres+bfpageres+blpageres+bpubyearres+'</div><!--bookCit--></div><!--bib-->&nbsp;';
	closePopup();
	//if((eleName =='bib')||(eleName =='bib')){
		
		tinyMCE.execCommand('mceInsertContent',false,finalBookCit);
	//}
	}//for epath cit
	else if(type == 'etype'){
		//Author's Forename & Surname
		var efnames = $("input[name^=efname]").serializeArray();
		var esnames = $("input[name^=esname]").serializeArray();
		if(efnames[0].value == ''){
			authorname='';			
		} else {
			authorname='';
			for(i=0;i<efnames.length;i++){
				var cnt = efnames.length;
				if(i== cnt){
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+efnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+esnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->.';
				} else if(i== cnt-1 && cnt !=1){
					authorname +=' and <div class="author">';
					authorname +='<div class="forenames">'+efnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+esnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->';
				} else {
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+efnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+esnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->,';
				}
			}
		}

		//url
		var url = $("#url").val();		
		if(url==''){
			var url = '';
		}else{
			var url = '<div class="url" xlink:href="'+url+'">'+url+'</div><!--url-->';
		}

		//Pub Year
		var epubyear = $("#epubyear").val();		
		if(epubyear==''){
			var epubyearres = '';
		}else{
			var epubyearres = '(<div class="pubYear" year="'+epubyear+'">'+epubyear+'</div><!--pubYear-->).';
		}

		var finalePathCit ='<div class="bib" id="epath"><div class="ePathCit">'+authorname+url+epubyearres+'</div><!--ePathCit--></div><!--bib-->&nbsp;';
		closePopup();
	//if((eleName =='bib')||(eleName =='bib')){

		tinyMCE.execCommand('mceInsertContent', false, finalePathCit);
	//}
	}//for other cit
	else if(type == 'otype'){
		//Author's Forename & Surname
		var ofnames = $("input[name^=ofname]").serializeArray();
		var osnames = $("input[name^=osname]").serializeArray();
		if(ofnames[0].value == ''){
			authorname='';			
		} else {
			authorname='';
			for(i=0;i<ofnames.length;i++){
				var cnt = ofnames.length;
				if(i== cnt){
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+ofnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+osnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->.';
				} else if(i== cnt-1 && cnt !=1){
					authorname +=' and <div class="author">';
					authorname +='<div class="forenames">'+ofnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+osnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->';
				} else {
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+ofnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+osnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->,';
				}
			}
		}

		//Pub Year
		var opubyear = $("#opubyear").val();
		if(opubyear==''){
			var opubyearres = '';
		}else{
			var opubyearres = '(<div class="pubYear" year="'+opubyear+'">'+opubyear+'</div><!--pubYear-->).';
		}

		//other title		
		var othertit = $("#othertit").val();
		if(othertit==''){
			var othertitres = '';
		}else{
			var othertitres = '<div class="otherTitle">'+othertit+'</div><!--otherTitle-->,';
		}

		//First Page
		var ofpage = $("#ofpage").val();		
		if(ofpage==''){
			var ofpageres = '';
		}else{
			var ofpageres = '<div class="firstPage">'+ofpage+'</div><!--firstPage-->';
		}
		//Last Page
		var olpage = $("#olpage").val();		
		if(olpage==''){
			var olpageres = '';
		}else{
			var olpageres = '&ndash;<div class="lastPage">'+olpage+'</div><!--lastPage-->,';
		}
		
		var finalotherCit ='<div class="bib" id="othcit"><div class="otherCit">'+authorname+othertitres+ofpageres+olpageres+opubyearres+'</div><!--otherCit--></div><!--bib-->&nbsp;';
		closePopup();

		tinyMCE.execCommand('mceInsertContent', false, finalotherCit);
	}//for patent cit
	else if(type == 'ptype'){
		//Author's Forename & Surname
		var pfnames = $("input[name^=pfname]").serializeArray();
		var psnames = $("input[name^=psname]").serializeArray();
		if(pfnames[0].value == ''){
			authorname='';			
		} else {
			authorname='';
			for(i=0;i<pfnames.length;i++){
				var cnt = pfnames.length;
				if(i== cnt){
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+pfnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+psnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->.';
				} else if(i== cnt-1 && cnt !=1){
					authorname +=' and <div class="author">';
					authorname +='<div class="forenames">'+pfnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+psnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->';
				} else {
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+pfnames[i].value+'</div><!--forenames-->&nbsp;<div class="surname">'+psnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->,';
				}
			}
		}

		//Patent Jurisdiction & Number
		var pjuris = $("#pjurisdiction").val();
		var pnum = $("#pnumber").val();
		
		if(pjuris==''){
			var pjurisres = '';
		}else{
			var pjurisres = pjuris+' Patent <div class="patentNum" jurisdiction="'+pjuris+'"';
		}

		pnum = pjurisres + ' number="'+pnum+'">'+pnum + '</div><!--patentNum-->';
		
		//Pub Year
		var ppubyear = $("#ppubyear").val();
		if(ppubyear==''){
			var ppubyearres = '';
		}else{
			var ppubyearres = '(<div class="pubYear" year="'+ppubyear+'">'+ppubyear+'</div><!--pubYear-->).';
		}

		var finalpatentCit ='<div class="bib" id="patcit"><div class="patentCit">'+authorname+pnum+ppubyearres+'</div><!--otherCit--></div><!--bib-->&nbsp;';
		closePopup();

		tinyMCE.execCommand('mceInsertContent', false, finalpatentCit);
	}
	else if(type == 'prtype'){
		//Author's Forename & Surname
		var prfnames = $("input[name^=prfname]").serializeArray();
		var prsnames = $("input[name^=prsname]").serializeArray();
		if(prfnames[0].value == ''){
			authorname='';			
		} else {
			authorname='';
			for(i=0;i<prfnames.length;i++){
				var cnt = prfnames.length;
				if(i== cnt){
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+prfnames[i].value+'</div><!--forenames--><div class="surname">'+prsnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->.';
				} else if(i== cnt-1 && cnt !=1){
					authorname +=' and <div class="author">';
					authorname +='<div class="forenames">'+prfnames[i].value+'</div><!--forenames--><div class="surname">'+prsnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->';
				} else {
					authorname +='<div class="author">';
					authorname +='<div class="forenames">'+prfnames[i].value+'</div><!--forenames--><div class="surname">'+prsnames[i].value+'</div><!--surname-->';
					authorname +='</div><!--author-->,';
				}
			}
		}
		//Editor's Forename & Surame
		var prefnames = $("input[name^=prefname]").serializeArray();
		var presnames = $("input[name^=presname]").serializeArray();
		if(prefnames[0].value == ''){
			editorname='';			
		} else {
			editorname ='';
			for(j=0;j<prefnames.length;j++){
				var cnte = prefnames.length;
				if(j== cnte){
					editorname +='<div class="editor">';
					editorname +='<div class="forenames">'+prefnames[j].value+'</div><!--forenames--><div class="surname">'+presnames[j].value+'</div><!--surname-->';	
					editorname +='</div><!--editor-->.';
				} else if(j== cnte-1 && cnte !=1){
					editorname +=' and <div class="editor">';
					editorname +='<div class="forenames">'+prefnames[j].value+'</div><!--forenames--><div class="surname">'+presnames[j].value+'</div><!--surname-->';	
					editorname +='</div><!--editor-->';
				} else {				
					editorname +='<div class="editor">';
					editorname +='<div class="forenames">'+prefnames[j].value+'</div><!--forenames--><div class="surname">'+presnames[j].value+'</div><!--surname-->';	
					editorname +='</div><!--editor-->,';
				}
			}			
		}
		//article title
		var prarticletit = $("#prartitletit").val();
		if(prarticletit==''){
			var prarticletitres = '';
		}else{
			var prarticletitres = '<div class="articleTitle">'+prarticletit+'</div><!--articleTitle-->,';
		}

		//chapter name
		var prchapname = $("#prchapname").val();
		if(prchapname == ''){
			var prchapnameres = '';
		}else{
			var prchapnameres = '<div class="chapterName">'+prchapname+'</div><!--chapterName-->,';
		}

		//Publisher Name
		var prpubname = $("#prpubname").val();		
		if(prpubname==''){
			var prpubnameres = '';
		}else{
			var prpubnameres = '<div class="publisherName">'+prpubname+'</div><!--publisherName-->,';
		}
		//Publisher Loc
		var prpubloc = $("#prpubloc").val();		
		if(prpubloc==''){
			var prpublocres = '';
		}else{
			var prpublocres = '<div class="publisherLoc">'+prpubloc+'</div><!--publisherLoc-->,';
		}
		//First Page
		var prfpage = $("#prfpage").val();		
		if(prfpage==''){
			var prfpageres = '';
		}else{
			var prfpageres = '<div class="firstPage">'+prfpage+'</div><!--firstPage-->';
		}
		//Last Page
		var prlpage = $("#prlpage").val();		
		if(prlpage==''){
			var prlpageres = '';
		}else{
			var prlpageres = '<div class="lastPage">'+prlpage+'</div><!--lastPage-->,';
		}
		//Pub Year
		var prpubyear = $("#prpubyear").val();
		if(prpubyear==''){
			var prpubyearres = '';
		}else{
			var prpubyearres = '(<div class="pubYear" year="'+prpubyear+'">'+prpubyear+'</div><!--pubYear-->).';
		}
		var finalProceedingCit ='<div class="bib" id="book"><div class="proceedingsCit">'+authorname+editorname+prarticletitres+prchapnameres+prpubnameres+prpublocres+prfpageres+prlpageres+prpubyearres+'</div><!--proceedingsCit--></div><!--bib-->&nbsp;';
		closePopup();
		tinyMCE.execCommand('mceInsertContent', false, finalProceedingCit);
	}


	//End of Else
			//tinyMCE.execInstanceCommand('abb',"mceInsertContent",false,data);	
}//End of Bib Function
//validation
function jrnls(type){
	var jfname = sendValidate("input", "jfname");
	var jlname = sendValidate("input", "jlname");
	var journal = sendValidate("input", "journaltit");
	var issue = sendValidate("input", "issue");
	if(jfname != "validation_error" && jlname != "validation_error" && journal != "validation_error" && issue != "validation_error") {
		//alert("success");
		addb(type);
	}
	return false;
}
function booker(type){
	var getauthVal = $("#baddMore").css("display");
	var geteditVal = $("#beaddMore").css("display");
	if(getauthVal != 'none'){			
		var bfname = sendValidate("input", "bfname");
		var blname = sendValidate("input", "bsname");
	}
	if(geteditVal != 'none'){			
		var befname =  sendValidate("input", "befname");
		var besname =  sendValidate("input", "besname");
	}
	var bookTitle = sendValidate("input", "booktit");
	var publishname = sendValidate("input", "pubname");
	var publishloc = sendValidate("input", "publoc");
	if(bfname != "validation_error" && blname != "validation_error"  && befname != "validation_error" && besname != "validation_error" &&bookTitle != "validation_error" && publishname != "validation_error" && publishloc != "validation_error"
	   ) {
		addb(type);
	}
	return false;
}
function epath(type){
	addb(type);
}
function othercit(type){
	addb(type);
}
function patentcit(type){
	addb(type);
}
function proceeding(type){
	addb(type);
}
function sendValidate(input_type, input_name, error_text) {
	if ($(input_type + "[name^=" + input_name + "]").val() == "") {
	$(input_type + "[name^=" + input_name + "]").css({
				'border': '1px dashed #FF3F3F',
				"background": "#FAEBE7"
	});
		return "validation_error";
	}
	else {
	$(input_type + "[name^=" + input_name + "]").css({
			'border': '1px solid #8C8C8C',
				"background": "#F7F7F7"
	});
	}
}
/* Title */
function title(){
	var title = $('#abb_ifr').contents().find('#h1title').html();
	if(title == null){
	title = '';
	status = 0;
	}
	else{
	status = 1;	
	}
	var txt = '<label class="signinhead" style="margin-bottom:30px">Add Title</label><form id="pub" name="pub" method="post">';
	txt+= '<span><input type="text" name="htitle" id="htitle" value="'+title+'" style="width:350px;height:24px;margin-left:120px"/>';
	txt+= '<input style="margin-left:10px;" type="button" id="sbut" name="sbut" value="Add" onclick="return titleData(\''+status+'\');"/></span><br><br></form></div>';
	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}
function titleData(status){
	var htitle = sendValidate("input", "htitle");
	if(htitle != "validation_error"){
	data =  $("#htitle").val();
	if(status == 0){
	data = "<h1 id='h1title' class='jour_title'>"+data+"</h1>";
			tinyMCE.execInstanceCommand('abb',"mceInsertContent",false,data);			
	}
	else{
	$('#abb_ifr').contents().find('#h1title').html(data);
	}
		closePopup();
	}
}
/*Abtract*/
function abstract(){
	var abstract = $('#abb_ifr').contents().find('#abstract').html();
	if(abstract == null){
	abstract = '';
	status = 0;
	}
	else{
	status = 1;	
	}
	var txt = '<label class="signinhead" style="margin-bottom:30px">Add an Abstract</label><form id="pub" name="pub" method="post">';
	txt+='<span><textarea name="habstract" id="habstract" style="width:550px;height:200px;margin-left:60px">'+abstract+'</textarea></span><br><br>';
	txt+='<input style="float:right;margin-right:120px" type="button" id="sbut" name="sbut" value="Add" onclick="return abstData(\''+status+'\');"/><br><br></form></div>';
	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}
function abstData(status){
	var habstract = sendValidate("textarea", "habstract");
	if(habstract != "validation_error"){
	data =  $("#habstract").val();
	if(status == 0){
	data = "<span id='abstract' class='abs'>"+data+"</span>";
		tinyMCE.execInstanceCommand('abb',"mceInsertContent",false,data);			
	}
	else{
		$('#abb_ifr').contents().find('#abstract').html(data);
	}
	closePopup();
	}
}
/*keywords*/
function keywords(){	
	var keywords = $('#abb_ifr').contents().find('#keywords').html();
	if(keywords == null){
	keywords = '';
	status = 0;
	}
	else{
	status = 1;	
	}
	var txt = '<label class="signinhead" style="margin-bottom:30px">Add Keywords</label><form id="pub" name="pub" method="post">';
	txt+='<span><textarea name="hkeyword" id="hkeyword" style="width:550px;height:200px;margin-left:60px">'+keywords+'</textarea></span><br><br>';
	txt+='<input style="float:right;margin-right:120px" type="button" id="sbut" name="sbut" value="Add" onclick="return keyData(\''+status+'\');"/><br><br></form></div>';
	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}
function keyData(status){
	var hkeyword = sendValidate("textarea", "hkeyword");
	if(hkeyword != "validation_error"){
	data =  $("#hkeyword").val();
	if(status == 0){
		data = "<span class='keywords'><span class='bold'>Keywords:  </span><span id='keywords'>"+data+"</span></span><br><br>";
			tinyMCE.execInstanceCommand('abb',"mceInsertContent",false,data);			
	}
	else{
	$('#abb_ifr').contents().find('#keywords').html(data);
	}
		closePopup();
	}
}

/*Acknowledgment*/
function ack(){	
		var acknowlege = $('#abb_ifr').contents().find('#acknowlege').html();
		if(acknowlege == null){
		acknowlege = '';
		status = 0;
		}
		else{
		status = 1;	
		}
	var txt = '<label class="signinhead" style="margin-bottom:30px">Acknowledgments</label><form id="pub" name="pub" method="post">';
	txt+='<span><textarea name="ack" id="ack" style="width:550px;height:200px;margin-left:60px">'+acknowlege+'</textarea></span><br><br>';
	txt+='<input style="float:right;margin-right:120px" type="button" id="sbut" name="sbut" value="Add" onclick="return ackData(\''+status+'\');"/><br><br></form></div>';
	popUp();
	
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}
function ackData(status){
	var ack = sendValidate("textarea", "ack");
	if(ack != "validation_error"){
	data =  $("#ack").val();
	if(status == 0){
	data = "<span id='acknowlege'>"+data+"</span>";
			tinyMCE.execInstanceCommand('abb',"mceInsertContent",false,data);			
	}
	else{
	$('#abb_ifr').contents().find('#acknowlege').html(data);
	}
	closePopup();
	}
}
/* Authors */
function authors(){
	var txt = '<label class="signinhead" style="margin-bottom:30px">Affiliations</label><form id="pub" name="pub" method="post">';
	txt+= '<span><label style="margin-left:20px;"><strong>Department:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="dept" name="dept"/>&nbsp;&nbsp;<strong style="margin-right:11px">Institute:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="isnt" name="isnt"/></span><br><br>';
	txt+= '<span><label style="margin-left:20px;margin-right:52px;"><strong>City:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="city" name="city">&nbsp;&nbsp;<strong style="margin-right:33px;">State:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="state" name="state"/></span><br><br>';
	txt+= '<span><label style="margin-left:20px;margin-right:25px;"><strong>Country:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="country" name="country"/>&nbsp;&nbsp;<strong style="margin-right:13px;">Zip Code:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="zip" name="zip"/></span><br><br>';
	txt+= '<span><label style="margin-left:20px;margin-right:56px;"><strong>Tel:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="tel" name="tel"/>&nbsp;&nbsp;<strong style="margin-right:32px;margin-left:12px">Fax:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="fax" name="fax"/></span><br><br>';
	txt+= '<label class="signinhead" style="margin-bottom:30px">Author Name</label><form id="pub" name="pub" method="post">';
	txt+= '<span id="addMore"><label style="margin-left:20px;margin-right:5px"><strong>First Name:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="jfname" name="jfname[]"/>&nbsp;&nbsp;<strong>Last Name:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="jlname" name="jlname[]"/><a style="text-decoration:none;margin-left:10px" href="javascript:addAuth();">Add More +</a></span><br><br>';
	txt+= '<input style="margin-right:10px;float:right;" type="button" id="sbut" name="sbut" value="Submit" onclick="return authorData();"/><br><br></form></div>';
	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
}
jcount =0;
function addAuth(){
	jcount++;
	if(jcount<=4){
		$("#addMore").append('<label style="margin-left:20px;margin-right:9px"><br /><br><strong style="margin-left:16px;">First Name:&nbsp;&nbsp;</strong></label><input style="width:200px" type="text" id="jfname" name="jfname[]"/>&nbsp;&nbsp;<strong style="margin-right:8px">Last Name:&nbsp;&nbsp;</strong><input style="width:200px" type="text" id="jlname" name="jlname[]"/>');
	}
}

/*pubmed searh */
function pubMed(){	
		var txt = '<label class="signinhead" style="margin-bottom:30px">Search</label><form id="pub" name="pub" method="post"><span><input type="text" name="search" id="search" style="width:350px;height:24px;margin-left:120px"/><input style="margin-left:10px;" type="button" id="sbut" name="sbut" value="Search" onclick="return searchData();"/></span><br><br></form><br><br></form></div>';
		popUp();
		$("#popup_content").html("");
		$("#popup_content").html(txt);
}
function searchData(){
	var pubmed = sendValidate("input", "search");
	if(pubmed != "validation_error"){
	vals = $("#pub").serialize();
	$.ajax({
		type: "get",
		url: "search.php?"+vals,
		success: function(data){
				alert(data);
			}
		});
		}
}
//function for youtube video api
function youtube(){	
	$("#popup").css({
		"width" : 920,
	});	
	var ytube = '<iframe id="ytube" src="YouTubeVideoApp/index.php" width="100%" height="600px" frameborder="0"></iframe>'
		popUp();
	$("#popup_content").html("");
	$("#popup_content").html(ytube)
}
//function for wikipedia api
function mediaWiki(){	
	$("#popup").css({
		"width" : 920,
	});	
		//var wiki = '<iframe id="ytube" src="mediaWiki/textWiki.php" width="100%" height="600px" frameborder="0"></iframe>'
		//var wiki = '<iframe id="ytube" src="mediaWiki/searchWiki.php" width="100%" height="600px" frameborder="0"></iframe>'
		var wiki = '<iframe id="iwiki" src="mediaWiki/cross.php" width="100%" height="500px" frameborder="0" style="overflow-y: hidden;"></iframe>';
		popUp();
	$("#popup_content").html("");
	$("#popup_content").html(wiki)
}

//function for crossRef api
function crossRef(){	
	$("#popup").css({
		"width" : 920,
	});	
		var crossRef = '<iframe id="ytube" src="crossRef/fetch.php" width="100%" height="600px" frameborder="0"></iframe>'
		popUp();
	$("#popup_content").html("");
	$("#popup_content").html(crossRef)
}

// function for CrossRef
function wCrossRef(){
	$("#popup").css({
		"width" : 720,
	});	
	var txt = '<br /><div style="font:bold 15px arial;text-decoration:underline;margin-left:20px;">Cross-reference<br /><br /><br /></div>';
	
	// choosing cross reference type
	txt+= '<div style="margin-left:20px;"><input type="radio" id="type1" name="type" value="inside" checked>  Within Article &nbsp;&nbsp;&nbsp;&nbsp;';
	txt+= '<input type="radio" id="type2" name="type" value="outside">  Other Article </div><br>';
	
	// within article
	txt+= '<div id="artType1"><div style="margin-left:20px;">Reference Type :&nbsp;&nbsp;<select id="refer" style="width:150px" onchange="refType();">';
	txt+= ' <option value="">-- Select --</option>';
	txt+= '<option value="heading">Heading</option><option value="Numbered Item">Numbered Item</option></select></div><br>';
	txt+= '<div id="out" style="margin-left:20px;display:none;"><br><br>For which <span id="selVal"></span>:<select id="put" type="multiple" size="15" style="width:620px"></select><br /><br />';
	txt+= '<input id="insert" type="button" value="Insert" name="insert" style="float:right;margin-right:40px;margin-bottom:20px;display:none;" onclick="crossInsert();"/></div></div>';

	//outside article
	txt+= '<div id="artType2" style="display:none;"><div style="margin-left:20px;">Choose an Article :&nbsp;&nbsp;';
	txt+= '<select id="article" style="width:250px"">';
	txt+= '</select><input type="button" value="Add this Article" name="Add Article" style="margin-left:15px;" onClick="otherArticle();"/><br><br><br><br></div>';	
	popUp();
	$("#popup_content").html("");
	$("#popup_content").html(txt);
	
	$('input:radio[name=type]').click(function() {
		var val = $('input:radio[name=type]:checked').val();
		if(val == "outside"){
			$("#artType1").css('display','none');
			$("#artType2").css('display','block');
			jobId = $("#jobId").val();
			$.ajax({
				type: "post",
				url: "fetchArticles.php?jobid="+jobId,
				success: function(data){
						$("#article").html(data);
					}
				});
		}
		else {
			$("#artType1").css('display','block');
			$("#artType2").css('display','none');
		}
	});
		$("#put").click(function() {
			$("#insert").css('display','block');
		});
		

}
//function for cross ref for other article 
function otherArticle(){
	article_no = $("#article option:selected").val();
	article_name = $("#article option:selected").html();
	closePopup();
	tinyMCE.execCommand('mceInsertContent',false,'<!--OCRStart--><label id="'+article_no+'" style="font:bold italic 14px verdana;">'+article_name+'</label><!--OCREnd-->');			
}
	
function refType(){
	var sel = $("#refer option:selected").val();
	if (sel ==""){
		$('#out').css('display','none');
	}
	else {
		$("#selVal").html(sel);
		$('#out').css('display','block');
		// Reference type : heading
		if(sel == "heading"){
			var c1 = parseInt($('#c1').val()) +1;
			$('#c1').val(c1);
			var counter = 1;

			$('#abb_ifr_ifr').contents().find('.title').each(function(index) {
				var sectionId = $(this).closest("div").attr("id");		
				//creating reference tag
				var item_html = $(this).html();
				item_html = item_html.replace(/<\/?[^>]+>/gi, '');
				
				getVal = $(this.parentNode).attr("id");
				
				title = $(this).html();
				$(this).html('<!--ICT--><a name="crossRef-'+counter+'" id="'+sectionId+'">'+ item_html + '</a><!--ICT-->');
				
				var myOptions = {
					index : item_html,
				};
				$.each(myOptions, function(index, text) {
				//creating option list
					if(text != "References"){
						$('#put').append(
							$('<option id="'+sectionId+'"></option>').val('crossRef-'+counter).html(text)
						);
					}
				counter++;
				});
				});
		}
		// Reference type : Numbered item
		else if(sel == "Numbered Item"){
			$('#put').html("");
			var c2 = parseInt($('#c2').val()) +1;
			$('#c2').val(c2);
			var counter = 1;

				//creating reference tag
				$('#abb_ifr_ifr').contents().find('ol li').each(function(index) {
 				if($('#c2').val()==1)
					$(this).html('<a name="crossRef-0'+counter+'">'+ $(this).html() + '</a>');
				var myOptions = {
					index : $(this).html(),
				};
				
				//creating option list
				$.each(myOptions, function(index, text) {
						$('#put').append(
							$('<option></option>').val('crossRef-0'+counter).html(text)
						);
				counter++;
				});
				});
		}
	}
}
function crossInsert(){
	sel_val = $("#put option:selected").val();
	sectionId = $("#put option:selected").attr("id");
	closePopup();
	tinyMCE.execCommand('mceInsertContent',false,'<!--ICR--><a href="#'+sel_val+'" id="'+sectionId+'">'+sel_val+'</a><!--ICR-->');			
}
// function for CrossRef ends here
counter = 1;
cid =1;
sec =1;
function container(type){
	var elm = tinyMCE.activeEditor.dom.getParent(tinyMCE.activeEditor.selection.getNode(), 'div[name="section"],div[name="subsection"]');
	var eleName = tinyMCE.activeEditor.dom.getAttrib(elm, 'name');	
	var prevDepth = parseInt(tinyMCE.activeEditor.dom.getAttrib(elm, 'depth'));
	var prevId = tinyMCE.activeEditor.dom.getAttrib(elm, 'id');
	if(type == 'section'){
		if(eleName == ""){	
			tinyMCE.execCommand('mceInsertContent',false,'<div name="section" id="sec-'+ sec +'.0" depth="0" class="sect1"><button class="closebutton" id="sec-'+ sec +'.0"></button><div class="p">&nbsp;</div><!--p--></div><!--sect1--><br>&nbsp;');
			tinyMCE.activeEditor.selection.getNode()
			sec++;
		}
		else if(eleName == 'section' || eleName == 'subsection'){
			tinyMCE.activeEditor.controlManager.setDisabled('section', true);
		}
	}
	if(type == 'subsection'){
			if(eleName == "section" || eleName == 'subsection'){	
					curMinus = (counter-1);
					if(prevDepth == curMinus){
						tinyMCE.execCommand('mceInsertContent',false,'<br>&nbsp;<div name="subsection" id="'+ prevId +'.'+ cid +'" depth="'+counter+'"  class="sect'+(counter+1)+'"><button class="closebutton" id="'+cid+'"></button><div class="p">&nbsp;</div><!--p--></div><!--sect'+(counter+1)+'-->');
							if(counter == 6){
								tinyMCE.activeEditor.controlManager.setDisabled('subsection', true);
								alert("You have reached the Maximum Subsection Limit");
							}		
						counter++;
						cid++;
					}
					else {
						if(prevDepth == 0){
							tinyMCE.execCommand('mceInsertContent',false,'<br>&nbsp;<div name="subsection" id="'+ prevId +'.'+ cid +'" depth="1" class="sect2"><button class="closebutton" id="'+cid+'"></button><div class="p">&nbsp;</div><!--p--></div><!--sect2-->');
						}
						else{
							tinyMCE.execCommand('mceInsertContent',false,'<br>&nbsp;<div name="subsection" id="'+ prevId +'.'+ cid +'" depth="'+(prevDepth+1)+'" class="sect'+(prevDepth+2)+'"><button class="closebutton" id="'+cid+'"></button><div class="p">&nbsp;</div><!--p--></div><!--sect'+(counter)+'--><br>&nbsp;');
							cid++;
						}
					}	
								
				}
			else {
					tinyMCE.activeEditor.controlManager.setDisabled('subsection', true);
			}
	}
	
}

tab =1;
function addTable(get){
	//alert(get);
		tinyMCE.execCommand('mceInsertContent',false,'<!--Start Table--><div class="tabular" id="'+get+'-'+ tab +'.0" >&nbsp;</div><!--tabular--><!--End Table-->');
			tinyMCE.activeEditor.selection.getNode();
			tab++;
}
//var clicks = 0;
function styler(el){
	  alert(clicks);
	//tinyMCE.activeEditor.selection.getNode().unwrap();    
	//alert(tinyMCE.activeEditor.selection.getContent({format : 'text'}));
    /*    clicks++;
          setTimeout(function() {
	  if(el == 'nostyle'){
	
            if(clicks == 1) {*/
					node = tinyMCE.activeEditor.selection.getNode();
					with(document.getElementById('abb_ifr_ifr').contentWindow){
					var newElement = document.createTextNode(node.innerHTML);
			//	  }
				  	node.parentNode.replaceChild(newElement, node);
         //   } else {
			//	tinyMCE.activeEditor.selection.setContent(tinyMCE.activeEditor.selection.getContent({format : 'text'}));
         //   }
  }
    // clicks = 0;
     //     }, 300);
  if(el == 'rmv'){
	  var selectedHTML = tinyMCE.activeEditor.selection.getNode().nodeName;
	  if(selectedHTML == 'IMG'){
		    tinyMCE.activeEditor.selection.setContent('');
		 // tinyMCE.activeEditor.dom.remove(tinyMCE.activeEditor.selection.getNode());
	  }
  }

  if(el == 'title'){
  tinyMCE.activeEditor.selection.setContent('<span class="title">' + tinyMCE.activeEditor.selection.getContent() + '</span>');
  }
  else if(el == 'chemName'){
  tinyMCE.activeEditor.selection.setContent('<div class="chemName">' + tinyMCE.activeEditor.selection.getContent() + '</div>');
  }
  else if(el == 'chemFormula'){
  tinyMCE.activeEditor.selection.setContent('<div class="chemFormula">' + tinyMCE.activeEditor.selection.getContent() + '</div>');
  }
  else if(el == 'huc'){
  tinyMCE.activeEditor.selection.setContent('<div class="huc">' + tinyMCE.activeEditor.selection.getContent() + '</div>');
  }
  else if(el == 'hlc'){
  tinyMCE.activeEditor.selection.setContent('<div class="hlc">' + tinyMCE.activeEditor.selection.getContent() + '</div>');
  }
  else if(el == 'hi'){
  tinyMCE.activeEditor.selection.setContent('<div class="hi">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--hi-->');
  }
  else if(el == 'termdef'){
  tinyMCE.activeEditor.selection.setContent('<div class="termdef">' + tinyMCE.activeEditor.selection.getContent() + '</div>');
  }
  else if(el == 'genusSpecies'){
	  tinyMCE.activeEditor.selection.setContent('<div class="genusSpecies">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--genusSpecies-->');
  }
  else if(el == 'email'){
	  tinyMCE.activeEditor.selection.setContent('<div class="email">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--email-->');
  }
  else if(el == 'forenames'){
	  tinyMCE.activeEditor.selection.setContent('<div class="forenames">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--forenames-->');
  }
  else if(el == 'surname'){
	  tinyMCE.activeEditor.selection.setContent('<div class="surname">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--surname-->');
  }
  else if(el == 'bookTitle'){
	  tinyMCE.activeEditor.selection.setContent('<div class="bookTitle">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--bookTitle-->');
  }
  else if(el == 'vol'){
	  tinyMCE.activeEditor.selection.setContent('<div class="vol">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--vol-->');
  }
  else if(el == 'publisherName'){
	  tinyMCE.activeEditor.selection.setContent('<div class="publisherName">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--publisherName-->');
  }
  else if(el == 'publisherLoc'){
	  tinyMCE.activeEditor.selection.setContent('<div class="publisherLoc">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--publisherLoc-->');
  }
  else if(el == 'firstPage'){
	  tinyMCE.activeEditor.selection.setContent('<div class="firstPage">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--firstPage-->');
  }
  else if(el == 'lastPage'){
	  tinyMCE.activeEditor.selection.setContent('<div class="lastPage">' + tinyMCE.activeEditor.selection.getContent() + '</div><!--lastPage-->');
  }
  // for word AT STYLES
}
function atStyles(el){
	//alert(el);
	  if(el == 'rmv'){
	  var selectedHTML = tinyMCE.activeEditor.selection.getNode().nodeName;
	  if(selectedHTML == 'IMG'){
		    tinyMCE.activeEditor.selection.setContent('');
		 // tinyMCE.activeEditor.dom.remove(tinyMCE.activeEditor.selection.getNode());
	  }
	  }
		else {
		  tinyMCE.activeEditor.selection.setContent('<span class="'+el+'">' + tinyMCE.activeEditor.selection.getContent() + '</span>');
		}
}
