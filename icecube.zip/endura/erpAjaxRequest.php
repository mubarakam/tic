<?php
if($_REQUEST['req'] == "addtemperature")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addpressure")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addtime")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addweight")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "adddensity")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addhardness")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}
?>