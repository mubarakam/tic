<?php
session_start();
ob_start();
include("config.php");
include("includes/classes/employeeClass.php");
echo "<pre>";
print_r($_REQUEST);

$eid = $_REQUEST['eid'];
$ename = $_REQUEST['ename'];
$fname = $_REQUEST['fname'];
$roleID = $_REQUEST['role'];
$genderID = $_REQUEST['gender'];
$bloodgrpID = $_REQUEST['bloodgrp'];
$martialID = $_REQUEST['martial'];
$dob = $_REQUEST['dob'];
$doj = $_REQUEST['doj'];
$dow = $_REQUEST['dow'];
$empTypeID = $_REQUEST['emptype'];
$address = $_REQUEST['addr'];
$contnum = $_REQUEST['contnum'];
$activeflag = $_REQUEST['activeflag'];

$newdoj = date('Y-m-d', strtotime($_REQUEST['doj']));
$newdob = date('Y-m-d', strtotime($_REQUEST['dob']));
$newdow = date('Y-m-d', strtotime($_REQUEST['dow']));

$emp = new employeeClass();

if($_REQUEST['mode'] == 'add')
{
	$emp->addEmployee($ename, $fname, $roleID, $genderID, $bloodgrpID, $martialID, $newdob, $newdoj, $newdow, $empTypeID, $address, $contnum);
}
if($_REQUEST['mode'] == 'edit')
{
	$emp->updateEmployee($eid, $ename, $fname, $roleID, $genderID, $bloodgrpID, $martialID, $newdob, $newdoj, $newdow, $empTypeID, $address, $contnum, $activeflag);
}
?>