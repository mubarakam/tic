<?php session_start();
ob_start();
date_default_timezone_set('Asia/Calcutta');
 //include('config_wfp.php'); 
 include('config.php'); 

include('class/aclClass.php');
include('class/encode.php');
//include("const_link.php"); 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> :: CRESCENT apps :: </title>
<!--<link rel="short icon" href="images/favicon.ico"/>-->
<link rel="stylesheet" type="text/css" href="css/xpub.css" />
<link rel="stylesheet" type="text/css" href="css/erp.css" />
<link rel="stylesheet" type="text/css" href="css/impromptu.css"/>
<link rel="stylesheet" href="css/myaccount.css" type="text/css"/>	
<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/popup.js"></script>
<link href="css/jquery.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/jquery_003.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/jquery_002.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/ui.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/portlet.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/jquery_004.css" media="screen" rel="stylesheet" type="text/css">
<link href="css/jquery_005.css" media="screen" rel="stylesheet" type="text/css" class="uicolor">
<script type="text/javascript" src="script/jquery.dataTables.js"></script>
<script type="text/javascript" src="script/global.js"></script>
<link href="css/jquery.datepick.css" media="screen" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jquery.datepick.js"></script>
<script type="text/javascript" src="js/jquery.datepick.ext.js"></script>
<link rel="stylesheet" href="css/tipsy.css" type="text/css" />
<script type="text/javascript" src="js/jquery.tipsy.js"></script>
<script type="text/javascript" src="script/jquery.chosen.min.js"></script> 
<script type="text/javascript" src="script/jquery-ui.min.js"></script> 
<?php
extract($_REQUEST);
//print_r($_SESSION);
?>
<script type="text/javascript">
jQuery(document).ready(function(){
	
	<?php
	if($_REQUEST['info'] == "nouser" && $_SESSION['info1'] =="")
	{ $_SESSION['info1'] = "nouser";
	
	?>
	alert('There is no SSO username for you. In that case you are not able to authenicate folder and you are not able to checkout. Please contact admin!!!')
	
	<?php } ?>
	<?php
	if($_REQUEST['info'] =="nexttimeuse" && $_SESSION['info1'] =="")
	{$_SESSION['info1'] = "nexttimeuse";
	
	?>
	alert("Next time please use SSO login credentials. \nYour SSO login id is : <?php echo $_SESSION['sso_user_id'];?>");
	<?php } ?>
	
//---------Left Navigation hide/view------------
			jQuery(".left-collapse-icon a img").click(function(){
				jQuery(".left-nav").toggleClass("active");
				jQuery(".dashlet-panel").toggleClass("active");				
				
			});
			// message box
			$('.msg_success').delay(5000).fadeOut();
			$('.msg_error').delay(5000).fadeOut();
			
	});
	
	
</script>

<script type="text/javascript" src="highslide/highslide-full.js"></script>
<link rel="stylesheet" type="text/css" href="highslide/highslide.css" />
<script type="text/javascript">
hs.graphicsDir = 'highslide/graphics/';
hs.outlineType = 'rounded-white';
hs.wrapperClassName = 'draggable-header';
hs.dimmingOpacity = 0.75;
hs.align = 'center';
hs.enableKeyListener = false; /*  Press ESC key it will be stay on page */
hs.onDimmerClick=function(){ /* It is not allowed to close or click outside */
return false;
}
 </script>
 </head>
 <body>
 <!-- <div class="top_left_ribbon"><img src="images/beta_ribbon.png" alt="beta"></div>-->