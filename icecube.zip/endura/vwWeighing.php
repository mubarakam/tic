<?php
include('meta_script_link.php');?>
<div class="main-container">
	<?php include('includes/header.php');?>
<!-- Bread-Crumb Starts -->
<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="#">Pre-Production</a>&nbsp;&raquo;&nbsp;Weighing</div>
	<div class="msg_wrap">
    <?php 
   if($_SESSION['prcmsg'] == 'dones')
        {?>
        <div class="msg_success">
           Product Created Successfully !!
        </div>
	<?php }	
        if($_SESSION['prcmsg'] == 'donef')
        {?>
        <div class="msg_error">
            Product Creation Failed !!
        </div>
       	<?php }
		if($_SESSION['prcmsg'] == 'upds')
        {?>
        <div class="msg_success">
           Product Updated Successfully !!
        </div>
		<?php }	
		if($_SESSION['prcmsg'] == 'ds')
        {?>
        <div class="msg_success">
           Product deleted Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'ss')
        {?>
        <div class="msg_success">
           Setting updated Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'sf')
        {?>
        <div class="msg_success">
           Setting updation failed !!
        </div>
        <?php } ?>


        </div>
    
    <div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>

<div class="clear"></div>
<!-- Bread-Crumb Ends -->
        <div class="dashlet-panel-full">

                <div class="backlink">            
<!--                    <a href="ctrlWorkOrder.php?mode=add"><img src="images/new.png" title="Add Product" border="0" />&nbsp;New Work Order</a>-->
                </div> 
        <div class="clear"></div>
   			<div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; left: 0px; top: 0px;">				
					<div class="ui-widget-header ui-corner-top">
						<h2 class="arial12-nrml-medium-dark-gry">Weighing</h2>						
					</div>	
						 <!--<form name="listUser" action="" method="post" >	-->						
							<table cellspacing="0" cellpadding="0" border="0" width="100%" class="display" id="example">
								<thead>
									<tr>
										<th>Code</th>
                                        <th>Product</th>
										<th>Production Flow</th>
										<th>Quantity</th>
										<th>Finished Qty</th>
										<th>Pending Qty</th>
										<th>Active</th>
										<th>Action</th>															
									</tr>
								</thead>                                                    
								<tbody>
								<?php
								$i = 1;
								$workOrderList = mysql_query("SELECT DISTINCT wo.Quantity - wo.QuantityFinished QtyPending, wo.QuantityFinished, wo.ID, wo.Code, p.ProductName, wf.WorkflowName, wo.Quantity, if(wo.IsActive = 1, 'Yes', 'No') as active, if(wo.IsCompleted = 1, 'Yes', 'No') as completed, (wo.Pieces * wo.Quantity) Pieces FROM ".APP."txnworkorder wo JOIN ".APP."mstrproduct p ON p.ID = wo.ProductID JOIN ".APP."luworkflow wf ON wf.ID = wo.WorkFlowID JOIN ".APP."txnworkordersetting tws ON tws.WorkOrderID = wo.ID WHERE (wo.Quantity - wo.QuantityFinished) <> 0 ORDER BY wo.IsActive DESC");
								while($rs = mysql_fetch_array($workOrderList)){
									?>
									<tr>
										<td align="center" width="10%"><?php echo $rs['Code']; ?></td>
                                        <td width="20%"><?php echo $rs['ProductName']; ?></td>
                                        <td width="20%"><?php echo $rs['WorkflowName']; ?></td>
										<td align="center" width="10%"><?php echo $rs['Quantity']; ?></td>
										<td align="center" width="10%"><?php echo $rs['QuantityFinished']; ?></td>
										<td align="center" width="10%"><?php echo $rs['QtyPending']; ?></td>
										<td align="center" width="10%"><?php echo $rs['active']; ?></td>
										<td style="font-weight:bold" align="center" width="10%">
                                        
										<a href="ctrlWeighing.php?mode=edit&woid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a> &nbsp; 
										<!--<a onclick="javascript:if(confirm('Are you sure you want to delete?')){return true;}return false;" href="mdlProduct.php?mode=del&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/del.png" title="Delete" border="0" /> </a>-->
										</td>															
									</tr>									
								<?php $i++; } ?>								
								</tbody>
							</table>
												
			</div>
   </div>
   
   <!-- Dashlet-Panel Ends -->	
   <?php include('footer.php'); ?> 
</div>