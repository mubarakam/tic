// JavaScript Document
function ValDocDet(){
	var docimg = document.frmDocDet.docImg.value;
	var dirimg = document.frmDocDet.dirImg.value;
	docimg = Number(docimg);
	dirimg = Number(dirimg);
	if(docimg < dirimg){
		alert("Some Extra Images attached");
		return true;
	}
	else if(docimg > dirimg){
		alert("Some images missing");		
		return true;
	}
	else if(docimg == dirimg){
		return true;
	}
	
}

function ValDocup(){
	return false;
	var docUp = document.upload_file.word_file.value;
	if(docUp.length == 0){
		alert ("Upload Document");
		return false;
	}
	else {
		res = docUp.split(".");			
		if(res[1] == "xml"){
			return true;
		}
		else{ 
			alert("Upload xml Document Only");
			return false;
		}
	}
	
}

function ValDocimage(){
	var docUp = document.upload_image.word_file.value;
	if(docUp.length == 0){
		alert ("Upload Zip folder");
		return false;
	}
	else {
		res = docUp.split(".");	
		if(res[1] == "zip" || res[1] == "rar"){
			return true;
		}
		else{ 
			alert("Upload images in zip folder");
			return false;
		}
	}
	
}


//------------------Validate the Log-in Page Starts Here-----------------
function validate(username, password) {
	var user = document.getElementById(username);
	var pwd = document.getElementById(password);
	var validUser = document.getElementById('validUser')
	var validPwd = document.getElementById('validPwd')
	if(user.value == 'username' || user.value == '') {
		validPwd.style.display = 'none';
		$("#validUser").fadeTo("slow",1.25);
		validUser.style.display = 'block';
		user.focus();
		return false;
	}
	else if(pwd.value == 'password' || pwd.value == '') {
		validUser.style.display = 'none';
		$("#validPwd").fadeTo("slow",1.25);
		validPwd.style.display = 'block';
		pwd.focus();
		return false;
	}else{
		return true;
	}
}
//------------------Validate the Log-in Page Ends Here-----------------
