// JavaScript Document
	$(document).ready(function() {
		$(function() {
			$(".select").chosen();
		});
				
		
		/*$("#round").change(function(){
			var acronym = $("#acronym").val();
			var round = $("#round").val();
	        //var articleCount = $("#articlename").val;
	        			
		     $.ajax({
		        url: "wfp_status_update_data.php",
		        type: "post",
		        data: 'req=acronymDropdown&acronym='+acronym+'&round='+round,
		        								
		        success: function(data) {
					data = $.trim(data);
					if(data == 0) {
		          		$("#articlename").css({"display": "none"});
		          		$(".displayMsg").css({"border": "1px dashed red", "background": "#FAEBE7"});
		          		$("#displayMsg").show();
						//alert("Chapter Not Found");
					} else{
		          		$("#articlename").css({"display": "block"});
		          		$(".displayMsg").css({"border": "none", "background": "#FAFAFA"});
		          		$("#displayMsg").hide();
		          		$("#articlename").html(data);
		        	}
		        }
			 }); 
			
		});*/
		
	});

	function validate(){
			
	var acronym     = document.getElementById("acronym").value;
	var disType     = document.getElementById("type").value;
	
							
	if(acronym == "" ){
		$(".acronym").css({
			'border': '1px dashed #FF3F3F',
			"background": "#FAEBE7"
		});	
		return false;
	} 
	else {
		$(".acronym").css({
			'border': 'none',
			"background": "#FAFAFA"
		});
	}
		
	if (disType == 1) {		
		$("#vol").removeAttr("required");
		$("#iss").removeAttr("required");
	}
	
	if (disType == 2 ) {
	    $("#articleid").removeAttr("required");
	}
				
		

			
		
		
	
	}
	
	function typedefine() {
		
	var type = document.getElementById("type").value;
		
		if(type == '') {
			document.getElementById("type1").style.display = "none";
			document.getElementById("type2").style.display = "none";
			document.getElementById("type3").style.display = "none";
			document.getElementById("type4").style.display = "none";	
		}
		
		if(type == 1 ) {
			document.getElementById("type1").style.display = "block";
			document.getElementById("type2").style.display = "none";
			document.getElementById("type3").style.display = "block";
			document.getElementById("type4").style.display = "none";
				
		} else if (type == 2) {
			document.getElementById("type1").style.display = "none";
			document.getElementById("type2").style.display = "block";
			document.getElementById("type3").style.display = "none";
			document.getElementById("type4").style.display = "block";
		}	
	
	}
		
