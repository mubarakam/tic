//function for view log entries
function logEntryPopup(userid){

	$.ajax({
			type: "post",
			url: "popupUserLog.php?userid="+userid,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
				}
		});

}//end function


//function for Set Notification
function notificationPopup(id){

	$.ajax({
			type: "post",
			url: "notificationSetup.php?id="+id,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
				}
		});

}//end function


//function for Add/Edit Books
function currentBooksPopup(id){

	$.ajax({
			type: "post",
			url: "addEditBook.php?id="+id,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
				}
		});

}//end function


//function for Add/Edit Chapter
function chapterPopup(book_id,id){

	$.ajax({
			type: "post",
			url: "addEditChapter.php?bookid="+book_id+"&id="+id,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
				}
		});

}//end function


//function for Chapter Html View
function htmlView_Popup(chap_id){

	$.ajax({
			type: "post",
			url: "html_view.php?chap_id="+chap_id,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
				}
				
		});

}//end function


// upload function
function xcel_upload(jid){

	$.ajax({
			type: "post",
			url: "xcel_upload.php?jid="+jid,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
						
				}
		});

}//end function

//function for abstract popup
function abstractPopup(abstract){

	$.ajax({
			type: "post",
			url: "editXML.php?abstract="+abstract,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
				}
		});

}//end function

//function for getting metadata id from view chapter page
var meta = "";
function getmetadata(i)
{
	meta = document.getElementById('mid'+i).value;
}
//function end

//function for calling invite author page from view chapter page
function getcoAuthor(jbid){

	$.ajax({
			type: "post",
			url: "inviteArticle.php?list="+meta+"&jobid="+jbid,
			success: function(data){
					var txt = data;
					popUp();
						$("#popup_content").html("");
						$("#popup_content").html(txt);
						
				}
		});

}//end function

function deletechecked(message)
{
    var answer = confirm(message)
    if (answer){
        document.messages.submit();
    }
    
    return false;  
}

function invitecoAuthor(meta){

	$.ajax({
type: "post",
url: "inviteCoAuthor.php?mid="+meta,
success: function(data){
		  var txt = data;
		  popUp();
		  $("#popup_content").html("");
		  $("#popup_content").html(txt);

	  }
	});

}