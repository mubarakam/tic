<?php
 include('meta_script_link.php');
?><head>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(document).ready(function(){
document.getElementById("sbox2").focus();
	jQuery("#stageform").validate({
            rules: {
                "id": {required: true}
                         }
        });	
	});
	
var sbox_str = "";
        $(function() {
            $("#right,#left").click(function(event) {
			//alert($("#sbox2").val());
                var id = $(event.target).attr("id");
				var selectFrom = id == "right" ? "#sbox1" : "#sbox2";
                var moveTo = id == "right" ? "#sbox2" : "#sbox1";
 
                var selectedItems = $(selectFrom + " :selected").toArray(); 
				$(moveTo).append(selectedItems); 
				selectedItems.remove;

				var myOpts = new Array();	
				myOpts  = document.getElementById('sbox2').options;
				
				//alert(myOpts.length);
				//alert(myOpts[0].value+"length = "+myOpts.length); 
								
				var select_box_length = myOpts.length;
				
				var  str_val = "";
				for(var i=0; i<myOpts.length; i++) {
	//alert(myOpts[i].value);			
				if(i == 0)
						str_val += myOpts[i].value;
					else
						str_val += ","+myOpts[i].value;
				}
				
				//alert(str_val);	 

			// sbox_str +=  ","+$("#sbox2").val();
				  $(".sbox2").val(str_val);				  
				  $(".t1").val(str_val);
					
				
								
            });
        });


/////
        $(function() {
            $("#right2,#left2").click(function(event) {
			//alert($("#sbox2").val());
                var id = $(event.target).attr("id");
				var selectFrom = id == "right2" ? "#sbox3" : "#sbox4";
                var moveTo = id == "right2" ? "#sbox4" : "#sbox3";
 
                var selectedItems = $(selectFrom + " :selected").toArray(); 
				$(moveTo).append(selectedItems); 
				selectedItems.remove;

				var myOpts = new Array();	
				myOpts  = document.getElementById('sbox4').options;
				
				//alert(myOpts.length);
				//alert(myOpts[0].value+"length = "+myOpts.length); 
								
				var select_box_length = myOpts.length;
				
				var  str_val = "";
				for(var i=0; i<myOpts.length; i++) {
	//alert(myOpts[i].value);			
				if(i == 0)
						str_val += myOpts[i].value;
					else
						str_val += ","+myOpts[i].value;
				}
				
				//alert(str_val);	 

			// sbox_str +=  ","+$("#sbox2").val();
				  $(".sbox4").val(str_val);				  
				  $(".t1").val(str_val);
					
				
								
            });
        });



function listbox_move(listID, direction) {

    var listbox = document.getElementById(listID);
    var selIndex = listbox.selectedIndex;

    if(-1 == selIndex) {
        alert("Please select an option to move.");
        return;
    }
 
    var increment = -1;
    if(direction == 'up')
        increment = -1;
    else
        increment = 1;
 
    if((selIndex + increment) < 0 ||
        (selIndex + increment) > (listbox.options.length-1)) {
        return;
    }
 
    var selValue = listbox.options[selIndex].value;
    var selText = listbox.options[selIndex].text;
    listbox.options[selIndex].value = listbox.options[selIndex + increment].value
    listbox.options[selIndex].text = listbox.options[selIndex + increment].text
    	
		
    listbox.options[selIndex + increment].value = selValue;
    listbox.options[selIndex + increment].text = selText;
 
    listbox.selectedIndex = selIndex + increment;
	
	var myOpts = new Array();	
				myOpts  = document.getElementById('sbox2').options;
				//alert(myOpts[0].value+"length = "+myOpts.length); 
				
				var select_box_length = myOpts.length;
				var  str_val = "";
				for(var i=0; i<myOpts.length; i++) {
					
					if(i == 0)
						str_val += myOpts[i].value;
					else
						str_val += ","+myOpts[i].value;
				}
				
				//alert(str_val);	
				$(".sbox2").val(str_val); 
				$(".t1").val(str_val);
				

	
}

function listbox_move_edit(listID, direction) {

    var listbox = document.getElementById(listID);
    var selIndex = listbox.selectedIndex;

    if(-1 == selIndex) {
        alert("Please select an option to move.");
        return;
    }
 
    var increment = -1;
    if(direction == 'up')
        increment = -1;
    else
        increment = 1;
 
    if((selIndex + increment) < 0 ||
        (selIndex + increment) > (listbox.options.length-1)) {
        return;
    }
 
    var selValue = listbox.options[selIndex].value;
    var selText = listbox.options[selIndex].text;
    listbox.options[selIndex].value = listbox.options[selIndex + increment].value
    listbox.options[selIndex].text = listbox.options[selIndex + increment].text
    	
		
    listbox.options[selIndex + increment].value = selValue;
    listbox.options[selIndex + increment].text = selText;
 
    listbox.selectedIndex = selIndex + increment;
	
	var myOpts = new Array();	
				myOpts  = document.getElementById('sbox4').options;
				//alert(myOpts[0].value+"length = "+myOpts.length); 
				
				var select_box_length = myOpts.length;
				var  str_val = "";
				for(var i=0; i<myOpts.length; i++) {
					
					if(i == 0)
						str_val += myOpts[i].value;
					else
						str_val += ","+myOpts[i].value;
				}
				
				//alert(str_val);	
				$(".sbox4").val(str_val); 
				$(".t1").val(str_val);
}

function selectDropdown(){
        var circle=document.getElementById("eg").value;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("clusterdropdown").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","ajaxRequest.php?req=clstdrop&circle="+circle,true);
xmlhttp.send();
	   
    }

function validate(a){var val = $("#"+a).val();$.ajax({type: "post",url: "ajaxValidate.php?frm="+a+"&val="+val,success: function(data){if(data == "exist"){$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});document.getElementById('errdiv').style.display='inline';$("#addbtn").attr('disabled','true')}else if(data != "exist"){$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});document.getElementById('errdiv').style.display='none';$("#addbtn").removeAttr('disabled');}}});}
</script>

<div class="main-container">
<?php include('includes/header.php');


####### Need to declare########
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Process Flow</div>
<div class="msg_wrap">
<?php 
   if($_REQUEST['msg']=='done')
        {?>
        <div class="msg_success">
           Workflow Created Successfully !!
        </div>
	<?php }	
        if($_REQUEST['msg']=='fail')
        {?>
        <div class="msg_error">
            Workflow Creation Failed !!
        </div>
       	<?php } ?></div>
<div class="backlink">
                 <a href="vwProductionFlow.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
	
		 
        	
  		
        

 <?php
if($_REQUEST['mode'] == 'add')
{
   $wcode = mysql_query("SELECT CONCAT(`CODE`,`CurrentRange` + 1) as code from ".APP."cfgdocumenttype where `ObjectTypeId` = 5") or die(mysql_error());
   $code = mysql_fetch_array($wcode); ?>					
                    <form name="ProductionFlowform" action="mdlProductionFlow.php?mode=add" method="post" id="stageform" >
                        
                        <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Process Flow Code</td>
    <td colspan="3">
      <input style="width:60px;"  type="text"  maxlength="255" name="ProductionFlowcode" value="<?php echo $code['code']; ?>" readonly="readonly"/>
    </td>
    </tr>
  <tr>
    <td>Process Flow Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;" type="text" name="ProductionFlowname" value="<?php $workflowName ?>" id="ProductionFlowname"  required onChange="validate('ProductionFlowname');"/>
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Processflow already exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
      <textarea name="description" cols="34" rows="3"></textarea>
      </td>
  </tr>
  <tr>

    <td>Select Process<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td width="20%">
	<select id="sbox1" name="sbox1" size="10" style="width:210px; height:200px;"  multiple="multiple">
	<?php
	
	$processList = mysql_query("SELECT ID, StageName FROM ".APP."lustage WHERE IsActive = 1 AND StageType = 1 ORDER BY StageName") or die(mysql_error());
	while($pLrs = mysql_fetch_array($processList))
	{	
	?>
	<option value='<?php echo $pLrs['ID']; ?>'><?php echo $pLrs['StageName']; ?></option>
	<?php
	}
	?>
	</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" /></td>
    <td width="63%">
      <select required id="sbox2" name="sbox2" size="10" style="width:210px; height:200px;" multiple="multiple">
      </select>
</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
              
                         
				</form>
<?php			
 }
if($_REQUEST['mode'] == 'edit')
{
	$productionFlow = mysql_query("select `ID`, `Code`, `WorkflowName`,`Description` from ".APP."luworkflow where ID = ".$_REQUEST['sid']) or die(mysql_error());
	$productionFlowrs = mysql_fetch_array($productionFlow);
?>
				<form name="ProductionFlowform" action="mdlProductionFlow.php?mode=edit" method="post" id="ProductionFlowform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Process Flow Code</td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="ProductionFlowcode" value="<?php echo $productionFlowrs['Code']; ?>" readonly="readonly"/><input type="hidden" name="sid" id="sid" value="<?php echo $productionFlowrs['ID']; ?>" >
    </td>
    </tr>
  <tr>
    <td>Process Flow Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;"  type="text" name="ProductionFlowname" value="<?php echo $productionFlowrs['WorkflowName']; ?>" id="ProductionFlowname"  required onChange="validate('ProductionFlowname')" />
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Processflow already exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
     <textarea name="description" cols="36" rows="3"><?php echo $productionFlowrs['Description']; ?></textarea>
      </td>
  </tr>
  <tr>
    <td>Select Process&nbsp;<span class="validationerrornotify">&nbsp;*</span></td>
    <td width="20%">
   <select id="sbox1" name="sbox1" size="10" style="width:210px; height:200px;"  multiple="multiple">

	<?php
	
	$processList = mysql_query("SELECT ID, StageName FROM ".APP."lustage WHERE IsActive = 1 AND StageType = 1 AND NOT EXISTS (SELECT 1 FROM ".APP."txnworkflowstage WHERE txnworkflowstage.StageID = lustage.ID AND txnworkflowstage.WorkflowID = ".$_REQUEST['sid'].") ORDER BY StageName") or die(mysql_error());
	while($pLrs = mysql_fetch_array($processList))
	{	
	?>
		<option value='<?php echo $pLrs['ID']; ?>'><?php echo $pLrs['StageName']; ?></option>
		<?php }?>
		</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" /></td>
    <td width="63%">
    <select id="sbox2" required name="sbox2" size="10" style="width:210px; height:200px;" multiple="multiple" >           
	<?php
	
	$workflowStage = mysql_query("SELECT ws.StageID, s.StageName FROM ".APP."luworkflow w JOIN ".APP."txnworkflowstage ws ON ws.WorkflowID = w.ID JOIN ".APP."lustage s ON s.ID = ws.StageID WHERE w.ID = ".$_REQUEST['sid']) or die(mysql_error());
	while($wfRs = mysql_fetch_array($workflowStage))
	{
	?>
	<option value='<?php echo $wfRs['StageID']; ?>'><?php echo $wfRs['StageName']; ?></option>
	<?php
	}
	?>
	</select>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }

 if($_REQUEST['mode'] == 'set')
{
?>
	<form name="ProductionFlowformSetting" action="mdlProductionFlow.php?mode=set" method="post" id="ProductionFlowformSetting" >
<?php
	$productionFlow = mysql_query("select `ID`, `Code`, `WorkflowMasterName`,`Description` from ".APP."mstrworkflow where ID = ".$_REQUEST['sid']) or die(mysql_error());
	$productionFlowrs = mysql_fetch_array($productionFlow);
?>	
	<table width="100%" border="0" id="workflowtable">
	<tr>
	<td colspan="4" align="center"><b>Setting for </b>&nbsp;&nbsp;&nbsp;<?php echo $productionFlowrs['Code']." - ".$productionFlowrs['WorkflowMasterName']; ?></td>
	</tr>
	<tr>
	<td>Stage</td>
	<td>Machine</td>
	<td colspan="2">&nbsp;</td>
	</tr>
<?php

	$pfStage = mysql_query("SELECT ws.StageID, s.StageName, w.ID, wsm.MachineID, m.MachineName FROM ".APP."luworkflow w JOIN ".APP."txnworkflowstage ws ON ws.WorkFlowID = w.ID LEFT OUTER JOIN ".APP."txnworkflowstagemachine wsm ON wsm.WorkflowID = w.ID AND wsm.StageID = ws.StageID JOIN ".APP."lustage s ON s.ID = ws.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wsm.MachineID WHERE w.MasterID = ".$productionFlowrs['ID']." ORDER BY ws.StageSequence ASC") or die(mysql_error());
	
	while($pfStagers = mysql_fetch_array($pfStage))
	{		
?>
<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='pfStageID[]' id='pfStageID<?php echo $pfStagers['StageID']; ?>' value='<?php echo $pfStagers['StageID']; ?>' ><?php echo $pfStagers['StageName']; ?></td>
	<td><select id="machine" name="machine[]"><option value="" >--Select--</option>
	<?php
		$machine = mysql_query("SELECT ID, CONCAT(Code, ' - ', MachineName) Machine FROM ".APP."lumachine WHERE IsActive = 1 ORDER BY CONCAT(Code, ' - ', MachineName) ASC") or die(mysql_error());
		while($machiners = mysql_fetch_array($machine))
		{
			?>
			<option value="<?php echo $machiners['ID']; ?>" <?php if($machiners['ID'] == $pfStagers['MachineID']) { ?> selected <?php } ?> ><?php echo $machiners['Machine']; ?></option>
			<?php
		}
	?></select>
	</td>
	<td colspan="2"><a href="javascript:addTemp(<?php echo $pfStagers['StageID']; ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Temperature" src="images/temperature.png"/></a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>temperature">
	<tbody>
	<?php
	$temperatureQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 1") or die(mysql_error());
	
	while($temperaturers = mysql_fetch_array($temperatureQry))
	{
	?>
	<span><input type="text"  name="<?php echo $temperaturers['StageID']; ?>temperature[]" id="<?php echo $temperaturers['StageID'];?>temperature" value="<?php echo $temperaturers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>
	&nbsp;
	<a href="javascript:addPress(<?php echo $pfStagers['StageID']; ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Pressure" src="images/pressure.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>pressure">
	<tbody>
	<?php
	$pressureQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 2") or die(mysql_error());
	
	while($pressurers = mysql_fetch_array($pressureQry))
	{
	?>
	<span><input type="text"  name="<?php echo $pressurers['StageID']; ?>pressure[]" id="<?php echo $pressurers['StageID'];?>pressure" value="<?php echo $pressurers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	
	</tbody>
	</table>&nbsp;
	<a href="javascript:addTime(<?php echo $pfStagers['StageID']; ?>+'time')" id="Time" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Time" src="images/time.png"/></a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>time">
	<tbody>
	<?php
	$timeQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 4") or die(mysql_error());
	
	while($timers = mysql_fetch_array($timeQry))
	{
	?>
	<span><input type="text"  name="<?php echo $timers['StageID']; ?>time[]" id="<?php echo $timers['StageID'];?>time" value="<?php echo $timers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>
	&nbsp;
	<a href="javascript:addTime(<?php echo $pfStagers['StageID']; ?>+'weight')" id="Weight" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Weight" src="images/weight.png"/></a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>weight">
	<tbody>
	<?php
	$weightQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 3") or die(mysql_error());
	
	while($weightrs = mysql_fetch_array($weightQry))
	{
	?>
	<span><input type="text"  name="<?php echo $weightrs['StageID']; ?>weight[]" id="<?php echo $weightrs['StageID'];?>weight" value="<?php echo $weightrs['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>
&nbsp;
	<a href="javascript:addDensity(<?php echo $pfStagers['StageID']; ?>+'density')" id="Density" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Density" src="images/density.png" width="16px" height="16px"/></a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>density">
	<tbody>
	<?php
	$densityQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 5") or die(mysql_error());
	
	while($densityrs = mysql_fetch_array($densityQry))
	{
	?>
	<span><input type="text"  name="<?php echo $densityrs['StageID']; ?>density[]" id="<?php echo $densityrs['StageID'];?>density" value="<?php echo $densityrs['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>
&nbsp;
	<a href="javascript:addHardness(<?php echo $pfStagers['StageID']; ?>+'hardness')" id="Hardness" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Hardness" src="images/hardness.png" width="16px" height="16px"/></a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>hardness">
	<tbody>
	<?php
	$hardnessQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 6") or die(mysql_error());
	
	while($hardnessrs = mysql_fetch_array($hardnessQry))
	{
	?>
	<span><input type="text"  name="<?php echo $hardnessrs['StageID']; ?>hardness[]" id="<?php echo $hardnessrs['StageID'];?>hardness" value="<?php echo $hardnessrs['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>

	</td>
	<input class ="sbox2" type='hidden' name='pfWorkflowID' id='pfWorkflowID' value='<?php echo $pfStagers['ID']; ?>' >
</tr>
<?php
	}

?>

  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addstage" value="Submit" id="addstage" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }


 if($_REQUEST['mode']=='view')
 {
	
 $stage = mysql_query("select `STAGE_ID`,`CODE`,`STAGE_NAME`,`DESCRIPTION` from ".APP."stage where stage_id =".$_REQUEST['sid']) or die(mysql_error());
$sid = mysql_fetch_array($stage);
 ?>
				<form name="stageform" action="stage_store.php?mode=edit" method="post" id="stageform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Stage Code</td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="stagecode" value="<?php echo $sid['CODE']; ?>" readonly="readonly"/><input type="hidden" name="sid" id="sid" value="<?php echo $sid['STAGE_ID']; ?>" readonly >
    </td>
    </tr>
  <tr>
    <td>Stage Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="stageame" value="<?php echo $sid['STAGE_NAME']; ?>" id="stage"  required onChange="validate();" readonly/>
    <div id="roleerr" class="msg_exists" style="display:none;">&nbsp;Already Exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
     <textarea name="description" cols="36" rows="3" readonly><?php echo $sid['DESCRIPTION']; ?></textarea>
      </td>
  </tr>
  <tr>
    <td>Select Role&nbsp;<span class="validationerrornotify">&nbsp;*</span></td>
    <td width="20%">
   <select id="sbox1" name="sbox1" size="10" style="width:210px; height:200px;"  multiple="multiple" disabled="disabled">
									<?php
                                	$stage =mysql_query("select r.ID,r.NAME from ".APP."ROLE_ENUM r where not exists (select `ROLE` from ".APP."stage_role s where s.stage =".$_REQUEST['sid']." and s.role = r.ID )") or die(mysql_error());
                                	while($row = mysql_fetch_array($stage)){?>
                                	<option value='<?php echo $row['ID']; ?>'><?php echo $row['NAME']; ?></option>
                        			<?php }?>
                         			</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " disabled="disabled" />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " disabled="disabled" />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " disabled="disabled" />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" disabled="disabled" /></td>
    <td width="63%">
     <select id="sbox2" name="sbox2" size="10" style="width:210px; height:200px;" multiple="multiple" disabled="disabled" >           
                                    <?php
                                	$estage =mysql_query("select r.ID,r.NAME from ".APP."ROLE_ENUM r where exists (select `ROLE` from ".APP."stage_role s where s.stage =".$_REQUEST['sid']." and s.role = r.ID )") or die(mysql_error());
                                	while($srow = mysql_fetch_array($estage)){?>
                                	<option value='<?php echo $srow['ID']; ?>'><?php echo $srow['NAME']; ?></option>
                        			<?php }?>
                          			</select>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
     <a href="liststage.php">
        <input name="Cancel" type="button"  value="OK"/>
</a></td>
    </tr>
</table>
                         
				</form> 

<?PHP } ?>
			
	</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>