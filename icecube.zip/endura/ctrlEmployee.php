<?php
 include('meta_script_link.php');
?><head>
<input type="hidden" id="curryear" name="curryear" value="<?php echo date("y"); ?>" />
<input type="hidden" id="currmon" name="currmon" value="<?php echo date("m"); ?>" />
<input type="hidden" id="currday" name="currday" value="<?php echo date("d"); ?>" />
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
		var curYear = document.getElementById("curryear").value;
		var curMon = document.getElementById("currmon").value;
		var curDay = document.getElementById("currday").value;
		var mindat = curDay + "-" + curMon + "-" + curYear;
	
	var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	
	$(".kpress").keypress(function (e)
	{
		e.preventDefault();
	});
	$("input[aria-controls=example]").focus();
	
	jQuery(function(){
                jQuery('#dob').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
					changeYear: true,
					yearRange:"-100:+0"
				});
            })
	jQuery(function(){
                jQuery('#doj').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
					changeYear: true,
					minDate:mindat
                });
            })
	jQuery(function(){
                jQuery('#dow').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
					changeYear: true,
                    yearRange:"-100:+1"
                });
            })
		});
function validate(a){var val = $("#"+a).val();$.ajax({type: "post",url: "ajaxValidate.php?frm="+a+"&val="+val,success: function(data){if(data == "exist"){$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});document.getElementById('errdiv').style.display='inline';$("#addbtn").attr('disabled','true')}else if(data != "exist"){$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});document.getElementById('errdiv').style.display='none';$("#addbtn").removeAttr('disabled');}}});}
</script>
<div class="main-container">
<?php include('includes/header.php');
?>
<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="">HR</a>&nbsp;&raquo;&nbsp;Employee</div>
<div class="backlink"><a href="vwEmployee.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
<?php
$roleQry = mysql_query("SELECT ID, Description Role FROM ".APP."lurole WHERE IsActive = 1") or die(mysql_error());
$genderQry = mysql_query("SELECT ID, Description Gender FROM ".APP."lugender") or die(mysql_error());
$bloodQry = mysql_query("SELECT ID, Description Gender FROM ".APP."lubloodgroup") or die(mysql_error());
$martialQry = mysql_query("SELECT ID, Description MartialStatus FROM ".APP."lumartialstatus") or die(mysql_error());
$empTypeQry = mysql_query("SELECT ID, Description EmploymentType FROM ".APP."luemploymenttype") or die(mysql_error());

$empDetQry = "SELECT me.ID UserID, me.RoleID, me.EmployeeCode, me.Name, ed.GenderID, ed.MartialStatusID, ed.BloodGroupID, ed.EducationQualificationID, ed.EmploymentTypeID, ed.FatherName, ed.SpouseName, DATE_FORMAT(ed.DOB, '%d-%b-%Y') DOB, DATE_FORMAT(ed.DOJ, '%d-%b-%Y') DOJ, DATE_FORMAT(ed.DOW, '%d-%b-%Y') DOW, ed.Address, ed.ContactNumber, ed.AlternateContactNumber, ed.BankName, ed.BankAccountNumber, ed.BankBranch, ed.PFUAN, me.IsActive FROM ".APP."mstremployee me JOIN ".APP."luemployeedetail ed ON ed.ID = me.ID WHERE me.ID = ".$_REQUEST['eid'];

if($_REQUEST['mode'] == 'add')
{
?>
<form name="employeeform" action="mdlEmployee.php?mode=add" method="post" id="employeeform" >
<table width="100%" border="0" id="workflowtable">
<tr>
<td>Name</td>
<td><input type="text" id="ename" name="ename" required />
<td>Father Name</td>
<td><input type="text" id="fname" name="fname" required />
<td>Role</td>
<td>
<select id="role" name="role" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($roleQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>"><?php echo $rs['Role']; ?></option>
<?php
}
?>
</td>
</tr>

<tr>
<td>Gender</td>
<td>
<select id="gender" name="gender" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($genderQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>"><?php echo $rs['Gender']; ?></option>
<?php
}
?>
</td>
<td>Blood Group</td>
<td>
<select id="bloodgrp" name="bloodgrp" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($bloodQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>"><?php echo $rs['Gender']; ?></option>
<?php
}
?>
</td>
<td>Martial Status</td>
<td>
<select id="martial" name="martial" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($martialQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>"><?php echo $rs['MartialStatus']; ?></option>
<?php
}
?>
</td>
</tr>
<tr>
<td>Date of birth</td>
<td><input type="text" name="dob" class="kpress" style="width:100px;" id="dob" required /></td>
<td>Date of joining</td>
<td><input type="text" name="doj" class="kpress" style="width:100px;" id="doj" required /></td>
<td>Date of wedding</td>
<td><input type="text" name="dow" class="kpress" style="width:100px;" id="dow" /></td>
</tr>

<tr>
<td>Employment Type</td>
<td>
<select id="emptype" name="emptype" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($empTypeQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>"><?php echo $rs['EmploymentType']; ?></option>
<?php
}
?>
</td>
<td>Address</td>
<td><textarea name="addr" cols="34" rows="3"></textarea></td>
<td>Contact Number</td>
<td><input type="text" id="contnum" name="contnum" required onChange="validate('contnum');"/>
<div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Contact number already exists, it should be UNIQUE&nbsp;</div></td>
</tr>

<tr>
<td colspan="6" style="text-align:center;">
<input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
</td>
</tr>
</table>
<?php
}


if($_REQUEST['mode'] == 'edit')
{
	//echo $empDetQry;
	$emprs = mysql_fetch_array(mysql_query($empDetQry)) or die(mysql_error());
?>
<form name="employeeform" action="mdlEmployee.php?mode=edit" method="post" id="employeeform" >
<input type="hidden" id="eid" name="eid" required value="<?php echo $emprs['UserID'];?>" />
<table width="100%" border="0" id="workflowtable">
<tr>
<td>Code</td>
<td colspan="5"><?php echo $emprs['EmployeeCode'];?></td>
</tr>
<tr>
<td>Name</td>
<td><input type="text" id="ename" name="ename" required value="<?php echo $emprs['Name'];?>" />
<td>Father Name</td>
<td><input type="text" id="fname" name="fname" required value="<?php echo $emprs['FatherName'];?>" />
<td>Role</td>
<td>
<select id="role" name="role" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($roleQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>" <?php if($rs['ID'] == $emprs['RoleID']){ ?> selected <?php } ?> ><?php echo $rs['Role']; ?></option>
<?php
}
?>
</td>
</tr>

<tr>
<td>Gender</td>
<td>
<select id="gender" name="gender" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($genderQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>" <?php if($rs['ID'] == $emprs['GenderID']){ ?> selected <?php } ?> ><?php echo $rs['Gender']; ?></option>
<?php
}
?>
</td>
<td>Blood Group</td>
<td>
<select id="bloodgrp" name="bloodgrp" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($bloodQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>" <?php if($rs['ID'] == $emprs['BloodGroupID']){ ?> selected <?php } ?> ><?php echo $rs['Gender']; ?></option>
<?php
}
?>
</td>
<td>Martial Status</td>
<td>
<select id="martial" name="martial" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($martialQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>" <?php if($rs['ID'] == $emprs['MartialStatusID']){ ?> selected <?php } ?> ><?php echo $rs['MartialStatus']; ?></option>
<?php
}
?>
</td>
</tr>
<tr>
<td>Date of birth</td>
<td><input type="text" name="dob" class="kpress" style="width:100px;" id="dob" required value="<?php echo $emprs['DOB']; ?>" /></td>
<td>Date of joining</td>
<td><input type="text" name="doj" class="kpress" style="width:100px;" id="doj" required value="<?php echo $emprs['DOJ']; ?>" /></td>
<td>Date of wedding</td>
<td><input type="text" name="dow" class="kpress" style="width:100px;" id="dow"  value="<?php echo $emprs['DOW']; ?>" /></td>
</tr>
<tr>
<td>Employment Type</td>
<td>
<select id="emptype" name="emptype" required>
<option value="">--Select--</option>
<?php
while($rs = mysql_fetch_array($empTypeQry))
{
?>
	<option value="<?php echo $rs['ID']; ?>" <?php if($rs['ID'] == $emprs['EmploymentTypeID']){ ?> selected <?php } ?> ><?php echo $rs['EmploymentType']; ?></option>
<?php
}
?>
</td>
<td>Address</td>
<td><textarea name="addr" cols="34" rows="3"><?php echo $emprs['Address']; ?></textarea></td>
<td>Contact Number</td>
<td><input type="text" name="contnum" id="contnum" value="<?php echo $emprs['ContactNumber']; ?>" required onChange="validate('contnum');" />
<div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Contact number already exists, it should be UNIQUE&nbsp;</div>
</td>
</tr>

<tr>
<td>Active</td>
<td colspan="5">
<select id="activeflag" name="activeflag" required>
<option value="">--Select--</option>
<option value="1" <?php if($emprs['IsActive'] == 1){ ?> selected <?php } ?> >Yes</option>
<option value="0" <?php if($emprs['IsActive'] == 0){ ?> selected <?php } ?> >No</option>
</select>
</td>
</tr>

<tr>
<td colspan="6" style="text-align:center;">
<input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
</td>
</tr>
</table>
<?php
}


?>	
</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>