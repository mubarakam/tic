<?php session_start();
ob_start();
include "config.php";

if($_REQUEST['req'] == "uom")
{
?>
<input type="text" id="uomnum" name="uomnum" required />
<?php
}

if($_REQUEST['req'] == "supaddr")
{
?>
<?php
$stdQry = "SELECT Address FROM ".APP."mstrsupplier WHERE ID = ".$_REQUEST['sup'];
$stdExe = mysql_query($stdQry) or die(mysql_error());
while($stdRS = mysql_fetch_array($stdExe))
{
?>
<textarea name="address" required ><?php echo $stdRS['Address']; ?></textarea>
<?php
}

}

if($_REQUEST['req'] == "pf")
{
?>
<select id="standard" name="standard" required >
<option selected="selected" value="">--Select--</option>
<?php
$stdQry = "SELECT * FROM ".APP."mstrstandard WHERE WorkflowID = ".$_REQUEST['pf'];
$stdExe = mysql_query($stdQry) or die(mysql_error());
while($stdRS = mysql_fetch_array($stdExe))
{
?>
<option value="<?php echo $stdRS['ID']; ?>"><?php echo $stdRS['Code']." - ".$stdRS['Name']; ?></option>
<?php
}
?>
</select>
<?php
}

if($_REQUEST['req'] == "rbk")
{
?>
<select id="rollback" name="rollback" required >
<option selected="selected" value="">--Select--</option>
<?php
$stdQry = "SELECT msa.ID MetaStageID, msa.Sequence, s.StageName FROM ".APP."txnmetadatastage ms JOIN ".APP."txnmetadatastage msa ON msa.WorkOrderID = ms.WorkOrderID AND msa.Sequence <= ms.Sequence JOIN ".APP."lustage s ON s.ID = msa.StageID WHERE ms.ID = ".$_REQUEST['mtsid']." AND ms.WorkOrderID = ".$_REQUEST['woid'];
$stdExe = mysql_query($stdQry) or die(mysql_error());
while($stdRS = mysql_fetch_array($stdExe))
{
?>
<option value="<?php echo $stdRS['MetaStageID']; ?>"><?php echo $stdRS['StageName']; ?></option>
<?php
}
?>
</select>
<?php
}

if($_REQUEST['req'] == "skip")
{
?>
<select id="skipto" name="skipto" required >
<option selected="selected" value="">--Select--</option>
<?php
$skipQry = "SELECT msa.ID MetaStageID, msa.Sequence, s.StageName FROM ".APP."txnmetadatastage ms JOIN ".APP."txnmetadatastage msa ON msa.WorkOrderID = ms.WorkOrderID AND msa.Sequence > (ms.Sequence + 1) JOIN ".APP."lustage s ON s.ID = msa.StageID WHERE ms.ID = ".$_REQUEST['mtsid']." AND ms.WorkOrderID = ".$_REQUEST['woid'];
$skipExe = mysql_query($skipQry) or die(mysql_error());
while($skipRS = mysql_fetch_array($skipExe))
{
?>
<option value="<?php echo $skipRS['MetaStageID']; ?>"><?php echo $skipRS['StageName']; ?></option>
<?php
}
?>
</select>
<?php
}


if($_REQUEST['req'] == "addtemperature")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5" required />&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addpressure")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5" required />&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addtime")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5" required />&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addweight")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5" required />&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "adddensity")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5" required />&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "addhardness")
{
	$rand = rand(5, 88585);
	$newrand =  rand(5, 88585);
?>
<span><input temp="<?php echo $rand ?>"  type="text"  name="<?php echo $_REQUEST['stage']; ?>[]" id="<?php echo $_REQUEST['stage'];?>" value="" size="5" required />&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>
<?php
}

if($_REQUEST['req'] == "showpfdata")
{
?>

<table width="100%" border="0" id="workflowtable">
	<tr>
	<td colspan="4" align="center"><b>Setting</b></td>
	</tr>
	<tr>
	<td>Stage</td>
	<td>Machine</td>
	<td colspan="2">&nbsp;</td>
	</tr>
<?php
	//echo "SELECT ws.StageID, s.StageName, w.ID, wsm.MachineID, m.MachineName FROM mstrproduct p JOIN luworkflow w ON w.ID = p.WorkflowID JOIN txnworkflowstage ws ON ws.WorkFlowID = w.ID LEFT OUTER JOIN txnworkflowstagemachine wsm ON wsm.WorkflowID = w.ID AND wsm.StageID = ws.StageID JOIN lustage s ON s.ID = ws.StageID LEFT OUTER JOIN lumachine m ON m.ID = wsm.MachineID WHERE p.ID = ".$_REQUEST['pfid']." ORDER BY ws.StageSequence ASC";
	$pfStage = mysql_query("SELECT ws.StageID, s.StageName, w.ID, wsm.MachineID, m.MachineName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow w ON w.ID = p.WorkflowID JOIN ".APP."txnworkflowstage ws ON ws.WorkFlowID = w.ID LEFT OUTER JOIN ".APP."txnworkflowstagemachine wsm ON wsm.WorkflowID = w.ID AND wsm.StageID = ws.StageID JOIN ".APP."lustage s ON s.ID = ws.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wsm.MachineID WHERE p.ID = ".$_REQUEST['pfid']." ORDER BY ws.StageSequence ASC") or die(mysql_error());
	
	while($pfStagers = mysql_fetch_array($pfStage))
	{		
?>
<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='pfStageID[]' id='pfStageID<?php echo $pfStagers['StageID']; ?>' value='<?php echo $pfStagers['StageID']; ?>' ><?php echo $pfStagers['StageName']." - ".$pfStagers['StageID']; ?></td>
	<td><select id="machine" name="machine[]"><option value="" >--Select--</option>
	<?php
		$machine = mysql_query("SELECT ID, CONCAT(Code, ' - ', MachineName) Machine FROM ".APP."lumachine WHERE IsActive = 1 ORDER BY CONCAT(Code, ' - ', MachineName) ASC") or die(mysql_error());
		while($machiners = mysql_fetch_array($machine))
		{
			?>
			<option value="<?php echo $machiners['ID']; ?>" <?php if($machiners['ID'] == $pfStagers['MachineID']) { ?> selected <?php } ?> ><?php echo $machiners['Machine']; ?></option>
			<?php
		}
	?></select>
	</td>
	<td colspan="2"><a href="javascript:addTemp(<?php echo $pfStagers['StageID']; ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;">Temperature</a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>temperature">
	<tbody>
	<?php
	$temperatureQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 1") or die(mysql_error());
	
	while($temperaturers = mysql_fetch_array($temperatureQry))
	{
	?>
	<span><input type="text"  name="<?php echo $temperaturers['StageID']; ?>temperature[]" id="<?php echo $temperaturers['StageID'];?>temperature" value="<?php echo $temperaturers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>
	&nbsp;
	<a href="javascript:addPress(<?php echo $pfStagers['StageID']; ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;">Pressure</a>
	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>pressure">
	<tbody>
	<?php
	$pressureQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 2") or die(mysql_error());
	
	while($pressurers = mysql_fetch_array($pressureQry))
	{
	?>
	<span><input type="text"  name="<?php echo $pressurers['StageID']; ?>pressure[]" id="<?php echo $pressurers['StageID'];?>pressure" value="<?php echo $pressurers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	
	</tbody>
	</table>&nbsp;
	
	</td>
	<input class ="sbox2" type='hidden' name='pfWorkflowID' id='pfWorkflowID' value='<?php echo $pfStagers['ID']; ?>' >
</tr>
<?php
	}

?>

  
</table>



<?php
}

if($_REQUEST['req'] == "scdcadditem")
{
	$rand = rand(5, 88585);
	//$rand = $_REQUEST['rannum'] + 1;
	
	$newrand =  rand(5, 88585);
$journal_query = mysql_query("SELECT ID, Description ItemCategory FROM ".APP."luitemcategory WHERE IsActive = 1") or die(mysql_error());
?>
<tr>
<td align="center" width="10%">
<input type="hidden" name="random[]" id="<?php echo $rand; ?>" value="<?php echo $rand; ?>"/>
 <select name="acronym<?php echo $rand; ?>" id="acronym<?php echo $rand ?>" tabindex="2" required onChange="getItem(<?php echo $rand ?>)">
                                    <option value="">--Select--</option> 
                                    <?php
									while($journal_rs = mysql_fetch_array($journal_query))
									{
									?>
                                    <option value="<?php echo $journal_rs['ID'];?>" ><?php echo $journal_rs['ItemCategory'];?></option>
                                    <?php
									}
									?>
</select>
</td>
<td align="center" width="25%"><select name="itemname<?php echo $rand; ?>" id="itemname<?php echo $rand; ?>" required ><option value="">--Select--</option></select></td>
<td align="center" width="15%">
<select id="unit<?php echo $rand ?>" name="unit<?php echo $rand ?>" required onChange="getitemprice(<?php echo $rand ?>)">
<option value="">--Select--</option>
<?php
$getunit = mysql_query("SELECT ID, Description FROM ".APP."luuom ORDER BY Description ASC") or die(mysql_error());
while($getunitrs = mysql_fetch_array($getunit))
{
?>
<option value="<?php echo $getunitrs['ID']; ?>"><?php echo $getunitrs['Description']; ?></option>
<?php
}
?>
</select></td>
<td align="center" width="3%"><input style="width:50px;" type="text" name="quantity<?php echo $rand ?>" id="quantity<?php echo $rand ?>" required onChange="gettotal(<?php echo $rand ?>)" /></td>
<td align="center" width="5%"><img src="images/del.png" width="16" height="16" alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('tr').remove();chapDel();return 
true;}return false;" /></td>
  </tr>
  
    <?php }


if($_REQUEST['req'] == "additem")
{
	$rand = rand(5, 88585);
	$itemcategory = mysql_query("SELECT ID, Description ItemCategory FROM ".APP."luitemcategory WHERE IsActive = 1 ORDER BY Description ASC") or die(mysql_error());
?>
<tr>
<td align="center" width="10%">
<input type="hidden" name="random[]" id="<?php echo $rand; ?>" value="<?php echo $rand; ?>"/>
 <select name="itemcat<?php echo $rand; ?>" id="itemcat<?php echo $rand ?>" tabindex="1" required onChange="getItem(<?php echo $rand ?>)">
                                    <option value="">--Select--</option> 
                                    <?php
									while($itemcategoryrs = mysql_fetch_array($itemcategory))
									{
									?>
                                    <option value="<?php echo $itemcategoryrs['ID'];?>" ><?php echo $itemcategoryrs['ItemCategory'];?></option>
                                    <?php
									}
									?>
</select>
</td>
<td align="center" width="25%"><select name="itemname<?php echo $rand; ?>" id="itemname<?php echo $rand; ?>" required onChange="getItemDetail(<?php echo $rand ?>)"><option value="">--Select--</option></select></td>
<td align="center" width="15%"><input type="text" style="width:50px;" id="unit<?php echo $rand ?>" name="unit<?php echo $rand ?>" readonly />
<input type="hidden" style="width:50px;" id="unitid<?php echo $rand ?>" name="unitid<?php echo $rand ?>" />
</td>
<td align="center" width="3%"><input style="width:55px;text-align:right;" type="text" name="unitrate<?php echo $rand ?>" id="unitrate<?php echo $rand ?>" required /></td>
<td align="center" width="3%"><input style="width:50px;text-align:right;" type="text" name="quantity<?php echo $rand ?>" id="quantity<?php echo $rand ?>" required onChange="gettotal(<?php echo $rand ?>)" /></td>
<td align="center" width="5%"><input style="width:100px;text-align:right;" type="text" name="total<?php echo $rand ?>" id="total<?php echo $rand ?>" required /></td>

<td align="center" width="5%">
<select id="tax<?php echo $rand ?>" name="tax<?php echo $rand ?>" required >
<option value="">--Select--</option>
<?php
$taxmaster = mysql_query("SELECT ID, Description Tax FROM ".APP."lutax WHERE IsActive = 1 ORDER BY Description ASC") or die(mysql_error());
while($taxmasterrs = mysql_fetch_array($taxmaster))
{
?>
<option value="<?php echo $taxmasterrs['ID'];?>"><?php echo $taxmasterrs['Tax'];?></option>
<?php
}
?>
</select>
</td>
<td align="center" width="5%"><input style="width:80px;text-align:right;" type="text" name="taxvalue<?php echo $rand ?>" id="taxvalue<?php echo $rand ?>" value="0" onChange="getgrandtotal(<?php echo $rand ?>)"/></td>
<td align="center" width="5%"><input style="width:50px;text-align:right;" type="text" name="exciseduty<?php echo $rand ?>" id="exciseduty<?php echo $rand ?>" onChange="getgrandtotal(<?php echo $rand ?>)"/></td>
<td align="center" width="5%"><input style="width:100px;text-align:right;" type="text" name="grandtotal<?php echo $rand ?>" id="grandtotal<?php echo $rand ?>" required /></td>

<td align="center" width="5%"><img src="images/del.png" width="16" height="16" alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('tr').remove();chapDel();return 
true;}return false;" /></td>
  </tr>
  
    <?php }
	
if($_REQUEST['req'] == "addservice")
{
	$rand = rand(5, 88585);
	//$rand = $_REQUEST['rannum'] + 1;
	
	$newrand =  rand(5, 88585);
$journal_query = mysql_query("SELECT ID, Name Service FROM ".APP."luservice WHERE IsActive = 1") or die(mysql_error());
?>
<tr>
<td align="center" width="10%">
<input type="hidden" name="random[]" id="<?php echo $rand; ?>" value="<?php echo $rand; ?>"/>
<select name="itemname<?php echo $rand; ?>" id="itemname<?php echo $rand ?>" tabindex="2" required ">
                                    <option value="">--Select--</option> 
                                    <?php
									while($journal_rs = mysql_fetch_array($journal_query))
									{
									?>
                                    <option value="<?php echo $journal_rs['ID'];?>" ><?php echo $journal_rs['Service'];?></option>
                                    <?php
									}
									?>
</select>
</td>
<td align="center" width="15%">
<select id="unit<?php echo $rand ?>" name="unit<?php echo $rand ?>" required onChange="getitemprice(<?php echo $rand ?>)">
<option value="">--Select--</option>
<?php
$getunit = mysql_query("SELECT ID, Description FROM ".APP."luuom ORDER BY Description ASC") or die(mysql_error());
while($getunitrs = mysql_fetch_array($getunit))
{
?>
<option value="<?php echo $getunitrs['ID']; ?>"><?php echo $getunitrs['Description']; ?></option>
<?php
}
?>
</select></td>
<td align="center" width="3%"><input style="width:75px;" type="text" name="unitrate<?php echo $rand ?>" id="unitrate<?php echo $rand ?>" required /></td>
<td align="center" width="3%"><input style="width:50px;" type="text" name="quantity<?php echo $rand ?>" id="quantity<?php echo $rand ?>" required onChange="gettotal(<?php echo $rand ?>)" /></td>
<td align="center" width="5%"><input style="width:100px;" type="text" name="total<?php echo $rand ?>" id="total<?php echo $rand ?>" required /></td>

<td align="center" width="5%"><img src="images/del.png" width="16" height="16" alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('tr').remove();chapDel();return 
true;}return false;" /></td>
  </tr>
  
    <?php }
	
	if($_REQUEST['req'] == 'getitem')
	{
		$getitem = mysql_query("SELECT i.ID, i.Name FROM ".APP."luitem i WHERE i.ItemCategoryID = ".$_REQUEST['icid']." AND i.IsActive = 1 ORDER BY i.Name") or die(mysql_error());
		?>
		<option value="">--Select--</option>
		<?php

		while($getitemrs = mysql_fetch_array($getitem))
		{
		?>
		<option value="<?php echo $getitemrs['ID']; ?>"><?php echo $getitemrs['Name']; ?></option>
		<?php
		}
		?>
		<?php
	}
	
	if($_REQUEST['req'] == 'getitemprice')
	{
		$getitemprice = mysql_fetch_array(mysql_query("SELECT i.UnitRate FROM ".APP."luitem i WHERE i.ID = ".$_REQUEST['itmid']." AND i.IsActive = 1 ORDER BY i.Name")) or die(mysql_error());
		echo $getitemprice['UnitRate'];
	}
	
	if($_REQUEST['req'] == 'getitemunit')
	{
		$getitemunit = mysql_fetch_array(mysql_query("SELECT i.UOMID UnitID, u.Description Unit, i.UnitRate, i.ExciseDuty FROM ".APP."luitem i INNER JOIN ".APP."luuom u ON u.ID = i.UOMID WHERE i.ID = ".$_REQUEST['itmid']." AND i.IsActive = 1 ORDER BY i.Name")) or die(mysql_error());
		echo $getitemunit['Unit']."|".$getitemunit['UnitID']."|".$getitemunit['UnitRate']."|".$getitemunit['ExciseDuty'];
	}
	
	if($_REQUEST['req'] == "gettohr")
	{
		$hr = mysql_query("SELECT Value FROM ".APP."luhour WHERE Value >= ".$_REQUEST['frmhr']." ORDER BY Value ASC") or die(mysql_error());
		//echo "SELECT Value FROM lkphour WHERE Value = ".$_REQUEST['frmhr']." ORDER BY Value ASC";
		while($hrs = mysql_fetch_array($hr))
		{
		?>
		<option value="<?php echo $hrs['Value']; ?>"><?php echo $hrs['Value']; ?></option>
		<?php
		}
	}
	if($_REQUEST['req'] == "gettomin")
	{
		$hr = mysql_query("SELECT m.Value FROM ".APP."luminute m ORDER BY m.Value ASC") or die(mysql_error());
		//$hr = mysql_query("SELECT m.Value FROM luhour h, luminute m WHERE h.Value >= ".$_REQUEST['frmhr']." AND m.Value >= ".$_REQUEST['frmmin']." ORDER BY m.Value ASC");
		//echo "SELECT Value FROM lkphour WHERE Value = ".$_REQUEST['frmhr']." ORDER BY Value ASC";
		while($hrs = mysql_fetch_array($hr))
		{
		?>
		<option value="<?php echo $hrs['Value']; ?>"><?php echo $hrs['Value']; ?></option>
		<?php
		}
	}
	if($_REQUEST['req'] == "getprs")
	{
		$mac = mysql_query("SELECT m.ID MachineID, m.MachineName FROM ".APP."txnstagemachine ms INNER JOIN ".APP."lumachine m ON m.ID = ms.MachineID WHERE ms.StageID = ".$_REQUEST['prs']." AND m.IsActive = 1 ORDER BY m.MachineName ASC") or die(mysql_error());
		?>

		<option value="">--Machine--</option>
		<?php
		while($macrs = mysql_fetch_array($mac))
		{
		?>
		<option value="<?php echo $macrs['MachineID']; ?>"><?php echo $macrs['MachineName']; ?></option>
		<?php
		}
	}
?>

