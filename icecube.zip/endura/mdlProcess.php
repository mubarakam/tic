<?php session_start();
ob_start();
include("config.php");
include("includes/classes/processClass.php");
echo "<pre>";
$processCode = $_REQUEST['processcode'];
$processName = $_REQUEST['processname'];
$processDesc = $_REQUEST['description'];
$processId = $_REQUEST['sid'];
$roleValue = $_REQUEST['selectedRoleValue'];
$machineValue = $_REQUEST['selectedMachineValue'];
$active = $_REQUEST['active'];
print_r($_REQUEST);

$process = new processClass();

if($_REQUEST['mode'] == 'add')
{
	$process->addProcess($processCode, $processName, $processDesc, $machineValue);
}

if($_REQUEST['mode'] == 'edit')
{
	$process->updateProcess($processId, $processName, $processDesc, $active, $roleValue, $machineValue);
}

if($_REQUEST['mode'] == 'del')
{
	$process->deleteProcess($processId);
}
?>