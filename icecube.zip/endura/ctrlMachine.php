<?php
 include('meta_script_link.php');
?><head>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
function validate(a){var val = $("#"+a).val();$.ajax({type: "post",url: "ajaxValidate.php?frm="+a+"&val="+val,success: function(data){if(data == "exist"){$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});document.getElementById('errdiv').style.display='inline';$("#addbtn").attr('disabled','true')}else if(data != "exist"){$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});document.getElementById('errdiv').style.display='none';$("#addbtn").removeAttr('disabled');}}});}
</script>
<div class="main-container">
<?php include('includes/header.php');


####### Need to declare########
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Machine</div>
<div class="msg_wrap">
<?php 
   if($_REQUEST['msg']=='done')
        {?>
        <div class="msg_success">
           Workflow Created Successfully !!
        </div>
	<?php }	
        if($_REQUEST['msg']=='fail')
        {?>
        <div class="msg_error">
            Workflow Creation Failed !!
        </div>
       	<?php } ?></div>
<div class="backlink">
                 <a href="vwMachine.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
   		 <div id="dashlet-panel" class="dashlet-panel-full">
         <div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; padding-bottom: 5px;">	
  		
                 <div style="padding:10px;">

 <?php
if($_REQUEST['mode'] == 'add')
{
   $wcode = mysql_query("SELECT CONCAT(`CODE`,`CurrentRange` + 1) as code from ".APP."cfgdocumenttype where `ObjectTypeId` = 4") or die(mysql_error());
   $code = mysql_fetch_array($wcode); ?>					
                    <form name="Machineform" action="mdlMachine.php?mode=add" method="post" id="stageform" >
                        
                        <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Machine Code</td>
    <td colspan="3">
      <input style="width:60px;"  type="text"  maxlength="255" name="Machinecode" value="<?php echo $code['code']; ?>" readonly="readonly"/>
    </td>
    </tr>
  <tr>
    <td>Machine Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;" type="text" name="Machinename" value="<?php $workflowName ?>" id="Machinename"  required onChange="validate('Machinename');"/>
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Machine already exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
      <textarea name="description" cols="34" rows="3"></textarea>
      </td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn"/>
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
              
                         
				</form>
<?php			
 }
if($_REQUEST['mode'] == 'edit')
{
	$Machine = mysql_query("select `ID`, `Code`, `MachineName`,`Description` from ".APP."lumachine where ID = ".$_REQUEST['sid']) or die(mysql_error());
	$Machiners = mysql_fetch_array($Machine);
?>
				<form name="Machineform" action="mdlMachine.php?mode=edit" method="post" id="Machineform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Machine Code</td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="Machinecode" value="<?php echo $Machiners['Code']; ?>" readonly="readonly"/><input type="hidden" name="sid" id="sid" value="<?php echo $Machiners['ID']; ?>" >
    </td>
    </tr>
  <tr>
    <td>Machine Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;" type="text" id="Machinename" name="Machinename" value="<?php echo $Machiners['MachineName']; ?>" id="stage"  required onChange="validate('Machinename')" />
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Machine already exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
     <textarea name="description" cols="36" rows="3"><?php echo $Machiners['Description']; ?></textarea>
      </td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }
 ?>
			</div>			
		</div>		
	</div>

</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>