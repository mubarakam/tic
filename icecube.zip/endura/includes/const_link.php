<?php
define("NO_OF_DAYS_PASSWORD_EXPIRY", "90");   // NO_OF_DAYS_PASSWORD_EXPIRY

define("FPP", "104");   // FPP ROUND ID
define("RPP","105");    // RPP ROUND ID
define("ELD","106");    // ELD ROUND ID
define("ISSUE","107");  // ISSUE ROUND ID
define("PRINTER","100"); // PRINTER ROUND ID
define("ISSUE_ELD","108"); // ISSUE ONLINE ROUND ID
define("AA","114");  // AA ROUND ID
define("OTA","116"); // OFFPRINT TO AUTHOR ROUND ID
define("OTP","118"); // OFFPRINT TO PRINTER ROUND ID
define("POD","120"); // POD ROUND ID
define("INVOICE","122"); // INVOICE ROUND ID
define("OPC","142"); // OPC ROUND/SERVICE ID
define("JOURNAL_RNDS","104,105,106,107,100,108,114,116,118,120,122,142"); // JOURNAL ROUND ID'S
define("ME","664,188"); // MECHANICAL EDITING ID'S
define("OTA_DATE","1"); // OFFPRINT TO AUTHOR DUE DAY'S
define("OTP_DATE","1"); // OFFPRINT TO PRINTER DUE DAY'S
define("POD_DATE","1"); // POD DUE DAY'S
define("OPC_DATE","1"); // OPC DUE DAY'S
define("PG","3");   // PAGINATION STAGE ID
define("PR","5");   // PROOF READING STAGE ID
define("DP","7");   // DISPATCH STAGE ID
define("cestg", "188");  // COPYEDITING STAGE ID
define("hcestg", "664"); // HYBRID COPYEDITING STAGE ID
define("SSS1", "1194");  // SSS1 WORKFLOW ID
define("FSS", "1198");   // FSS WORKFLOW ID
define("Direct", "1200"); // DIRECT WORKFLOW ID
define("SSS","1196");  // SSS WORKFLOW ID
define("CCTNA","33");  // COPYRIGHT TYPE 'NOT AVAILABLE' ID
define("CROTHER","11,26"); // COPYRIGHT TYPE 'OTHER' ID
define("CRPATH","pagingfiles/copyright"); // CRT FILE DESTITNATION
define("STATUS","41,42,43,65,66,67,68,69"); // ARTICLE/ISSUE STATUS ID'S
define("RSTAT","43,69"); // ARTICLE/ISSUE STATUS ID'S
define("OPCS","69"); // OPC STATUS ID'S
define("CUNAME","mubarak"); // COPYRIGHT FILE PATH USERNAME
define("CPWD","laser@123"); // COPYRIGHT FILE PATH PASSWORD
define("CSRCPATH","192.168.9.218/htdocs/jmagnus/MyXls/crt"); // COPYRIGHT FILE SOURCE PATH
define("PATH7TYPECONVERSION","192.168.9.218/jmagnus/MyXls/"); // COPYRIGHT FILE SOURCE PATH
define("USERNAME7TYPECONVERSION","laserwords"); // COPYRIGHT FILE SOURCE PATH
define("PASSWORD7TYPECONVERSION","password@10"); // COPYRIGHT FILE SOURCE PATH
define("STAGE_IDS","562,691,692,693,694"); // REVIEW PATH STAGE IDS
define("MSR","562"); // REVIEW PATH STAGE ID
define("CES","692"); // CE SPECIFICATION STAGE ID
define("JC","694"); // JOURNAL RE COPY STAGE ID
define("JD","696"); // JOURNAL DOCUMENT STAGE ID
define("JPI","698"); // JOURNAL PREVIOUS ISSUE STAGE ID
define("DBACCESS","172.24.177.217:3306/emsdev<>devuser<>devuser");
define("FTPTBL","journal_round_level_ftp"); // FTP UPLOAD TABLE
define("QTBL","magnus_process_queue"); // FTP UPLOAD PROGRESS TABLE
define("FTPFROM","no-reply@laserwords.com"); 
define("FTPTO","shamu.shihabudeen@spi-global.com"); 
define("LOGPATH","172.24.177.217/EMSFileManagement/Watch_Folders/logs/"); // File Transfer log path
define("LOGPATHUNAME","administrator"); // File Transfer log path
define("LOGPATHPASSWORD","laserwords"); // File Transfer log path
define("LOCALPATHSTAGES","688,686,188,660,662,664,673");

////// NOTE: MENTION THE DEFINING NAME DETAILS CLEARLY IN A COMMENT, FOLLOW THE ABOVE FORMAT//////
?>