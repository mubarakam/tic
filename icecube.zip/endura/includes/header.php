<?php 
include("erpConstant.php");
session_start();
if(!isset($_SESSION['UserName'])) {
	header("location: index.php");	
}
?>
<link rel="stylesheet" href="css/menu.css" type="text/css" />
<script type="text/javascript">
function logout(){
	window.location.href="logout.php";
}
</script>
<style type="text/css" media="screen">
.tooltip:hover span span, .pure_css_dropdown:hover span span {
    display: block;
}
.tooltip span, .pure_css_dropdown span {
    position: absolute;
    text-decoration: none;
}
.tooltip span span, .pure_css_dropdown span span {
    background-color: #FFF;
	border-radius: 0.3em 0.3em 0.3em 0.3em;
    border: 3px solid #1290CB;
   	color: #FFFFFF;
	font-weight: bold;
	font-family:Verdana, Geneva, sans-serif;
    display: none;
    left: -90px;
    position: absolute;
    text-decoration:none;
	top: 20px;
    width: 98px;
    z-index: 100;
}
.pure_css_dropdown span span {
    top: 1.3em;
}
a.tooltip_blue {
    border-bottom: 1px dashed blue;
    text-decoration: none;
}
a.tooltip_blue:hover {
    padding: 0;
    text-decoration: none;
}
.tooltip_blue:hover span span {
    display: block;
}
.tooltip_blue span {
    position: absolute;
    text-decoration: none;
}
.tooltip_blue span span {
    background-color: #FFF;
    border: 2px solid #1290CB;
    color: #FFFFFF;
	border-radius: 0.3em 0.3em 0.3em 0.3em;
    display: none;
    left: -120px;
    position: absolute;
    text-decoration: none;
    top: 20px;
    width: 90px;
    z-index: 100;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
.role {
font-family: Verdana, Geneva, sans-serif; color: #FFF; font-weight:bolder; background-color: #1290CB;margin-bottom:10px;padding:3px	
}
.rlist {
float:left;margin:0 0 10px 8px;	
}
.rlist:hover {
text-decoration:underline;	
}
/**Notification Bubble **/
.notification-bubble {
    height: 18px;
    width: 18px;
    background: #f56c7e url(images/notification-bg-clear.png) no-repeat center center scroll;
    background-image: none\9;
    position: absolute;
    right: 17px;
    top: 21px;
    color: #fff;
    text-shadow: 1px 1px 0 rgba(0, 0, 0, .2);
    text-align: center;
    font-size: 10px;
    line-height: 18px;
    box-shadow: inset 0 0 0 1px rgba(0, 0, 0, .17), 0 1px 1px rgba(0, 0, 0, .2);
    -moz-box-shadow: inset 0 0 0 1px rgba(0, 0, 0, .17), 0 1px 1px rgba(0, 0, 0, .2);
    -webkit-box-shadow: inset 0 0 0 1px rgba(0, 0, 0, .17), 0 1px 1px rgba(0, 0, 0, .2);
    border-radius: 9px;
    font-weight: bold;
    cursor: pointer;
	display:none;
}
.notification-menu-item:hover .notification-bubble {
    box-shadow: inset 0 0 0 1px rgba(0, 0, 0, .2), 0 2px 1px rgba(0, 0, 0, .2);
}
.notification-menu-item a {
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
}

.notification-bubble {
    -webkit-transition: all 0.1s ease;
    -moz-transition: all 0.1s ease;
    -o-transition: all 0.1s ease;
    transition: all 0.1s ease;
}
.repeat{
width:100%;
height:25px;
background:url(images/repeat.png) repeat-x;
}

#fppCount .notification-bubble {
    background: #337534 url("images/notification-bg-clear.png") no-repeat scroll center center;
    border-radius: 9px;
    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.17) inset, 0 1px 1px rgba(0, 0, 0, 0.2);
    color: #fff;
    cursor: pointer;
    display: none;
    font-size: 10px;
    font-weight: bold;
    height: 18px;
    line-height: 18px;
    position: absolute;
    right: 55px;
    text-align: center;
    text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.2);
    top: 21px;
    width: 18px;
}

 </style>
<div class="header-inner-cont">

	
		<div class="head-nav-outer">
			  <ul class="user-settings">
			    <li>Welcome, &nbsp;<font color="#1f6090" style="font-weight:bold">

			<span  class="pure_css_dropdown">
				<?php echo $_SESSION['UserName']." [".$_SESSION['Role']."]";?>
               
				</span>
			    </font>
				</li>
                
				<li><a href="password.php?link=suc" title="Change Password">Change Password</a></li>
               			
				<li><a href="#" onclick="logout()">Logout</a></li>
			  </ul>
		</div>
			 <a href="dashboard.php" style="margin:12px 0 0 30px;float:left;">
        	<!--<img src="images/logo1.png" width="154" height="37" alt="" border="0" />-->
        </a>
</div>

<div class="clear"></div>
<div id="menubar">
<ul id="navbar">
<li><a href="dashboard.php">Home</a></li>

<!--<li><a href="#">Sample Main</a>
	<ul class="navbarmenu first">
		<li><a href="#" class="sub">Sample Child</a>
			<ul class="navbarmenu">
				<li><a href="#">Sub-Sample Child1</a></li>
				<li><a href="#">Sub-Sample Child2</a></li>
			</ul>
		</li>
	</ul>
</li>
-->
<li><a>Production</a>
	<ul class="navbarmenu first">
		<li><a>Pre-Production</a>
			<ul class="navbarmenu">
				<li><a href="vwWorkOrder.php">Work Order</a></li>
				<li><a href="vwWeighing.php">Weighing</a></li>
				<li><a href="vwMixing.php">Mixing</a></li>
			</ul>
		</li>
		<li><a>Production</a>
			<ul class="navbarmenu">
				<li><a href="vwMyTask.php">Production Entry</a></li>
				<li><a href="ctrlLongue.php">Lounge</a></li>
			</ul>
		</li>
		<li><a>Post-Production</a></li>
	</ul>
</li>

<li><a>Master</a>
	<ul class="navbarmenu first">
		<li><a href="vwMachine.php">Machine</a></li>
		<li><a href="vwProcess.php">Process</a></li>
		<li><a href="vwProductionFlow.php">Process Flow</a></li>
		<li><a href="vwStandard.php">Standards</a></li>
		<li><a href="vwProduct.php">Parent Item</a></li>
		<li><a href="vwProduct.php?mode=ci">Component</a></li>
		<!--<li><a href="vwItem.php">Parts</a></li>
		<li><a href="vwService.php">Service</a></li>
		<li><a href="vwSupplier.php">Supplier</a></li>
		<li><a href="vwContractor.php">Contractor</a></li>-->
	</ul>
</li>

<li><a>HR</a>
	<ul class="navbarmenu first">
		<li><a>Master</a>
			<ul class="navbarmenu">
				<li><a href="vwEmployee.php">Employee</a>
				<li><a>Shift</a>
			</ul>		
		</li>
		<li><a>Attendance</a></li>

	</ul>
</li>

<li><a>Reports</a>
	<ul class="navbarmenu first">
		<li><a>Production</a>
			<ul class="navbarmenu">
				
				<li><a href="rptprodtime.php">Timing Report</a></li>
				<li><a href="rptstdvsprod.php">Std. vs Prod. Setting</a></li>
				<li><a href="rptexlmacvsusr.php">Machine vs Operator</a></li>
				<li><a href="rptexlmacvscom.php">Component vs Machine</a></li>
			</ul>
		</li>
	</ul>
</li>
<!--
<li><a href="#">Pur. & Inv.</a>
	<ul class="navbarmenu first">
		<li><a href="vwPurchaseOrder.php">Purchase Order</a></li>
		<li><a href="vwMaterialReceipt.php">Material Receipt (MRN)</a></li>
		<li><a href="vwPurchaseOrder.php">Purchase Return</a></li>
		<li><a href="vwBillMatch.php">Bill Matching</a></li>
		<li><a href="vwBillPayment.php">Supplier Payment</a></li>
	</ul>
</li>

<li><a href="#">Sub Contract</a>
	<ul class="navbarmenu first">
		<li><a href="vwsubcontractPO.php">Purchase Order</a></li>
		<li><a href="vwsubcontractDC.php">Sub Contract DC</a></li>
		<li><a href="vwsubcontractGRN.php">Sub Contract GRN</a></li>
		
	</ul>
</li>-->
</ul>
</div>
<!--<div><span style="font-size:15px;background-color:red;">
		<?php
		$expiry = mysql_fetch_array(mysql_query("SELECT Value, DATEDIFF(CAST(Value AS DATE), NOW()) RemainingDays FROM cfgapplication WHERE AppKey = 'ExpiryDate' AND IsActive = 1"));
		?>
		<marquee><b><?php echo "We're in trail version. This URL will be expired on ".$expiry['Value'].". We have ".$expiry['RemainingDays']. " day(s) remaining for trail"; ?></b></marquee>
</span></div>-->
<div class="clear"></div>