<div class="clear"></div>
<div class="footer">
 <div class="lw-logo"><a href="#"><img src="" width="80" height="24" alt="" border="0" /></a></div>
 <div class="copyrights">&copy; <?php echo date('Y'); ?> - </div> 
 

</div>