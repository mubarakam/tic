<?php
class standardClass {
	
	//$userid = $_SESSION['UserID'];

	function machineSetting($pfWorkflowID, $pfStageID, $machine, $temperature, $pressure, $time, $weight, $density, $hardness, $target)
	{
		$userid = $_SESSION['UserID'];
		
		for($i = 0;$i < count($target);$i++)
		{
			$targetValue = trim($target[$i]);
			if($targetValue)
			{
				if($machine)
				{
					echo "INSERT INTO ".APP."txnstandardtarget (StandardID, StageID, MachineID, Target) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".$targetValue.")";
					echo "<br/>";
					$targetInsert = mysql_query("INSERT INTO ".APP."txnstandardtarget (StandardID, StageID, MachineID, Target) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".$targetValue.")") or die(mysql_error());
				}
				else
				{
					echo "INSERT INTO ".APP."txnstandardtarget (StandardID, StageID, Target) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$targetValue.")";
					echo "<br/>";
					$targetInsert = mysql_query("INSERT INTO ".APP."txnstandardtarget (StandardID, StageID, Target) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$targetValue.")") or die(mysql_error());
				}
			}
		}
		
		if($machine)
		{
				for($i = 0;$i < count($temperature);$i++)
				{
					$tseq = $i + 1;
					$temperatureValue = trim($temperature[$i]);
					if($temperatureValue)
					{
						echo "INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".TEMPERATURE.", '".$temperatureValue."', '".$tseq."')";
						echo "<br/>";
						$temperatureInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".TEMPERATURE.", '".$temperatureValue."', '".$tseq."')") or die(mysql_error());
					}
				}
				for($i = 0;$i < count($pressure);$i++)
				{
					$pseq = $i + 1;
					$pressureValue = trim($pressure[$i]);
					if($pressureValue)
					{
						$pressureInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".PRESSURE.", '".$pressureValue."', '".$pseq."')") or die(mysql_error());
					}
				}
				for($i = 0;$i < count($time);$i++)
				{
					$tmseq = $i + 1;
					$timeValue = trim($time[$i]);
					if($timeValue)
					{
						$timeInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".TIME.", '".$timeValue."', '".$tmseq."')") or die(mysql_error());
					}
				}
				for($i = 0;$i < count($weight);$i++)
				{
					$wseq = $i + 1;
					$weightValue = trim($weight[$i]);
					if($weightValue)
					{
						$weightInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".WEIGHT.", '".$weightValue."', '".$wseq."')") or die(mysql_error());
					}
				}
				for($i = 0;$i < count($density);$i++)
				{
					$dseq = $i + 1;
					$densityValue = trim($density[$i]);
					if($densityValue)
					{
						$densityInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".DENSITY.", '".$densityValue."', '".$dseq."')") or die(mysql_error());
					}
				}
				for($i = 0;$i < count($hardness);$i++)
				{
					$hseq = $i + 1;
					$hardnessValue = trim($hardness[$i]);
					if($hardnessValue)
					{
						$hardnessInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID, MachineID, AttributeID, Value, ValueSequence) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".HARDNESS.", '".$hardnessValue."', '".$hseq."')") or die(mysql_error());
					}
				}
		}
		else
		{
			$noMachineInsert = mysql_query("INSERT INTO ".APP."txnstandardsetting (StandardID, StageID) VALUES (".$pfWorkflowID.", ".$pfStageID.")") or die(mysql_error());
		}
	}	
}
?>