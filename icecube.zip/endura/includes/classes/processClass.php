<?php
class processClass {
	
	

	function addProcess($processCode, $processName, $processDesc, $machineValue)
	{
		$updateDocType = mysql_query("UPDATE ".APP."cfgdocumenttype set `CurrentRange` = CurrentRange +1  WHERE `OBJECTTYPEID` = 3") or die(mysql_error());
		
		$processQry = "INSERT INTO ".APP."lustage (Code, StageName, Description, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES ('".$processCode."' , '".$processName."' , '".$processDesc."', ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())";
		echo $processQry;
		$process = mysql_query($processQry) or die(mysql_error());
		
		echo $machineValue;
		
		if($machineValue)
		{
			$processId = mysql_insert_id();
			$arrMachineValue = explode(",", $machineValue);
			for($m=0;$m < COUNT($arrMachineValue);$m++)
			{
				$processMachine = "INSERT INTO ".APP."txnstagemachine (StageID, MachineID) VALUES (".$processId.", ".$arrMachineValue[$m].")";
				mysql_query($processMachine) or die(mysql_error());
			}
		}
		
		if($process && $updateDocType)
		{
			$_SESSION['prcmsg'] = 'dones';
			header("location:vwProcess.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'donef';
			header("location:vwProcess.php");
		}
	}
	
	function updateProcess($processId, $processName, $processDesc, $active, $roleValue, $machineValue)
	{
		$userid = $_SESSION['UserID'];
		$process = mysql_query("UPDATE ".APP."lustage SET StageName = '".$processName."' , Description = '".$processDesc."', IsActive = ".$active.", LastModOn = now(), LastModBy = ".$userid." where ID = ".$processId) or die(mysql_error());
		
		if($process)
		{
			if($roleValue)
			{
				$delStageRole = mysql_query("DELETE FROM ".APP."txnstagerole WHERE StageID = ".$processId) or die(mysql_error());
				$arrroleValue = explode(",", $machineValue);				
				if($delStageRole)
				{
					for($i = 0;$i < count($arrroleValue);$i++)
					{
						echo "INSER INTO ".APP."txnstagerole (StageID, RoleID, LastModBy, LastModOn) VALUES (".$processId.", ".$arrroleValue[$i].", ".$userid.", NOW())";
						$stagerole = mysql_query("INSERT INTO ".APP."txnstagerole (StageID, RoleID, LastModBy, LastModOn) VALUES (".$processId.", ".$arrroleValue[$i].", ".$userid.", NOW())") or die(mysql_error());
					}
				}
			}
			
			$delStageMachine = mysql_query("DELETE FROM ".APP."txnstagemachine WHERE StageID = ".$processId) or die(mysql_error());
			$arrMachineValue = explode(",", $machineValue);
			
			if($delStageMachine && $machineValue)
			{
				for($i = 0;$i < count($arrMachineValue);$i++)
				{
					echo "INSER INTO ".APP."txnstagemachine (StageID, MachineID) VALUES (".$processId.", ".$arrMachineValue[$i].")";
					$stagemachine = mysql_query("INSERT INTO ".APP."txnstagemachine (StageID, MachineID) VALUES (".$processId.", ".$arrMachineValue[$i].")") or die(mysql_error());
				}
			}

			$_SESSION['prcmsg'] = 'upds';
			header("location:vwProcess.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'updf';
			header("location:vwProcess.php");
		}
	}

	function deleteProcess($processId)
	{
		$process = mysql_query("UPDATE ".APP."lustage SET IsActive = 0, LastModOn = now(), LastModBy = ".$_SESSION['UserID']." where ID = ".$processId) or die(mysql_error());
		
		if($process)
		{
			$_SESSION['prcmsg'] = 'ds';
			header("location:vwProcess.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'df';
			header("location:vwProcess.php");
		}
	}	
/*
if($_REQUEST['mode'] == 'edit') {
	
	$stagename = addslashes($_REQUEST['stageame']);
$stagedescription = addslashes($_REQUEST['description']);
	
$sbox_val = $_POST['sbox_value'];
				$stage = mysql_query("update stage  set `STAGE_NAME` ='".$stagename."' , `DESCRIPTION` ='".$stagedescription."',`LAST_MOD_DATE` = now(), `LAST_MOD_BY`=".$_SESSION['user_id']." where stage_id=".$_REQUEST['sid']);
				if($stage)
				{
					if($sbox_val !=''){
						$del = mysql_query("delete from stage_role where stage =".$_REQUEST['sid']);
					$arr = explode(",",$sbox_val);			
					$arr_count = count($arr);
					$seq_val=1;
					for($i=0;$i<$arr_count;$i++)
						{				
						$id_value = $arr[$i];
						$qry_stage = mysql_query("INSERT INTO `stage_role` set `STAGE` =".$_REQUEST['sid'].", `ROLE`=".$id_value);
						$seq_val=$seq_val+1;
						}
						if($qry_stage)
						{
							header("location:liststage.php?msg=update");
						}
						else
						{
							header("location:liststage.php?msg=fail");
						}
					}
					else
					{
						header("location:liststage.php?msg=update");
					}
				}
				else
				{
					header("location:liststage.php?msg=fail");
				}



}



if($_REQUEST['mode']=='val')
{
$selqry = mysql_query("select stage_name from stage where stage_name ='".$_REQUEST['wflow']."'");

if(mysql_num_rows($selqry) != 0)
{
	echo "exist";
}
}

if($_REQUEST['mode']=='del')
{
	$delt = mysql_query("update stage set is_active = 0, LAST_MOD_DATE =now(), LAST_MOD_BY =".$_SESSION['user_id']." where stage_id =".$_REQUEST['sid']);
	if($delt)
	{
		header("location:liststage.php?msg=del");
	}
	else
	{
		header("location:liststage.php?msg=fail");
	}
	
}*/
		
	
	
	
}



?>