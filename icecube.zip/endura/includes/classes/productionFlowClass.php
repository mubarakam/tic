<?php
class productionFlowClass {
	
	//$userid = $_SESSION['UserID'];

	function addProductionFlow($pfCode, $pfName, $pfDesc, $selVal)
	{
		$updateDocType = mysql_query("UPDATE ".APP."cfgdocumenttype set `CurrentRange` = CurrentRange +1  WHERE `OBJECTTYPEID` = 5") or die(mysql_error());
		
		//$pfMaster = mysql_query("INSERT INTO mstrworkflow (Code, WorkflowMasterName, Description, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES ('".$pfCode."' , '".$pfName."' , '".$pfDesc."', ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())") or die(mysql_error());
		
		//$pfMasterId = mysql_insert_id();
		
		$pf = mysql_query("INSERT INTO ".APP."luworkflow (Code, WorkflowName, LastModBy, LastModOn) VALUES ('".$pfCode."', '".$pfName."', ".$_SESSION['UserID'].", now())") or die(mysql_error());
		
		$pfId = mysql_insert_id();

		$arrSelVal = explode(",", $selVal);			
		$arrSelValCnt = count($arrSelVal);
		$s = 1;
		for($i = 0;$i < $arrSelValCnt;$i++)
		{
			$id_value = $arrSelVal[$i];
			echo "INSERT INTO ".APP."txnworkflowstage (WorkflowID, StageID, StageSequence, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES (".$pfId.", ".$arrSelVal[$i].", ".$s.", ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())";
			$pfStage = mysql_query("INSERT INTO ".APP."txnworkflowstage (WorkflowID, StageID, StageSequence, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES (".$pfId.", ".$arrSelVal[$i].", ".$s.", ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())") or die(mysql_error());
			
			$s = $s + 1;
		}

		if($updateDocType && $pf && $pfStage)
		{
			$_SESSION['prcmsg'] = 'dones';
			header("location:vwProductionFlow.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'donef';
			header("location:vwProductionFlow.php");
		}
	}
	
	function updateProductionFlow($pfMasterId, $pfName, $pfDesc, $selVal)
	{
		$pf = mysql_query("UPDATE ".APP."luworkflow SET WorkflowName = '".$pfName."', LastModOn = now(), LastModBy = ".$_SESSION['UserID']." WHERE MasterID = ".$pfMasterId) or die(mysql_error());
		
		$delpfStage = mysql_query("DELETE FROM ".APP."txnworkflowstage WHERE WorkflowID = ".$pfMasterId) or die(mysql_error());
		
		$arrSelVal = explode(",", $selVal);			
		$arrSelValCnt = count($arrSelVal);
		$s = 1;
		for($i = 0;$i < $arrSelValCnt;$i++)
		{
			$id_value = $arrSelVal[$i];
			
			echo "INSERT INTO ".APP."txnworkflowstage (WorkflowID, StageID, StageSequence, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES (".$pfMasterId.", ".$arrSelVal[$i].", ".$s.", ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())";
			echo "<br/>";
			
			$pfStage = mysql_query("INSERT INTO ".APP."txnworkflowstage (WorkflowID, StageID, StageSequence, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES (".$pfMasterId.", ".$arrSelVal[$i].", ".$s.", ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())") or die(mysql_error());
			
			$s = $s + 1;
		}
		echo "pfMasterId - ".$pfMasterId;
		echo "pf - ".$pf;
		echo "delpfStage - ".$delpfStage;
		echo "pfStage - ".$pfStage;

		if($delpfStage && $pfStage)
		{
			$_SESSION['prcmsg'] = 'dones';
			header("location:vwProductionFlow.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'donef';
			header("location:vwProductionFlow.php");
		}
	}

	function deleteProductionFlow($pfMasterId)
	{
		$pfMaster = mysql_query("UPDATE ".APP."luworkflow SET IsActive = 0, LastModOn = now(), LastModBy = ".$_SESSION['UserID']." where ID = ".$pfMasterId) or die(mysql_error());
		
		if($pfMaster)
		{
			$_SESSION['prcmsg'] = 'ds';
			header("location:vwProductionFlow.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'df';
			header("location:vwProductionFlow.php");
		}
	}
	
	function machineSetting($pfWorkflowID, $pfStageID, $machine, $temperature, $pressure, $time, $weight, $density, $hardness)
	{
		$userid = $_SESSION['UserID'];/*
		echo "<br/>";
		echo "wk - ".$pfWorkflowID."<br/>";
		echo "st - ".$pfStageID."<br/>";
		echo "mac - ".$machine."<br/>";
		echo "temp - ";
		print_r($temperature);
		echo "<br/>";
		echo "press - ";
		print_r($pressure);
		*/
		if($machine)
		{
			echo "INSERT INTO ".APP."txnworkflowstagemachine (WorkFlowID, StageID, MachineID, LastModBy, LastModOn) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".$userid.", now())";
			$mapWkFlowStageMachine = mysql_query("INSERT INTO ".APP."txnworkflowstagemachine (WorkFlowID, StageID, MachineID, LastModBy, LastModOn) VALUES (".$pfWorkflowID.", ".$pfStageID.", ".$machine.", ".$userid.", now())") or die(mysql_error());
			
			if($mapWkFlowStageMachine)
			{
				$mapWkFlowStageMachineID = mysql_insert_id();

				for($i = 0;$i < count($temperature);$i++)
				{
					$tseq = $i + 1;
					$temperatureValue = $temperature[$i];
					$temperatureInsert = mysql_query("INSERT INTO ".APP."txnworkflowattributesetting (AttributeID, WorkflowStageMachineID, Value, SequenceOrder, LastModBy, LastModOn) VALUES (1, ".$mapWkFlowStageMachineID.", '".$temperatureValue."', ".$tseq.", ".$userid.", now())") or die(mysql_error());
				}
				for($i = 0;$i < count($pressure);$i++)
				{
					$pseq = $i + 1;
					$pressureValue = $pressure[$i];
					$pressureInsert = mysql_query("INSERT INTO ".APP."txnworkflowattributesetting (AttributeID, WorkflowStageMachineID, Value, SequenceOrder, LastModBy, LastModOn) VALUES (2, ".$mapWkFlowStageMachineID.", '".$pressureValue."', ".$pseq.", ".$userid.", now())") or die(mysql_error());
				}
				for($i = 0;$i < count($time);$i++)
				{
					$tmseq = $i + 1;
					$timeValue = $time[$i];
					$timeInsert = mysql_query("INSERT INTO ".APP."txnworkflowattributesetting (AttributeID, WorkflowStageMachineID, Value, SequenceOrder, LastModBy, LastModOn) VALUES (4, ".$mapWkFlowStageMachineID.", '".$timeValue."', ".$tmseq.", ".$userid.", now())") or die(mysql_error());
				}
				for($i = 0;$i < count($weight);$i++)
				{
					$wseq = $i + 1;
					$weightValue = $weight[$i];
					$weightInsert = mysql_query("INSERT INTO ".APP."txnworkflowattributesetting (AttributeID, WorkflowStageMachineID, Value, SequenceOrder, LastModBy, LastModOn) VALUES (3, ".$mapWkFlowStageMachineID.", '".$weightValue."', ".$wseq.", ".$userid.", now())") or die(mysql_error());
				}
				for($i = 0;$i < count($density);$i++)
				{
					$dseq = $i + 1;
					$densityValue = $density[$i];
					$densityInsert = mysql_query("INSERT INTO ".APP."txnworkflowattributesetting (AttributeID, WorkflowStageMachineID, Value, SequenceOrder, LastModBy, LastModOn) VALUES (5, ".$mapWkFlowStageMachineID.", '".$densityValue."', ".$dseq.", ".$userid.", now())") or die(mysql_error());
				}
				for($i = 0;$i < count($hardness);$i++)
				{
					$hseq = $i + 1;
					$hardnessValue = $hardness[$i];
					$hardnessInsert = mysql_query("INSERT INTO ".APP."txnworkflowattributesetting (AttributeID, WorkflowStageMachineID, Value, SequenceOrder, LastModBy, LastModOn) VALUES (6, ".$mapWkFlowStageMachineID.", '".$hardnessValue."', ".$hseq.", ".$userid.", now())") or die(mysql_error());
				}
			}
		}
	}

/*
if($_REQUEST['mode'] == 'edit') {
	
	$stagename = addslashes($_REQUEST['stageame']);
$stagedescription = addslashes($_REQUEST['description']);
	
$sbox_val = $_POST['sbox_value'];
				$stage = mysql_query("update stage  set `STAGE_NAME` ='".$stagename."' , `DESCRIPTION` ='".$stagedescription."',`LAST_MOD_DATE` = now(), `LAST_MOD_BY`=".$_SESSION['user_id']." where stage_id=".$_REQUEST['sid']);
				if($stage)
				{
					if($sbox_val !=''){
						$del = mysql_query("delete from stage_role where stage =".$_REQUEST['sid']);
					$arr = explode(",",$sbox_val);			
					$arr_count = count($arr);
					$seq_val=1;
					for($i=0;$i<$arr_count;$i++)
						{				
						$id_value = $arr[$i];
						$qry_stage = mysql_query("INSERT INTO `stage_role` set `STAGE` =".$_REQUEST['sid'].", `ROLE`=".$id_value);
						$seq_val=$seq_val+1;
						}
						if($qry_stage)
						{
							header("location:liststage.php?msg=update");
						}
						else
						{
							header("location:liststage.php?msg=fail");
						}
					}
					else
					{
						header("location:liststage.php?msg=update");
					}
				}
				else
				{
					header("location:liststage.php?msg=fail");
				}



}



if($_REQUEST['mode']=='val')
{
$selqry = mysql_query("select stage_name from stage where stage_name ='".$_REQUEST['wflow']."'");

if(mysql_num_rows($selqry) != 0)
{
	echo "exist";
}
}

if($_REQUEST['mode']=='del')
{
	$delt = mysql_query("update stage set is_active = 0, LAST_MOD_DATE =now(), LAST_MOD_BY =".$_SESSION['user_id']." where stage_id =".$_REQUEST['sid']);
	if($delt)
	{
		header("location:liststage.php?msg=del");
	}
	else
	{
		header("location:liststage.php?msg=fail");
	}
	
}*/
		
	
	
	
}



?>