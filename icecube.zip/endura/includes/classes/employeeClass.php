<?php
class employeeClass {
	function addEmployee($ename, $fname, $roleID, $genderID, $bloodgrpID, $martialID, $dob, $doj, $dow, $empTypeID, $address, $contnum)
	{
		$userid = $_SESSION['UserID'];
		$pwd = md5($dob);
		//date('Y-m-d', strtotime($_REQUEST['dow']))
		$getCode = mysql_fetch_array(mysql_query("SELECT CONCAT(CODE, CurrentRange + 1) as code from ".APP."cfgdocumenttype where ObjectTypeId = 10")) or die(mysql_error());
		$insQry = "INSERT INTO ".APP."mstremployee (RoleID, EmployeeCode, Name, Password, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES (".$roleID.", '".$getCode['code']."', '".$ename."', '".$pwd."', ".$userid.", NOW(), ".$userid.", NOW())";
		//echo $insQry;
		//echo "<br/>";
		$insExe = mysql_query($insQry) or die(mysql_error());
		
		if($insExe)
		{
			$empID = mysql_insert_id();
			$insDetQry = "INSERT INTO ".APP."luemployeedetail (ID, GenderID, MartialStatusID, BloodGroupID, EmploymentTypeID, FatherName, DOB, DOJ, Address, ContactNumber, CreatedBy, CreatedOn, LastModBy, LastModOn, DOW) VALUES (".$empID.", ".$genderID.", ".$martialID.", ".$bloodgrpID.", ".$empTypeID.", '".$fname."', '".$dob."', '".$doj."', '".$address."', '".$contnum."', ".$userid.", NOW(), ".$userid.", NOW(), '".$dow."')";
			
			$updDoc = "UPDATE ".APP."cfgdocumenttype SET CurrentRange = CurrentRange + 1 WHERE ObjectTypeId = 10";
			
			$insDetExe = mysql_query($insDetQry) or die(mysql_error());
			$updDocExe = mysql_query($updDoc) or die(mysql_error());
			
			if($insDetExe && $updDocExe)
			{
				header("location: vwEmployee.php?code=".$getCode['code']);				
			}
			else
			{
				header("location: ctrlEmployee.php?mode=add");
			}
		}
		
		
	}
	function updateEmployee($eid, $ename, $fname, $roleID, $genderID, $bloodgrpID, $martialID, $dob, $doj, $dow, $empTypeID, $address, $contnum, $activeflag)
	{
		$userid = $_SESSION['UserID'];
		$updEmpMas = "UPDATE ".APP."mstremployee SET Name = '".$ename."', RoleID = ".$roleID.", LastModBy = ".$userid.", LastModOn = NOW(), IsActive = ".$activeflag." WHERE ID = ".$eid;
		echo $updEmpMas;
		$updEmpDet = "UPDATE ".APP."luemployeedetail SET FatherName = '".$fname."', GenderID = ".$genderID.", BloodGroupID = ".$bloodgrpID.", MartialStatusID = ".$martialID.", DOB = '".$dob."', DOJ = '".$doj."', DOW = '".$dow."', EmploymentTypeID = ".$empTypeID.", Address = '".$address."', ContactNumber = '".$contnum."', LastModBy = ".$userid.", LastModOn = NOW() WHERE ID = ".$eid;
		
		$updEmpMasExe = mysql_query($updEmpMas) or die(mysql_error());
		$updEmpDetExe = mysql_query($updEmpDet) or die(mysql_error());
		
		if($updEmpMasExe && $updEmpDetExe)
		{
			header("location: vwEmployee.php?v=0");
		}
		else
		{
			header("location: ctrlEmployee.php?mode=edit&eid=".$eid);
		}
	}
}
?>