<?php
class erpClass {
	
	function splitCSV($val)
	{
		echo "abc";
		//return "abcde"
		//return $arrSelVal, $arrSelValCnt;
	}
	
	function LongueActivity($process, $doneby, $startdatetime, $enddatetime, $createdby, $machine, $remark)
	{
		echo "INSERT INTO ".APP."txntimesheet (StageID, StatusID, DoneBy, StartTime, EndTime, CreatedBy, CreatedOn, MachineID, Remarks) VALUES (".$process.", ".COMPLETED.", ".$doneby.", '".$startdatetime."', '".$enddatetime."', ".$createdby.", NOW(), ".$machine.", '".$remark."')";
		$inserttimesheet = mysql_query("INSERT INTO ".APP."txntimesheet (StageID, StatusID, DoneBy, StartTime, EndTime, CreatedBy, CreatedOn, MachineID, Remarks) VALUES (".$process.", ".COMPLETED.", ".$doneby.", '".$startdatetime."', '".$enddatetime."', ".$createdby.", NOW(), ".$machine.", '".$remark."')") or die(mysql_error());
		
		if($inserttimesheet)
		{
			header('location:ctrlLongue.php?prcmsg=dones');
		}
		else
		{
			header('location:ctrlLongue.php?prcmsg=donef');
		}
	}

	function moveToProduction_old($productid, $workorderid, $bottle)
	{
		$userid = $_SESSION['UserID'];
		echo "INSERT INTO ".APP."txntimesheet (ProductID, WorkOrderID, StageID, StatusID, DoneBy, Quantity) VALUES (".$productid.", ".$workorderid.", ".MIXING.", ".COMPLETED.", ".$userid.", ".COUNT($bottle).")";
		
		$insTimeSheet = mysql_query("INSERT INTO ".APP."txntimesheet (ProductID, WorkOrderID, StageID, StatusID, DoneBy, Quantity) VALUES (".$productid.", ".$workorderid.", ".MIXING.", ".COMPLETED.", ".$userid.", ".COUNT($bottle).")") or die(mysql_error());
		
		if($insTimeSheet)
		{
			for($b = 0;$b < COUNT($bottle);$b++)
			{
				echo "UPDATE ".APP."txnmetadata SET LastModBy = ".$userid.", LastModOn = NOW(), StageID = NULL, StatusID = ".OPEN." WHERE ID = ".$bottle[$b];
				echo "<br/>";
				$txnMetadataExe = mysql_query("UPDATE ".APP."txnmetadata SET LastModBy = ".$userid.", LastModOn = NOW(), StageID = NULL, StatusID = ".OPEN." WHERE ID = ".$bottle[$b]) or die(mysql_error());
				
				$txnMetadataStageQry = "INSERT INTO ".APP."txnmetadatastage (MetadataID, ProductID, WorkOrderID, WorkflowID, StageID, RollbackTo, Skip, Sequence, MachineID, StatusID, StandardID) SELECT DISTINCT m.ID, m.ProductID, m.WorkOrderID, wos.WorkflowID, wos.StageID, wos.RollbackTo, wos.Skip, wos.Sequence, wos.MachineID, ".NEWACTIVITY." StatusID FROM ".APP."txnmetadata m JOIN ".APP."txnworkordersetting wos ON wos.ProductID = m.ProductID AND wos.WorkOrderID = m.WorkOrderID JOIN ".APP."txnworkorder wo ON wo.ID = m.WorkOrderID WHERE m.ID = ".$bottle[$b];
				
				$txnMetadataStageExe = mysql_query($txnMetadataStageQry) or die(mysql_error());
				
				$txnMetadataStageUpdate = "UPDATE ".APP."txnmetadatastage ms, ".APP."txnmetadata m SET m.StageID = ms.StageID, ms.StatusID = ".AVAILABLE." WHERE m.ID = ".$bottle[$b]." AND ms.Sequence = 1 AND m.ID = ms.MetadataID";
				
				echo $txnMetadataStageUpdate;
				
				$txnMetadataStageUpdateExe = mysql_query($txnMetadataStageUpdate) or die(mysql_error());
				
			}
			header('location:vwMixing.php');
		}
		else
		{
			header('location:ctrlMixing.php?mode=edit&woid='.$workorderid);
		}
		
	}

	function moveToProduction($productid, $workorderid, $bottle)
	{
		$userid = $_SESSION['UserID'];
		echo "INSERT INTO ".APP."txntimesheet (ProductID, WorkOrderID, StageID, StatusID, DoneBy, Quantity) VALUES (".$productid.", ".$workorderid.", ".MIXING.", ".COMPLETED.", ".$userid.", ".COUNT($bottle).")";
		
		$insTimeSheet = 1;//mysql_query("INSERT INTO txntimesheet (ProductID, WorkOrderID, StageID, StatusID, DoneBy, Quantity) VALUES (".$productid.", ".$workorderid.", ".MIXING.", ".COMPLETED.", ".$userid.", ".COUNT($bottle).")");
		
		if($insTimeSheet)
		{
			$metaCnt = mysql_num_rows(mysql_query("SELECT 1 FROM ".APP."txnmetadatastage WHERE ProductID = ".$productid." AND WorkOrderID = ".$workorderid));
			echo $metaCnt;

			if($metaCnt)
			{
				echo "123";
				$txnMetadataStageUpdate = "UPDATE ".APP."txnmetadatastage a JOIN (SELECT MIN(ID) ID FROM ".APP."txnmetadatastage WHERE WorkOrderID = ".$workorderid.") b ON b.ID = a.ID JOIN ".APP."txnworkorder wo ON wo.ID = a.WorkOrderID SET a.InputQuantity = (a.InputQuantity + (".COUNT($bottle)." * wo.Pieces)), a.PendingQuantity = (a.PendingQuantity + (".COUNT($bottle)." * wo.Pieces)), wo.StageID = a.StageID, a.StatusID = ".AVAILABLE.", wo.LastModBy = ".$userid.", wo.LastModOn = NOW()";
				echo $txnMetadataStageUpdate;
				$txnMetadataStageUpdateExe = mysql_query($txnMetadataStageUpdate) or die(mysql_error());
				for($b = 0;$b < COUNT($bottle);$b++)
				{
					$uptMetdata = "UPDATE ".APP."txnmetadata SET LastModBy = ".$userid.", LastModOn = NOW(), StageID = NULL, StatusID = ".INPROGRESS." WHERE ID = ".$bottle[$b];
					echo $uptMetdata;
					$txnMetadataExe = mysql_query($uptMetdata) or die(mysql_error());
				}
				
				if($txnMetadataStageUpdateExe)
				{
					header('location:vwMixing.php');
				}
				else
				{
					header('location:ctrlMixing.php?mode=edit&woid='.$workorderid);
				}
				
			}
			else
			{
				$txnMetadataStageQry = "INSERT INTO ".APP."txnmetadatastage (StandardID, WorkOrderID, ProductID, WorkflowID, StageID, RollbackTo, Skip, StatusID) SELECT DISTINCT wo.StandardID, wo.ID, wo.ProductID, wos.WorkflowID, wos.StageID, wos.RollbackTo, wos.Skip, ".NEWACTIVITY." StatusID FROM ".APP."txnworkorder wo JOIN ".APP."txnworkordersetting wos ON wos.WorkOrderID = wo.ID WHERE wo.ID = ".$workorderid;

				$txnMetadataStageUpdate = "UPDATE ".APP."txnmetadatastage a JOIN (SELECT MIN(ID) ID FROM ".APP."txnmetadatastage WHERE WorkOrderID = ".$workorderid.") b ON b.ID = a.ID JOIN ".APP."txnworkorder wo ON wo.ID = a.WorkOrderID SET a.InputQuantity = (a.InputQuantity + (".COUNT($bottle)." * wo.Pieces)), a.PendingQuantity = (a.PendingQuantity + (".COUNT($bottle)." * wo.Pieces)), wo.StageID = a.StageID, a.StatusID = ".AVAILABLE.", wo.LastModBy = ".$userid.", wo.LastModOn = NOW(), wo.StatusID = ".INPROGRESS;
				
				$updSeq = "UPDATE (select @rownum:=@rownum+1 No, ID from ".APP."txnmetadatastage, (SELECT @rownum:=0) r where workorderid = ".$workorderid.") a JOIN ".APP."txnmetadatastage b ON b.ID = a.ID SET b.Sequence = a.No";

				$txnMetadataStageExe = mysql_query($txnMetadataStageQry) or die(mysql_error());
				
				$txnMetadataStageUpdateExe = mysql_query($txnMetadataStageUpdate) or die(mysql_error());
				
				$updSeqExe = mysql_query($updSeq) or die(mysql_error());
				
				for($b = 0;$b < COUNT($bottle);$b++)
				{
					$uptMetdata = "UPDATE ".APP."txnmetadata SET LastModBy = ".$userid.", LastModOn = NOW(), StageID = NULL, StatusID = ".INPROGRESS." WHERE ID = ".$bottle[$b];
					echo $uptMetdata;
					$txnMetadataExe = mysql_query($uptMetdata) or die(mysql_error());
				}
				if($txnMetadataStageExe && $txnMetadataStageUpdateExe && $updSeqExe)
				{
					header('location:vwMixing.php');
				}
				else
				{
					header('location:ctrlMixing.php?mode=edit&woid='.$workorderid);
				}
			}


		}
		else
		{
			header('location:ctrlMixing.php?mode=edit&woid='.$workorderid);
		}
		
	}
	
	function productionEntry($mtStgId, $seq, $InQty, $OutQty, $RejQty, $PenQty, $temperature, $pressure, $weight, $time, $density, $hardness, $employee, $startdatetime, $enddatetime, $machineid, $skipQty, $skipTo, $rollbackQty, $rollbackTo)
	{
		$userid = $_SESSION['UserID'];
		$lastStgFlag = 0;
		$getmetadatainfo = mysql_fetch_array(mysql_query("SELECT IF(b.ID IS NULL, 0, b.ID) NextMetaStageID, a.WorkOrderID FROM ".APP."txnmetadatastage a LEFT OUTER JOIN ".APP."txnmetadatastage b ON b.ProductID = a.ProductID AND b.WorkOrderID = a.WorkOrderID AND b.Sequence = (a.Sequence + 1) WHERE a.ID = ".$mtStgId)) or die(mysql_error());
		
		$logMaxSeq = mysql_fetch_array(mysql_query("SELECT MAX(Sequence) Sequence FROM ".APP."txnsettinglog WHERE MetadataStageID = ".$mtStgId)) or die(mysql_error());
		
		if($logMaxSeq['Sequence'])
		{
			$logSeq = $logMaxSeq['Sequence'] + 1;
		}
		else
		{
			$logSeq = 1;
		}
		
		if($seq == $getmetadatainfo['MaxSeq'])
		{
			$lastStgFlag = 1;
		}
		
		if(COUNT($employee) > 1)
		{
			$IsShared = 1;
		}
		else
		{
			$IsShared = 0;
		}
		for($e = 0;$e < COUNT($employee); $e++)
		{
			$logInsQry = "INSERT INTO ".APP."txnmetadatastagelog (MetadataStageID, StartTime, EndTime, InputQuantity, OutputQuantity, DoneBy, CreatedBy, IsShared, RejectedQuantity, ReprocessQuantity, SkippedQuantity) VALUES (".$mtStgId.", '".$startdatetime."', '".$enddatetime."', ".$InQty.", ".$OutQty.", ".$employee[$e].", ".$userid.", ".$IsShared.", ".$RejQty.", ".$rollbackQty.", ".$skipQty.")";
			//echo $logInsQry;
			mysql_query($logInsQry) or die(mysql_error());
			$metadataStgLogID = mysql_insert_id();
			
			for($i = 0;$i < count($temperature);$i++)
			{				
				$temperatureValue = $temperature[$i];
				$tseq = $i + 1;
				
				$tempQry = "INSERT INTO ".APP."txnsettinglog (MetadataStageID, AttributeID, Value, MachineID, Sequence, CreatedOn, ValueSequence, MetadataStageLogID) VALUES(".$mtStgId.", ".TEMPERATURE.", '".$temperatureValue."', ".$machineid.", ".$logSeq.", '".$startdatetime."', ".$tseq.", ".$metadataStgLogID.")";
				//echo $tempQry."<br/>";
				mysql_query($tempQry) or die(mysql_error());
			}
			for($i = 0;$i < count($pressure);$i++)
			{				
				$pressureValue = $pressure[$i];
				$pseq = $i + 1;
				$pressQry = "INSERT INTO ".APP."txnsettinglog (MetadataStageID, AttributeID, Value, MachineID, Sequence, CreatedOn, ValueSequence, MetadataStageLogID) VALUES(".$mtStgId.", ".PRESSURE.", '".$pressureValue."', ".$machineid.", ".$logSeq.", '".$startdatetime."', ".$pseq.", ".$metadataStgLogID.")";
				//echo $pressQry."<br/>";
				mysql_query($pressQry) or die(mysql_error());
			}
			for($i = 0;$i < count($time);$i++)
			{				
				$timeValue = $time[$i];
				$tmseq = $i + 1;
				$timeQry = "INSERT INTO ".APP."txnsettinglog (MetadataStageID, AttributeID, Value, MachineID, Sequence, CreatedOn, ValueSequence, MetadataStageLogID) VALUES(".$mtStgId.", ".TIME.", '".$timeValue."', ".$machineid.", ".$logSeq.", '".$startdatetime."', ".$tmseq.", ".$metadataStgLogID.")";
				echo $timeQry."<br/>";
				mysql_query($timeQry) or die(mysql_error());
			}
			for($i = 0;$i < count($weight);$i++)
			{				
				$weightValue = $weight[$i];
				$wseq = $i + 1;
				$weightQry = "INSERT INTO ".APP."txnsettinglog (MetadataStageID, AttributeID, Value, MachineID, Sequence, CreatedOn, ValueSequence, MetadataStageLogID) VALUES(".$mtStgId.", ".WEIGHT.", '".$weightValue."', ".$machineid.", ".$logSeq.", '".$startdatetime."', ".$wseq.", ".$metadataStgLogID.")";
				echo $weightQry."<br/>";
				mysql_query($weightQry) or die(mysql_error());
			}
			for($i = 0;$i < count($density);$i++)
			{				
				$densityValue = $density[$i];
				$dseq = $i + 1;
				$densityQry = "INSERT INTO ".APP."txnsettinglog (MetadataStageID, AttributeID, Value, MachineID, Sequence, CreatedOn, ValueSequence, MetadataStageLogID) VALUES(".$mtStgId.", ".DENSITY.", '".$densityValue."', ".$machineid.", ".$logSeq.", '".$startdatetime."', ".$dseq.", ".$metadataStgLogID.")";
				echo $densityQry."<br/>";
				mysql_query($densityQry) or die(mysql_error());
			}
			for($i = 0;$i < count($hardness);$i++)
			{				
				$hardnessValue = $hardness[$i];
				$hseq = $i + 1;
				$hardnessQry = "INSERT INTO ".APP."txnsettinglog (MetadataStageID, AttributeID, Value, MachineID, Sequence, CreatedOn, ValueSequence, MetadataStageLogID) VALUES(".$mtStgId.", ".HARDNESS.", '".$hardnessValue."', ".$machineid.", ".$logSeq.", '".$startdatetime."', ".$hseq.", ".$metadataStgLogID.")";
				echo $hardnessQry."<br/>";
				mysql_query($hardnessQry) or die(mysql_error());
			}
		}

		$updMetaQtyQry = "UPDATE ".APP."txnmetadatastage SET OutputQuantity = (OutputQuantity + ".$OutQty."), RejectedQuantity = (RejectedQuantity + ".$RejQty."), PendingQuantity = (".$PenQty."), ReprocessQuantity = (ReprocessQuantity + ".$rollbackQty.") WHERE ID = ".$mtStgId;
		mysql_query($updMetaQtyQry) or die(mysql_error());
		
		if($PenQty <= 0)
		{
			$updMetaStatusQry = "UPDATE ".APP."txnmetadatastage SET StatusID = ".COMPLETED." WHERE ID = ".$mtStgId;			
		}
		else
		{
			$updMetaStatusQry = "UPDATE ".APP."txnmetadatastage SET StatusID = ".AVAILABLE." WHERE ID = ".$mtStgId;
		}
		mysql_query($updMetaStatusQry) or die(mysql_error());
		if($getmetadatainfo)
		{
			$updMetaQtyNextSeqQry = "UPDATE ".APP."txnmetadatastage SET InputQuantity = IF(StatusID = ".COMPLETED.", ".$OutQty.", (InputQuantity + ".$OutQty.")), StatusID = ".AVAILABLE.", PendingQuantity = PendingQuantity + ".$OutQty." WHERE ID = ".$getmetadatainfo['NextMetaStageID'];
			mysql_query($updMetaQtyNextSeqQry) or die(mysql_error());
		}
		
		if($skipQty > 0)
		{
			$skipUpdQry = "UPDATE ".APP."txnmetadatastage SET InputQuantity = InputQuantity + ".$skipQty.", StatusID = ".AVAILABLE." WHERE ID = ".$skipTo;
			$skipUpdCurrID = "UPDATE ".APP."txnmetadatastage SET IsSkipped = 1, SkippedQuantity = SkippedQuantity + ".$skipQty." WHERE ID = ".$mtStgId;
			mysql_query($skipUpdQry) or die(mysql_error());
			mysql_query($skipUpdCurrID) or die(mysql_error());
		}

		if($rollbackQty > 0)
		{
			$FromStageID = mysql_fetch_array(mysql_query("SELECT StageID, WorkOrderID FROM ".APP."txnmetadatastage WHERE ID = ".$rollbackTo)) or die(mysql_error());
			$ToStageID = mysql_fetch_array(mysql_query("SELECT StageID FROM ".APP."txnmetadatastage WHERE ID = ".$mtStgId)) or die(mysql_error());
			$rollbackUpdQry = "UPDATE ".APP."txnmetadatastage SET PendingQuantity = PendingQuantity + ".$rollbackQty.", StatusID = ".AVAILABLE." WHERE ID = ".$rollbackTo;
			$rollbackInsQry = "INSERT INTO ".APP."txnrollbacklog (FromID, ToID, FromStageID, ToStageID, LastModBy, LastModOn, WorkOrderID, Quantity) VALUES (".$mtStgId.", ".$rollbackTo.", ".$ToStageID['StageID'].", ".$FromStageID['StageID'].", ".$userid.", NOW(), ".$FromStageID['WorkOrderID'].", ".$rollbackQty.")";
			echo $rollbackUpdQry;
			echo "<br/>";
			echo $rollbackInsQry;
			mysql_query($rollbackUpdQry) or die(mysql_error());
			mysql_query($rollbackInsQry) or die(mysql_error());
		}

		//change to Status as COMPLETED of WO
		$preStgPenQty = mysql_fetch_array(mysql_query("SELECT SUM(PendingQuantity) PenQty FROM ".APP."txnmetadatastage WHERE WorkOrderID = ".$getmetadatainfo['WorkOrderID']." AND ID <> ".$mtStgId)) or die(mysql_error());
		echo $getmetadatainfo['NextMetaStageID']." - ".$rollbackQty." - ".$PenQty." - ".$preStgPenQty['PenQty'];
		if($getmetadatainfo['NextMetaStageID'] == 0 && $rollbackQty == 0 && $PenQty <= 0 && $preStgPenQty['PenQty'] <= 0)
		{
			echo "if...";
			$WOCompleted = mysql_query("UPDATE ".APP."txnworkorder SET StatusID = ".COMPLETED." WHERE ID = ".$getmetadatainfo['WorkOrderID']) or die(mysql_error());
			$MetadataCompleted = mysql_query("UPDATE ".APP."txnmetadata SET StatusID = ".COMPLETED." WHERE WorkorderID = ".$getmetadatainfo['WorkOrderID']) or die(mysql_error());
		}
		header("location:vwMyTask.php?woid=".$getmetadatainfo['WorkOrderID']."&disp=1");			
	}
}
?>