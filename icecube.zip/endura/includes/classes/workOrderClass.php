<?php
class workOrderClass {
	
	//public $s_userid = $_SESSION['UserID'];

	function addWorkOrder($workordercode, $productid, $woquantity, $pfselect, $wopieces, $stdselect, $woduedate)
	{
		$userid = $_SESSION['UserID'];
		
		$updateDocType = mysql_query("UPDATE ".APP."cfgdocumenttype set `CurrentRange` = CurrentRange + 1, LastModBy = ".$userid.", LastModOn = NOW() WHERE `OBJECTTYPEID` = 7") or die(mysql_error());
		
		$insWO = "INSERT INTO ".APP."txnworkorder (Code, ProductID, WorkFlowID, Quantity, CreatedBy, CreatedOn, LastModBy, LastModOn, Pieces, StandardID, StatusID, DueDate) VALUES ('".$workordercode."', ".$productid.", '".$pfselect."', ".$woquantity.", ".$userid.", NOW(), ".$userid.", NOW(), ".$wopieces.", ".$stdselect.", ".OPEN.", '".$woduedate."')";
		echo $insWO;
		
		$woInsert = mysql_query($insWO) or die(mysql_error());
		
		if($woInsert && $updateDocType)
		{
			header("location:vwWorkOrder.php");
		}
		else
		{
			header("location:ctrlWorkOrder.php?mode=add&prdid".$productid);
		}
	}
	
	function updateWorkOrder($woid, $wopieces, $woquantity, $userid, $woduedate)
	{
		$updWO = "UPDATE ".APP."txnworkorder SET DueDate = '".$woduedate."', Quantity = ".$woquantity.", Pieces = ".$wopieces.", LastModOn = NOW(), LastModBy = ".$userid." WHERE ID = ".$woid;
		mysql_query("START TRANSACTION");
		$upd = mysql_query($updWO) or die(mysql_error());
		
		if($upd)
		{
			mysql_query("COMMIT");
			header("location:vwWorkOrder.php");
		}
		else
		{
			mysql_query("ROLLBACK");
			header("location:ctrlWorkOrder.php?mode=edit&woid".$woid);
		}
		
	}
	
	function updateWorkOrderSetting($workorderid, $pfselect, $pfStageID, $machine, $temperature, $pressure, $productid, $time, $weight, $density, $hardness, $seq, $target)
	{
		$userid = $_SESSION['UserID'];
		$seqno = $seq + 1;
		for($i = 0;$i < count($target);$i++)
		{
			$targetValue = trim($target[$i]);
			if($targetValue)
			{
				if($machine)
				{
					echo "INSERT INTO ".APP."txnworkordertarget (WorkorderID, ProductID, WorkflowID, StageID, MachineID, Target, LastModBy, LastModOn) VALUES (".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".$targetValue.", ".$userid.", now())";
					echo "<br/>";
					$targetInsert = mysql_query("INSERT INTO ".APP."txnworkordertarget (WorkorderID, ProductID, WorkflowID, StageID, MachineID, Target, LastModBy, LastModOn) VALUES (".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".$targetValue.", ".$userid.", now())") or die(mysql_error());
				}
				else
				{
					echo "INSERT INTO ".APP."txnworkordertarget (WorkorderID, ProductID, WorkflowID, StageID, Target, LastModBy, LastModOn) VALUES (".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$targetValue.", ".$userid.", now())";
					echo "<br/>";
					$targetInsert = mysql_query("INSERT INTO ".APP."txnworkordertarget (WorkorderID, ProductID, WorkflowID, StageID, Target, LastModBy, LastModOn) VALUES (".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$targetValue.", ".$userid.", now())") or die(mysql_error());
				}
			}
		}

		if($machine)
		{
			for($i = 0;$i < count($temperature);$i++)
			{
				$temperatureValue = $temperature[$i];
				$tseq = $i + 1;
				$woWkFlowStageMachineTemperature = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, MachineID, AttributeID, Value, LastModBy, LastModOn, Sequence, ValueSequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".TEMPERATURE.", '".$temperatureValue."', ".$userid.", now(), ".$seqno.", ".$tseq.")") or die(mysql_error());
			}
			for($i = 0;$i < count($pressure);$i++)
			{				
				$pressureValue = $pressure[$i];
				$pseq = $i + 1;
				$woWkFlowStageMachinePressure = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, MachineID, AttributeID, Value, LastModBy, LastModOn, Sequence, ValueSequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".PRESSURE.", '".$pressureValue."', ".$userid.", now(), ".$seqno.", ".$pseq.")") or die(mysql_error()) or die(mysql_error());
			}
			for($i = 0;$i < count($time);$i++)
			{				
				$timeValue = $time[$i];
				$tmseq = $i + 1;
				$woWkFlowStageMachinePressure = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, MachineID, AttributeID, Value, LastModBy, LastModOn, Sequence, ValueSequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".TIME.", '".$timeValue."', ".$userid.", now(), ".$seqno.", ".$tmseq.")") or die(mysql_error()) or die(mysql_error());
			}
			for($i = 0;$i < count($weight);$i++)
			{				
				$weightValue = $weight[$i];
				$wseq = $i + 1;
				$woWkFlowStageMachinePressure = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, MachineID, AttributeID, Value, LastModBy, LastModOn, Sequence, ValueSequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".WEIGHT.", '".$weightValue."', ".$userid.", now(), ".$seqno.", ".$wseq.")") or die(mysql_error()) or die(mysql_error());
			}
			for($i = 0;$i < count($density);$i++)
			{				
				$densityValue = $density[$i];
				$dseq = $i + 1;
				$woWkFlowStageMachinePressure = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, MachineID, AttributeID, Value, LastModBy, LastModOn, Sequence, ValueSequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".DENSITY.", '".$densityValue."', ".$userid.", now(), ".$seqno.", ".$dseq.")") or die(mysql_error()) or die(mysql_error());
			}
			for($i = 0;$i < count($hardness);$i++)
			{				
				$hardnessValue = $hardness[$i];
				$hseq = $i + 1;
				$woWkFlowStageMachinePressure = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, MachineID, AttributeID, Value, LastModBy, LastModOn, Sequence, ValueSequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$machine.", ".HARDNESS.", '".$hardnessValue."', ".$userid.", now(), ".$seqno.", ".$hseq.")") or die(mysql_error()) or die(mysql_error());
			}
		}
		else
		{echo "else";
			echo "INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, LastModBy, LastModOn, Sequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$userid.", now(), ".$seqno.")";
			echo "<br/>";
			$woWkFlowStageMachine = mysql_query("INSERT INTO ".APP."txnworkordersetting (WorkOrderID, ProductID, WorkflowID, StageID, LastModBy, LastModOn, Sequence) VALUES(".$workorderid.", ".$productid.", ".$pfselect.", ".$pfStageID.", ".$userid.", now(), ".$seqno.")") or die(mysql_error());
		}
	}
}
?>