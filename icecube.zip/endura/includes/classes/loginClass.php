<?php
class LoginClass{
	
//-----------Login Check for the Authenticated Users---------------------
	function userAuthentic($username, $password, $rememberMe) {
		$uname = strip_tags(addslashes($username));
		$pword = strip_tags(addslashes($password));
		$pword1 = md5($pword);

		$user_Qry = mysql_query("SELECT me.ID UserID, me.EmployeeCode, me.Name UserName, me.RoleID, r.Description Role FROM ".APP."mstremployee me JOIN ".APP."lurole r ON r.ID = me.RoleID WHERE me.EmployeeCode = '".$uname."' AND me.Password = '".$pword1."' AND me.IsActive = 1") or die(mysql_error());
		
			if(mysql_num_rows($user_Qry) == 1) {
				session_unset();
				$user = mysql_fetch_array($user_Qry);
				//-------Setting Values In SESSION-----------
				
				$_SESSION['UserName'] = $user['UserName'];				
				$_SESSION['UserID'] = $user['UserID'];
				$_SESSION['EmployeeCode'] = $user['EmployeeCode'];
				$_SESSION['RoleID'] = $user['RoleID'];
				$_SESSION['Role'] = $user['Role'];

				//-------Setting Values In COOKIES-----------				
				if(isset($rememberMe)) {
					setcookie("username", $username, time()+3600*24*2);
					setcookie("password", $password, time()+3600*24*2);
				}
				else
				{
					setcookie("username", "", time()-3600*24*2);
					setcookie("password", "", time()-3600*24*2);
				}
				
				$currentdate = date("Y-m-d");
				header("location: dashboard.php");
			}
			else
			{
				$_SESSION['logoutinfo'] = "fail";
				header("location: index.php?result=".$_SESSION['logoutinfo']);
			}
	}
}
?>