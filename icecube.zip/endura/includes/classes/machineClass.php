<?php
class machineClass {

	function addMachine($machineCode, $machineName, $machineDesc)
	{
		$updateDocType = mysql_query("UPDATE ".APP."cfgdocumenttype set `CurrentRange` = CurrentRange +1  WHERE `OBJECTTYPEID` = 4") or die(mysql_error());
		
		$machine = mysql_query("INSERT INTO ".APP."lumachine (Code, MachineName, Description, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES ('".$machineCode."' , '".$machineName."' , '".$machineDesc."', ".$_SESSION['UserID'].", now(), ".$_SESSION['UserID'].", now())") or die(mysql_error());

		if($machine && $updateDocType)
		{
			$_SESSION['prcmsg'] = 'dones';
			header("location:vwmachine.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'donef';
			header("location:vwmachine.php");
		}
	}
	
	function updateMachine($machineId, $machineName, $machineDesc)
	{
		$machine = mysql_query("UPDATE ".APP."lumachine SET MachineName = '".$machineName."' , Description = '".$machineDesc."', LastModOn = now(), LastModBy = ".$_SESSION['UserID']." where ID = ".$machineId) or die(mysql_error());
		
		if($machine)
		{
			$_SESSION['prcmsg'] = 'upds';
			header("location:vwmachine.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'updf';
			header("location:vwmachine.php");
		}
	}

	function deleteMachine($machineId)
	{
		$machine = mysql_query("UPDATE ".APP."lumachine SET IsActive = 0, LastModOn = now(), LastModBy = ".$_SESSION['UserID']." where ID = ".$machineId) or die(mysql_error());
		
		if($machine)
		{
			$_SESSION['prcmsg'] = 'ds';
			header("location:vwmachine.php");
		}
		else
		{
			$_SESSION['prcmsg'] = 'df';
			header("location:vwmachine.php");
		}
	}	
}
?>