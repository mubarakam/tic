<?php
class productClass {
	
	//$userid = $_SESSION['UserID'];

	function addProduct($productcode, $productname, $parentproduct, $productflow, $diamond, $bond, $bottleweight, $standard)
	{
		$userid = $_SESSION['UserID'];
		
		$updateDocType = mysql_query("UPDATE ".APP."cfgdocumenttype set `CurrentRange` = CurrentRange + 1, LastModBy = ".$userid.", LastModOn = NOW() WHERE `OBJECTTYPEID` = 2") or die(mysql_error());
	
		$productInsert = mysql_query("INSERT INTO ".APP."mstrproduct (ProductName, WorkFlowID, Code, CreatedBy, CreatedOn, LastModBy, LastModOn, IsParent, ParentID, DiamondID, BondID, BottleWeight, StandardID) VALUES ('".$productname."', ".$productflow.", '".$productcode."', ".$userid.", NOW(), ".$userid.", NOW(), 0, ".$parentproduct.", ".$diamond.", ".$bond.", ".$bottleweight.", ".$standard.")") or die(mysql_error());
		
		if($productInsert && $updateDocType)
		{
			header("location:vwProduct.php?mode=ci");
		}
		else
		{
			header("location:ctrlProduct.php?mode=addci");
		}
	}

	function addParent($productcode, $productname, $delivermode, $uomnumber)
	{
		$userid = $_SESSION['UserID'];
		echo $delivermode;
		$updateDocType = mysql_query("UPDATE ".APP."cfgdocumenttype set `CurrentRange` = CurrentRange + 1, LastModBy = ".$userid.", LastModOn = NOW() WHERE `OBJECTTYPEID` = 1") or die(mysql_error());
		
		$insQry = "INSERT INTO ".APP."mstrproduct (ProductName, Code, CreatedBy, CreatedOn, LastModBy, LastModOn, IsParent, DeliveryMode, DeliveryValue) VALUES ('".$productname."', '".$productcode."', ".$userid.", NOW(), ".$userid.", NOW(), 1, ".$delivermode.", '".$uomnumber."')";
		echo $insQry;
		
		$productInsert = mysql_query($insQry) or die(mysql_error());
		
		if($productInsert && $updateDocType)
		{
			header("location:vwProduct.php");
		}
		else
		{
			header("location:ctrlProduct.php?mode=addpar");
		}
	}

	function updateParent($productid, $productname, $delivermode, $uomnumber)
	{
		$userid = $_SESSION['UserID'];
		
		$updQry = "UPDATE ".APP."mstrproduct SET ProductName = '".$productname."', LastModBy = ".$userid.", LastModOn = NOW(), DeliveryMode = ".$delivermode.", DeliveryValue = '".$uomnumber."' WHERE ID = ".$productid;
		
		echo $updQry;

		
		$productupdate = mysql_query($updQry) or die(mysql_error());
		
		if($productupdate)
		{
			header("location:vwProduct.php");
		}
		else
		{
			header("location:ctrlProduct.php?mode=editpar");
		}
	}
	
	function updateProduct($productid, $productname, $parentproduct, $productflow, $diamond, $bond, $bottleweight, $standard)
	{
		$userid = $_SESSION['UserID'];
		
		$productupdate = mysql_query("UPDATE ".APP."mstrproduct SET ProductName = '".$productname."', WorkFlowID = ".$productflow.", ParentID = ".$parentproduct.", LastModBy = ".$userid.", LastModOn = NOW(), DiamondID = ".$diamond.", BondID = ".$bond.", BottleWeight = ".$bottleweight.", StandardID = ".$standard." WHERE ID = ".$productid) or die(mysql_error());
		
		if($productupdate)
		{
			header("location:vwProduct.php?mode=ci");
		}
		else
		{
			header("location:ctrlProduct.php?mode=editci");
		}
	}
}



?>