<?php
include('meta_script_link.php');
?><head>
<style>
input.error {
    border: 1px dotted red;
	background-color:#FD9A95 !important;
}
select.error {
    border: 1px dotted red;
	background-color:#FD9A95 !important;
}
/* ===== Chosen multiple select plugin with dropdown ===== */
.chzn-container { position: relative; display: inline-block; zoom: 1; *display: inline; max-width: 100%; }
.noSearch .chzn-search, .searchDrop .selector, .noSearch .selector { display: none; }
.noSearch .chzn-results { margin: 0!important; padding: 2px!important; }
.chzn-container > .chzn-drop { background: #fff; border: 1px solid #d5d5d5; border-top: 0; position: absolute; top: 29px; margin-top: 1px; left: 0; z-index: 998; width: 100%!important; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; -ms-box-sizing: border-box; box-sizing: border-box; }
.chzn-container-single .chzn-single { border: 1px solid #d8d8d8; display: block; overflow: hidden; white-space: nowrap; position: relative; color: #808080; text-shadow: 0 1px #f5f5f5; height: 27px; line-height: 27px; padding: 0 0 0 10px; background: #fcfcfc; background: -moz-linear-gradient(top,  #fcfcfc 0%, #f1f1f1 100%); background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fcfcfc), color-stop(100%,#f1f1f1)); background: -webkit-linear-gradient(top,  #fcfcfc 0%,#f1f1f1 100%); background: -o-linear-gradient(top,  #fcfcfc 0%,#f1f1f1 100%); background: -ms-linear-gradient(top,  #fcfcfc 0%,#f1f1f1 100%); background: linear-gradient(top,  #fcfcfc 0%,#f1f1f1 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#fcfcfc', endColorstr='#f1f1f1',GradientType=0 ); border: 1px solid #d2d2d2;  box-sizing: content-box; border-radius: 2px; -webkit-border-radius: 2px; -moz-border-radius: 2px;  box-shadow: 0 1px 0 #fff inset, 0 1px 0px #eeeeee; -webkit-box-shadow: 0 1px 0 #fff inset, 0 1px 0px #eeeeee; -moz-box-shadow: 0 1px 0 #fff inset, 0 1px 0px #eeeeee; }
.chzn-container-single .chzn-single span { display: block; font-size: 11px; padding-right: 30px; overflow: hidden; white-space: nowrap; -o-text-overflow: ellipsis; -ms-text-overflow: ellipsis; text-overflow: ellipsis; background: url(../images/elements/forms/selectArrow.png) no-repeat 100%; }
.chzn-container-single .chzn-single abbr { display: block; position: absolute; right: 26px; top: 6px; width: 12px; height: 13px; font-size: 1px; }
.chzn-container-single .chzn-single div { position: absolute; right: -1px; top: -1px; display: block; height: 27px; width: 27px; }
.chzn-container-single .chzn-single div b { display: block; width: 27px; height: 28px; }
.chzn-container-single .chzn-search { padding: 3px 4px; position: relative; margin: 0; white-space: nowrap; z-index: 1010; }
.chzn-container-single .chzn-search input { margin: 1px 0; padding: 4px 20px 4px 5px; outline: 0; border: 1px solid #aaa; font-family: sans-serif; font-size: 11px; background: url(../images/searchSmall.png) no-repeat 98% !important; box-sizing: border-box; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; -ms-box-sizing: border-box; max-width: 100%; min-width: 100%; }
.chzn-container-single-nosearch .chzn-search input { position: absolute; left: -9000px; }
.chzn-container-multi .chzn-choices { border: 1px solid #ddd; margin: 0; cursor: text; overflow: hidden; height: auto !important; height: 1%; position: relative; font-size: 12px; padding: 4px; background: white; color: #656565;  }
.chzn-container-multi .chzn-choices li { float: left; list-style: none; }
.chzn-container-multi .chzn-choices .search-field { white-space: nowrap; margin: 0; padding: 0; }
.chzn-container-multi .chzn-choices .search-field input { color: #666; background: transparent !important; border: 0 !important; font-family: sans-serif; font-size: 12px!important; padding: 11px 4px 10px 4px!important; margin: 0; outline: 0; box-shadow: none!important; }
.chzn-container-multi .chzn-choices .search-field .default { color: #999; }
.chzn-container-multi .chzn-choices .search-choice { position: relative; line-height: 16px; font-size: 11px; border: 1px solid #A5D24A; display: block; float: left; padding: 5px 24px 5px 8px; background: #CDE69C; color: #638421; margin: 4px; }
.chzn-container-multi .chzn-choices .search-choice-focus { background: #d4d4d4; }
.chzn-container-multi .chzn-choices .search-choice .search-choice-close { display: block; position: absolute; right: 6px; top: 8px; width: 10px; height: 10px; font-size: 1px; background: url(../images/elements/forms/closeSelection.png) 50% no-repeat; }
.chzn-container-multi .chzn-choices .search-choice-focus .search-choice-close { background-position: right -11px; }
.chzn-container .chzn-results { margin: 0 4px 4px 0; max-height: 240px; padding: 0 0 0 4px; position: relative; overflow-x: hidden; overflow-y: auto; }
.chzn-container-multi .chzn-results { padding: 0; margin: 0; }
.chzn-container .chzn-results li { display: none; line-height: 14px; padding: 5px 6px; margin: 0; list-style: none; font-size: 11px; }
.chzn-container .chzn-results .active-result { cursor: pointer; display: list-item; }
.chzn-container .chzn-results .highlighted { background-color: #3875d7; color: #fff; }
.chzn-container .chzn-results li em { background: #feffde; font-style: normal; }
.chzn-container .chzn-results .highlighted em { background: transparent; }
.chzn-container .chzn-results .no-results { background: #f4f4f4; display: list-item; }
.chzn-container .chzn-results .group-result { cursor: default; color: #2e74a6; font-weight: bold; font-size: 10px; border-bottom: 1px solid #DDD; border-top: 1px solid #DDD; }
.chzn-container .chzn-results .group-option { padding-left: 15px; }
.chzn-container-multi .chzn-drop .result-selected { display: none; }
.chzn-container .chzn-results-scroll { background: white; margin: 0 4px; position: absolute; text-align: center; width: 321px; /* This should be dynamic with js */ z-index: 1; }
.chzn-container .chzn-results-scroll span { display: inline-block; height: 17px; text-indent: -5000px; width: 9px; }
.chzn-container .chzn-results-scroll-down { bottom: 0; }
.chzn-container-active .chzn-single-with-drop div { background: transparent; border-left: none; }
.chzn-container-active .chzn-choices { border: 1px solid #d5d5d5; }
.chzn-container-active .chzn-choices .search-field input { color: #111 !important; }
.chzn-disabled { cursor: default; opacity:0.5 !important; }
.chzn-disabled .chzn-single { cursor: default; }
.chzn-disabled .chzn-choices .search-choice .search-choice-close { cursor: default; }
.msg_error1 {
	background-color: #FFBABA;
	background-image: url("images/msg_error.png");
	color: #D8000C;
	z-index: 1000 !important;
}
.msg_success, .msg_error1, .msg_info {
	background-repeat: no-repeat;
	margin: 10px 0;

	z-index: 1000 !important;
}
#errmsg {
	color: red;
}
</style>

<input type="hidden" id="curryear" name="curryear" value="<?php echo date("y"); ?>" />
<input type="hidden" id="currmon" name="currmon" value="<?php echo date("m"); ?>" />
<input type="hidden" id="currday" name="currday" value="<?php echo date("d"); ?>" />
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script type="text/javascript" src="script/jquery.chosen.min.js"></script>
<script type="text/javascript" src="script/jquery-ui.min.js"></script>
 <script type="text/javascript" src="js/jquery.blockUI.js"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
function wopreview()
{
	alert("preview");
}
function getProductionFlow(val, woid)
{
	if(val == 'edit')
	{
		window.location = "ctrlWorkOrder.php?prdid="+document.getElementById("product").value+"&mode="+val+"&woid="+woid;
	}
	else
	{
		window.location = "ctrlWorkOrder.php?prdid="+document.getElementById("product").value+"&mode="+val;
	}
	
}

$(document).ready(function() {
	$(function() 
		{
		$(".select").chosen();
		});
	
	var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	
	$(".kpress").keypress(function (e)
	{
		e.preventDefault();
	});
	$("input[aria-controls=example]").focus();
	
	jQuery(function(){
		var curYear = document.getElementById("curryear").value;
		var curMon = document.getElementById("currmon").value;
		var curDay = document.getElementById("currday").value;
		var mindat = curDay + "-" + curMon + "-" + curYear;
                jQuery('#woduedate').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
					changeYear: true					
                });
            })
	


	   $('input[name="addworkorder"]').on('click', function(e){
		   e.preventDefault();
		   var woquantity = document.getElementById("woquantity").value;
		   var wopieces = document.getElementById("wopieces").value;
		   var wodue = document.getElementById("woduedate").value;
		   var woproduct = document.getElementById('product');
		   var woproducttext = woproduct.options[woproduct.selectedIndex].innerHTML;
		   
		   if(woproduct && woquantity && wopieces && wodue)
		   {
				$('#popuppreview').dialog('open');
				wocode.innerHTML = document.getElementById("workordercode").value;
				quantity.innerHTML = woquantity;
				pieces.innerHTML = wopieces;
				duedate.innerHTML = wodue;
				wocomponent.innerHTML = woproducttext;
		   }
		   else
		   {
			   alert("Please check the mandatory field(s), COMPONENT/QUANTITY/PIECES/DUE DATE");
		   }
		   
			   
		   

		});
		$('#popuppreview').dialog({
				autoOpen: false,
				modal: true,
				buttons: {
					"Confirm": function(e) {
						$(this).dialog('close');
						$('#workorderform').submit();


					},
					"Cancel": function() {
						$(this).dialog('close');
					}
				}
			});
});

function addTemp(val)
{
	alert(val);
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addtemperature&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}

function addPress(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addpressure&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addTime(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addtime&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addWeight(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addweight&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addDensity(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=adddensity&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addHardness(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addhardness&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}

</script>
<div class="main-container">
<?php include('includes/header.php');


####### Need to declare########
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Work Order</div>
<div class="backlink"><a href="vwWorkOrder.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
 <?php
if($_REQUEST['mode'] == 'add')
{
   $wcode = mysql_query("SELECT CONCAT(`CODE`, LPAD(`CurrentRange` + 1, 3, 0)) as code from ".APP."cfgdocumenttype where `ObjectTypeId` = 7") or die(mysql_error());
   $code = mysql_fetch_array($wcode); ?>
<div id="popuppreview" style="width:400px;height:150px;">
<p>Are you sure you want to create the WO with below detail(s)?</p>
<p>Work Order Code : <span id="wocode"></span></p>
<p>Component : <span id="wocomponent"></span></p>
<p>Quantity : <span id="quantity"></span>&nbsp;Bottle(s)</p>
<p>Piece(s) : <span id="pieces"></span></p>
<p>Due Date : <span id="duedate"></span></p>
</div>
                    <form name="workorderform" action="mdlWorkOrder.php?mode=add" method="post" id="workorderform">
                        
                        <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Work Order Code</td>
    <td colspan="3">
      <input style="width:75px;"  type="text"  maxlength="255" name="workordercode" id="workordercode" value="<?php echo $code['code']; ?>" readonly="readonly"/>
    </td>
    </tr>
  <tr>
    <td>Component Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
	<select data-placeholder="choose" class="select" id="product" name="product" onChange="getProductionFlow('add')" ><option value="">--Select--</option>
	<?php
		$product = mysql_query("SELECT ID, Code, ProductName, WorkFlowID FROM ".APP."mstrproduct WHERE IsParent = 0 AND IsActive = 1 AND StandardID IS NOT NULL ORDER BY Code, ProductName") or die(mysql_error());
		while($productrs = mysql_fetch_array($product))
		{
			?>
			<option value="<?php echo $productrs['ID']; ?>" <?php if($_REQUEST['prdid'] == $productrs['ID']) { ?> selected <?php }?> ><?php echo $productrs['Code']." - ".$productrs['ProductName']; ?></option>
			<?php
		}
	?></select>
    </td>
    </tr>
    <tr>
    <td>Quantity<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<input style="width:60px;"  type="number" min="1" name="woquantity" id="woquantity" required onkeypress="return isNumberKey(event)" />&nbsp;Bottle(s)
    </td>
  </tr>
    <tr>
    <td>Piece(s)/Bottle<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<input style="width:60px;"  type="number" min="1" name="wopieces" id="wopieces" required onkeypress="return isNumberKey(event)" />
    </td>
  </tr>
  <tr>
   <td>Production Flow</td>
   <td colspan="3">
   <?php
   
   if($_REQUEST['prdid'])
   {
	   //echo "SELECT p.WorkFlowID, wf.WorkflowName, p.StandardID, s.Name StandardName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow wf ON wf.ID = p.WorkFlowID JOIN ".APP."mstrstandard s ON s.ID = p.StandardID WHERE p.ID = ".$_REQUEST['prdid'];
	   $pfrs = mysql_fetch_array(mysql_query("SELECT p.WorkFlowID, wf.WorkflowName, p.StandardID, s.Name StandardName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow wf ON wf.ID = p.WorkFlowID JOIN ".APP."mstrstandard s ON s.ID = p.StandardID WHERE p.ID = ".$_REQUEST['prdid'])) or die(mysql_error());	   
   }
   ?>
   <input type="hidden" id="pfselect" name="pfselect" value="<?php echo $pfrs['WorkFlowID']; ?>" />
   <?php
   echo $pfrs['WorkflowName'];
   ?>
   </td>
  </tr>

  <tr>
   <td>Standard</td>
   <td colspan="3">
   <input type="hidden" id="stdselect" name="stdselect" value="<?php echo $pfrs['StandardID']; ?>" />
   <?php
   echo $pfrs['StandardName'];
   ?>
   </td>
  </tr>

<tr>
<td>Due Date</td>
<td colspan="3">
<input type="text" name="woduedate" id="woduedate" class="kpress" style="width:100px;" id="woduedate" required />
</td>
</tr>

 

  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addworkorder" value="submit" id="addworkorder"/>
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
              
                         
				</form>
<?php			
 }
 
if($_REQUEST['mode'] != 'add')
{
	//echo "SELECT wo.Code, wo.ProductID, p.ProductName, wo.WorkFlowID, wf.WorkflowName, wo.Quantity, if(wo.IsActive = 1, 'Yes', 'No') as active, if(wo.IsCompleted = 1, 'Yes', 'No') as completed, wo.Pieces, wo.StandardID FROM txnworkorder wo JOIN mstrproduct p ON p.ID = wo.ProductID JOIN luworkflow wf ON wf.ID = wo.WorkFlowID WHERE wo.ID = ".$_REQUEST['woid'];
	$woQry = mysql_fetch_array(mysql_query("SELECT wo.Code, wo.ProductID, p.ProductName, wo.WorkFlowID, wf.WorkflowName, wo.Quantity, IF(wo.IsActive = 1, 'Yes', 'No') AS active, IF(wo.IsCompleted = 1, 'Yes', 'No') AS completed, wo.Pieces, wo.StandardID, s.Name Standard, DATE_FORMAT(wo.DueDate, '%d-%b-%Y') DueDate
		FROM ".APP."txnworkorder wo
		JOIN ".APP."mstrproduct p ON p.ID = wo.ProductID
		JOIN ".APP."luworkflow wf ON wf.ID = wo.WorkFlowID
		JOIN ".APP."mstrstandard s ON s.ID = wo.StandardID
		WHERE wo.ID = ".$_REQUEST['woid'])) or die(mysql_error());
}

 if($_REQUEST['mode'] == 'edit')
 {
?>
<form name="workorderSetting" action="mdlWorkOrder.php?mode=edit" method="post" id="workorderSetting" >
<table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Work Order Code</td>
    <td colspan="3">
      <input style="width:60px;"  type="text"  maxlength="255" name="workordercode" value="<?php echo $woQry['Code']; ?>" readonly="readonly"/>
    </td>
    </tr>
  <tr>
    <td>Component Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
	<select data-placeholder="choose" class="select" id="product" name="product" onChange="getProductionFlow('edit', '<?php echo $_REQUEST['woid']; ?>')" ><option value="">--Select--</option>
	<?php
		$product = mysql_query("SELECT ID, Code, ProductName, WorkFlowID FROM ".APP."mstrproduct WHERE IsActive = 1 ORDER BY ProductName") or die(mysql_error());
		while($productrs = mysql_fetch_array($product))
		{
			if($_REQUEST['prdid'])
			{
				$woProject = $woQry['ProductID'];
				$selProject = $_REQUEST['prdid'];
			}
			else
			{
				$woProject = $woQry['ProductID'];
				$selProject = $productrs['ID'];
			}
			?>
			<option value="<?php echo $productrs['ID']; ?>" <?php if($woProject == $selProject) { ?> selected <?php }?> ><?php echo $productrs['Code']." - ".$productrs['ProductName']; ?></option>
			<?php
		}
	?></select>
    </td>
    </tr>
    <tr>
    <td>Quantity<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<input style="width:60px;"  type="text"  maxlength="255" name="woquantity" value="<?php echo $woQry['Quantity']; ?>"  />&nbsp;Bottle(s)
    </td>
  </tr>
 </tr>
    <tr>
    <td>Piece(s)/Bottle<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<input style="width:60px;"  type="text"  maxlength="255" name="wopieces" value="<?php echo $woQry['Pieces']; ?>" readonly />
    </td>
  </tr>
  <tr>
   <td>Production Flow</td>
   <td colspan="3">
   <?php
   //echo "SELECT p.WorkFlowID, wf.WorkflowName FROM mstrproduct p JOIN luworkflow wf ON wf.ID = p.WorkFlowID WHERE p.ID = ".$_REQUEST['prdid'];
   $pfrs = mysql_fetch_array(mysql_query("SELECT p.WorkFlowID, wf.WorkflowName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow wf ON wf.ID = p.WorkFlowID WHERE p.ID = ".$woQry['ProductID'])) or die(mysql_error());
   ?>
   <input type="hidden" id="pfselect" name="pfselect" value="<?php echo $pfrs['WorkFlowID']; ?>" />
   <input type="hidden" id="workorderid" name="workorderid" value="<?php echo $_REQUEST['woid']; ?>" />
   <?php
   echo $pfrs['WorkflowName'];
   ?>
   </td>
  </tr>
  <tr>
   <td>Standard</td>
   <td colspan="3">
    <?php
   echo $woQry['Standard'];
   ?>
   </td>
  </tr>
 <tr>
<td>Due Date</td>
<td colspan="3"><input type="text" name="woduedate" id="woduedate" class="kpress" style="width:100px;" id="woduedate" required value="<?php echo $woQry['DueDate']; ?>" /></td>
</tr> 
  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="editworkorder" value="Submit" id="editworkorder" />
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>

  </table>
</form>
<?php
 }
 
 
if($_REQUEST['mode'] == 'set')
{
?>
	<form name="workorderSetting" action="mdlWorkOrder.php?mode=set" method="post" id="workorderSetting" >

<table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Work Order Code</td>
    <td colspan="3">
      <?php echo $woQry['Code']; ?>
    </td>
    </tr>
  <tr>
    <td>Product Name</td>
    <td colspan="3">
	<?php echo $woQry['ProductName']; ?>
    </td>
    </tr>
    <tr>
    <td>Quantity</td>
    <td colspan="3">
	<?php echo $woQry['Quantity']; ?>&nbsp;Bottle(s)
    </td>
  </tr>
 </tr>
    <tr>
    <td>Piece(s)/Bottle<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<?php echo $woQry['Pieces']; ?>
    </td>
  </tr>
  <tr>
   <td>Production Flow</td>
   <td colspan="3">
   <?php
   //echo "SELECT p.WorkFlowID, wf.WorkflowName, p.StandardID, s.StandardName FROM mstrproduct p JOIN luworkflow wf ON wf.ID = p.WorkFlowID JOIN mstrstandard s ON s.ID = p.StandardID WHERE p.ID = ".$woQry['ProductID'];
   $pfrs = mysql_fetch_array(mysql_query("SELECT p.WorkFlowID, wf.WorkflowName, p.StandardID, s.Name StandardName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow wf ON wf.ID = p.WorkFlowID JOIN ".APP."mstrstandard s ON s.ID = p.StandardID WHERE p.ID = ".$woQry['ProductID'])) or die(mysql_error());
   ?>
   <input type="hidden" id="pfselect" name="pfselect" value="<?php echo $pfrs['WorkFlowID']; ?>" />
   <input type="hidden" id="workorderid" name="workorderid" value="<?php echo $_REQUEST['woid']; ?>" />
   <input type="hidden" id="product" name="product" value="<?php echo $woQry['ProductID']; ?>" />
   <?php
   echo $pfrs['WorkflowName'];
   ?>
   </td>
  </tr>
  <tr>
   <td>Standard</td>
   <td colspan="3">
   <input type="hidden" id="stdselect" name="stdselect" value="<?php echo $pfrs['StandardID']; ?>" />
   <?php
   echo $pfrs['StandardName'];
   ?>
   </td>
  </tr>

  <tr>
  <td style="text-align:center" width="25%">Process</td>
  <td style="text-align:center" width="25%">Machine</td>
  <td style="text-align:center" width="25%">Std. Value(s)</td>
  <td style="text-align:center" width="25%">Target/Hour</td>
	</tr>
<?php

	$woStageQry = "SELECT DISTINCT wos.StageID, s.StageName, wos.WorkflowID ID, wos.MachineID, m.MachineName, wo.StandardID FROM ".APP."txnworkordersetting wos JOIN ".APP."lustage s ON s.ID = wos.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wos.MachineID JOIN ".APP."txnworkorder wo ON wo.ID = wos.WorkOrderID WHERE wos.WorkOrderID = ".$_REQUEST['woid'];

	$pfStageQry = "SELECT DISTINCT ms.ID StandardID, IF(tss.StageID IS NULL, tws.StageID, tss.StageID) StageID, s.StageName, IF(tss.MachineID IS NULL, tsm.MachineID, IF(tss.MachineID = tsm.MachineID, tss.MachineID, tsm.MachineID)) MachineID, IFNULL(m.MachineName, 'NA') MachineName, tsm.MachineID FROM ".APP."mstrstandard ms JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID JOIN ".APP."txnworkflowstage tws ON tws.WorkflowID = wf.ID LEFT OUTER JOIN ".APP."txnstandardsetting tss ON tss.StandardID = ms.ID AND tss.StageID = tws.StageID JOIN ".APP."lustage s ON s.ID = IF(tss.StageID IS NULL, tws.StageID, tss.StageID) LEFT OUTER JOIN ".APP."txnstagemachine tsm ON tsm.StageID = IF(tss.StageID IS NULL, tws.StageID, tss.StageID) LEFT OUTER JOIN ".APP."lumachine m ON m.ID = tsm.MachineID WHERE ms.ID = ".$woQry['StandardID']." ORDER BY tws.StageSequence ASC";
	//$pfStageQry = "SELECT DISTINCT tss.StageID, s.StageName, ms.ID, tss.MachineID, IF(m.MachineName IS NULL, 'NA', m.MachineName) MachineName, ms.ID StandardID FROM mstrstandard ms JOIN txnstandardsetting tss ON tss.StandardID = ms.ID JOIN lustage s ON s.ID = tss.StageID LEFT OUTER JOIN lumachine m ON m.ID = tss.MachineID WHERE ms.ID = ".$woQry['StandardID']." ORDER BY tss.ID ASC";
//echo $woStageQry;
//echo $pfStageQry;
	if(mysql_num_rows(mysql_query($woStageQry)) > 0)
	{
		$pfStage = mysql_query($woStageQry) or die(mysql_error());
	}
	else
	{
		$pfStage = mysql_query($pfStageQry) or die(mysql_error());
	}

	while($pfStagers = mysql_fetch_array($pfStage))
	{
		$attcnt = 0;
		$stagemachine = $pfStagers['StageID']."".$pfStagers['MachineID'];
	?>
	<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='pfStageID[]' id='pfStageID<?php echo $pfStagers['StageID']; ?>' value='<?php echo $pfStagers['StageID']; ?>' ><?php echo $pfStagers['StageName']; ?></td>
	<td><input class ="sbox2" type='hidden' name='machine[]' id='machine<?php echo $pfStagers['MachineID']; ?>' value='<?php echo $pfStagers['MachineID']; ?>' ><?php echo $pfStagers['MachineName']; ?>
	</td>
	<td>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--TEMPERATURE-->
	<a href="javascript:addTemp(<?php echo $stagemachine; ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Temperature" src="images/temperature.png"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>temperature">
	<tbody>
	<?php
	$woTemperatureQry = "SELECT wos.StageID, wos.AttributeID, wos.Value, wos.MachineID FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".TEMPERATURE." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];

	//$pfTemperatureQry = "SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM txnworkflowstagemachine wsm JOIN txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 1";
	$pfTemperatureQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".TEMPERATURE." AND tss.MachineID = ".$pfStagers['MachineID'];	

	if(mysql_num_rows(mysql_query($woTemperatureQry)) > 0)
	{
		$woTemperature = mysql_query($woTemperatureQry) or die(mysql_error());
	}
	else
	{
		$woTemperature = mysql_query($pfTemperatureQry) or die(mysql_error());
	}

	while($temperaturers = mysql_fetch_array($woTemperature))
	{
		if($temperaturers['Value'])
		{
			$attcnt = $attcnt + 1;
			//$stagemachine = $temperaturers['StageID']."".$temperaturers['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>temperature[]" id="<?php echo $stagemachine;?>temperature" value="<?php echo $temperaturers['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--PRESSURE-->
	<a href="javascript:addPress(<?php echo $stagemachine; ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Pressure" src="images/pressure.png" width="16px" height="16px"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>pressure">
	<tbody>
	<?php
	$woPressureQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".PRESSURE." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfPressureQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".PRESSURE." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woPressureQry)) > 0)
	{
		$woPressure = mysql_query($woPressureQry) or die(mysql_error());
	}
	else
	{
		$woPressure = mysql_query($pfPressureQry) or die(mysql_error());
	}
	
	while($pressurers = mysql_fetch_array($woPressure))
	{
		if($pressurers['Value'])
		{
			$attcnt = $attcnt + 1;
			//$stagemachine = $pressurers['StageID']."".$pressurers['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>pressure[]" id="<?php echo $stagemachine;?>pressure" value="<?php echo $pressurers['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--TIME-->
	<a href="javascript:addTime(<?php echo $stagemachine; ?>+'time')" id="Time" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Time" src="images/time.png"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>time">
	<tbody>
	<?php
	
	$woTimeQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".TIME." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfTimeQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".TIME." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woTimeQry)) > 0)
	{
		$woTime = mysql_query($woTimeQry) or die(mysql_error());
	}
	else
	{
		$woTime = mysql_query($pfTimeQry) or die(mysql_error());
	}

	while($timers = mysql_fetch_array($woTime))
	{
		if($timers['Value'])
		{
			$attcnt = $attcnt + 1;
			//$stagemachine = $timers['StageID']."".$timers['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine ?>time[]" id="<?php echo $stagemachine;?>time" value="<?php echo $timers['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--WEIGHT-->
	<a href="javascript:addWeight(<?php echo $stagemachine; ?>+'weight')" id="Weight" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Weight" src="images/weight.png"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>weight">
	<tbody>
	<?php
	
	$woWeightQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".WEIGHT." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfWeightQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".WEIGHT." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woWeightQry)) > 0)
	{
		$woWeight = mysql_query($woWeightQry) or die(mysql_error());
	}
	else
	{
		$woWeight = mysql_query($pfWeightQry) or die(mysql_error());
	}

	while($weightrs = mysql_fetch_array($woWeight))
	{
		if($weightrs['Value'])
		{
			$attcnt = $attcnt + 1;
			//$stagemachine = $weightrs['StageID']."".$weightrs['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>weight[]" id="<?php echo $stagemachine;?>weight" value="<?php echo $weightrs['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--DENSITY-->
	<a href="javascript:addDensity(<?php echo $stagemachine; ?>+'density')" id="Density" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Density" src="images/density.png" width="16px" height="16px"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>density">
	<tbody>
	<?php
	
	$woDensityQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".DENSITY." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfDensityQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".DENSITY." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woDensityQry)) > 0)
	{
		$woDensity = mysql_query($woDensityQry) or die(mysql_error());
	}
	else
	{
		$woDensity = mysql_query($pfDensityQry) or die(mysql_error());
	}

	while($densityrs = mysql_fetch_array($woDensity))
	{
		if($densityrs['Value'])
		{
			$attcnt = $attcnt + 1;
			//$stagemachine = $densityrs['StageID']."".$densityrs['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>density[]" id="<?php echo $stagemachine;?>density" value="<?php echo $densityrs['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--HARDNESS-->
	<a href="javascript:addHardness(<?php echo $stagemachine; ?>+'hardness')" id="Hardness" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Hardness" src="images/hardness.png" width="16px" height="16px"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>hardness">
	<tbody>
	<?php
	
	$woHardnessQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".HARDNESS." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfHardnessQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".HARDNESS." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woHardnessQry)) > 0)
	{
		$woHardness = mysql_query($woHardnessQry) or die(mysql_error());
	}
	else
	{
		$woHardness = mysql_query($pfHardnessQry) or die(mysql_error());
	}

	while($hardnessrs = mysql_fetch_array($woHardness))
	{
		if($hardnessrs['Value'])
		{
			$attcnt = $attcnt + 1;
			//$stagemachine = $hardnessrs['StageID']."".$hardnessrs['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>hardness[]" id="<?php echo $stagemachine;?>hardness" value="<?php echo $hardnessrs['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	</td>
	<td>
	<?php
	if($pfStagers['MachineID'])
	{
		$stdTargetQry = "SELECT tst.Target FROM ".APP."txnstandardtarget tst WHERE tst.StandardID = ".$pfStagers['StandardID']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID = ".$pfStagers['MachineID'];
		$woTargetQry = "SELECT tst.Target FROM ".APP."txnworkordertarget tst WHERE tst.WorkOrderID = ".$_REQUEST['woid']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID = ".$pfStagers['MachineID'];		
	}
	else
	{
		$stdTargetQry = "SELECT tst.Target FROM ".APP."txnstandardtarget tst WHERE tst.StandardID = ".$pfStagers['StandardID']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID IS NULL";
		$woTargetQry = "SELECT tst.Target FROM ".APP."txnworkordertarget tst WHERE tst.WorkOrderID = ".$_REQUEST['woid']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID IS NULL";
	}
	
	
	if(mysql_num_rows(mysql_query($woTargetQry)) > 0)
	{
		$woTarget = mysql_query($woTargetQry) or die(mysql_error());
	}
	else
	{
		$woTarget = mysql_query($stdTargetQry) or die(mysql_error());
	}

	$stdTargetRS = mysql_fetch_array($woTarget);
	?>
	<input type="text" id="<?php echo $stagemachine; ?>target[]" name="<?php echo $stagemachine; ?>target[]" style="width:50px;" value="<?php echo $stdTargetRS['Target']; ?>" <?php if($attcnt > 0) { ?> required <?php } ?> onkeypress="return isNumberKey(event)" />

	</td>
	<input class ="sbox2" type='hidden' name='pfWorkflowID' id='pfWorkflowID' value='<?php echo $pfStagers['ID']; ?>' >
	
</tr>
<?php
	}

?>

  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addstage" value="Submit" id="addstage" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }

 if($_REQUEST['mode'] == 'vw')
{
?>
	<form name="workorderSetting" action="mdlWorkOrder.php?mode=set" method="post" id="workorderSetting" >

<table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Work Order Code</td>
    <td colspan="3">
      <?php echo $woQry['Code']; ?>
    </td>
    </tr>
  <tr>
    <td>Product Name</td>
    <td colspan="3">
	<?php echo $woQry['ProductName']; ?>
    </td>
    </tr>
    <tr>
    <td>Quantity</td>
    <td colspan="3">
	<?php echo $woQry['Quantity']; ?>&nbsp;Bottle(s)
    </td>
  </tr>
 </tr>
    <tr>
    <td>Piece(s)/Bottle<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<?php echo $woQry['Pieces']; ?>
    </td>
  </tr>
  <tr>
   <td>Production Flow</td>
   <td colspan="3">
   <?php
   //echo "SELECT p.WorkFlowID, wf.WorkflowName, p.StandardID, s.StandardName FROM mstrproduct p JOIN luworkflow wf ON wf.ID = p.WorkFlowID JOIN mstrstandard s ON s.ID = p.StandardID WHERE p.ID = ".$woQry['ProductID'];
   $pfrs = mysql_fetch_array(mysql_query("SELECT p.WorkFlowID, wf.WorkflowName, p.StandardID, s.Name StandardName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow wf ON wf.ID = p.WorkFlowID JOIN ".APP."mstrstandard s ON s.ID = p.StandardID WHERE p.ID = ".$woQry['ProductID'])) or die(mysql_error());
   ?>
   <input type="hidden" id="pfselect" name="pfselect" value="<?php echo $pfrs['WorkFlowID']; ?>" />
   <input type="hidden" id="workorderid" name="workorderid" value="<?php echo $_REQUEST['woid']; ?>" />
   <input type="hidden" id="product" name="product" value="<?php echo $woQry['ProductID']; ?>" />
   <?php
   echo $pfrs['WorkflowName'];
   ?>
   </td>
  </tr>
  <tr>
   <td>Standard</td>
   <td colspan="3">
   <input type="hidden" id="stdselect" name="stdselect" value="<?php echo $pfrs['StandardID']; ?>" />
   <?php
   echo $pfrs['StandardName'];
   ?>
   </td>
  </tr>

  <tr>
  <td style="text-align:center" width="25%">Process</td>
  <td style="text-align:center" width="25%">Machine</td>
  <td style="text-align:center" width="25%">Std. Value(s)</td>
  <td style="text-align:center" width="25%">Target/Hour</td>
	</tr>
<?php

	$woStageQry = "SELECT DISTINCT wos.StageID, s.StageName, wos.WorkflowID ID, wos.MachineID, m.MachineName, wo.StandardID FROM ".APP."txnworkordersetting wos JOIN ".APP."lustage s ON s.ID = wos.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wos.MachineID JOIN ".APP."txnworkorder wo ON wo.ID = wos.WorkOrderID WHERE wos.WorkOrderID = ".$_REQUEST['woid'];

	$pfStageQry = "SELECT DISTINCT ms.ID StandardID, IF(tss.StageID IS NULL, tws.StageID, tss.StageID) StageID, s.StageName, IF(tss.MachineID IS NULL, tsm.MachineID, IF(tss.MachineID = tsm.MachineID, tss.MachineID, tsm.MachineID)) MachineID, IFNULL(m.MachineName, 'NA') MachineName, tsm.MachineID FROM ".APP."mstrstandard ms JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID JOIN ".APP."txnworkflowstage tws ON tws.WorkflowID = wf.ID LEFT OUTER JOIN ".APP."txnstandardsetting tss ON tss.StandardID = ms.ID AND tss.StageID = tws.StageID JOIN ".APP."lustage s ON s.ID = IF(tss.StageID IS NULL, tws.StageID, tss.StageID) LEFT OUTER JOIN ".APP."txnstagemachine tsm ON tsm.StageID = IF(tss.StageID IS NULL, tws.StageID, tss.StageID) LEFT OUTER JOIN ".APP."lumachine m ON m.ID = tsm.MachineID WHERE ms.ID = ".$woQry['StandardID']." ORDER BY tws.StageSequence ASC";
	//$pfStageQry = "SELECT DISTINCT tss.StageID, s.StageName, ms.ID, tss.MachineID, IF(m.MachineName IS NULL, 'NA', m.MachineName) MachineName, ms.ID StandardID FROM mstrstandard ms JOIN txnstandardsetting tss ON tss.StandardID = ms.ID JOIN lustage s ON s.ID = tss.StageID LEFT OUTER JOIN lumachine m ON m.ID = tss.MachineID WHERE ms.ID = ".$woQry['StandardID']." ORDER BY tss.ID ASC";
//echo $woStageQry;
//echo $pfStageQry;
	if(mysql_num_rows(mysql_query($woStageQry)) > 0)
	{
		$pfStage = mysql_query($woStageQry) or die(mysql_error());
	}
	else
	{
		$pfStage = mysql_query($pfStageQry) or die(mysql_error());
	}

	while($pfStagers = mysql_fetch_array($pfStage))
	{
		$stagemachine = $pfStagers['StageID']."".$pfStagers['MachineID'];
	?>
	<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='pfStageID[]' id='pfStageID<?php echo $pfStagers['StageID']; ?>' value='<?php echo $pfStagers['StageID']; ?>' ><?php echo $pfStagers['StageName']; ?></td>
	<td><input class ="sbox2" type='hidden' name='machine[]' id='machine<?php echo $pfStagers['MachineID']; ?>' value='<?php echo $pfStagers['MachineID']; ?>' ><?php echo $pfStagers['MachineName']; ?>
	</td>
	<td>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--TEMPERATURE-->
	<a href="javascript:addTemp(<?php echo $stagemachine; ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Temperature" src="images/temperature.png"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>temperature">
	<tbody>
	<?php
	$woTemperatureQry = "SELECT wos.StageID, wos.AttributeID, wos.Value, wos.MachineID FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".TEMPERATURE." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];

	//$pfTemperatureQry = "SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM txnworkflowstagemachine wsm JOIN txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 1";
	$pfTemperatureQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".TEMPERATURE." AND tss.MachineID = ".$pfStagers['MachineID'];

	if(mysql_num_rows(mysql_query($woTemperatureQry)) > 0)
	{
		$woTemperature = mysql_query($woTemperatureQry) or die(mysql_error());
	}
	else
	{
		$woTemperature = mysql_query($pfTemperatureQry) or die(mysql_error());
	}

	while($temperaturers = mysql_fetch_array($woTemperature))
	{
		if($temperaturers['Value'])
		{
			//$stagemachine = $temperaturers['StageID']."".$temperaturers['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>temperature[]" id="<?php echo $stagemachine;?>temperature" value="<?php echo $temperaturers['Value'];?>" size="5" required readonly />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--PRESSURE-->
	<a href="javascript:addPress(<?php echo $stagemachine; ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Pressure" src="images/pressure.png" width="16px" height="16px"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>pressure">
	<tbody>
	<?php
	$woPressureQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".PRESSURE." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfPressureQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".PRESSURE." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woPressureQry)) > 0)
	{
		$woPressure = mysql_query($woPressureQry) or die(mysql_error());
	}
	else
	{
		$woPressure = mysql_query($pfPressureQry) or die(mysql_error());
	}
	
	while($pressurers = mysql_fetch_array($woPressure))
	{
		if($pressurers['Value'])
		{
			//$stagemachine = $pressurers['StageID']."".$pressurers['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>pressure[]" id="<?php echo $stagemachine;?>pressure" value="<?php echo $pressurers['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--TIME-->
	<a href="javascript:addTime(<?php echo $stagemachine; ?>+'time')" id="Time" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Time" src="images/time.png"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>time">
	<tbody>
	<?php
	
	$woTimeQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".TIME." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfTimeQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".TIME." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woTimeQry)) > 0)
	{
		$woTime = mysql_query($woTimeQry) or die(mysql_error());
	}
	else
	{
		$woTime = mysql_query($pfTimeQry) or die(mysql_error());
	}

	while($timers = mysql_fetch_array($woTime))
	{
		if($timers['Value'])
		{
			//$stagemachine = $timers['StageID']."".$timers['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine ?>time[]" id="<?php echo $stagemachine;?>time" value="<?php echo $timers['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--WEIGHT-->
	<a href="javascript:addWeight(<?php echo $stagemachine; ?>+'weight')" id="Weight" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Weight" src="images/weight.png"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>weight">
	<tbody>
	<?php
	
	$woWeightQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".WEIGHT." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfWeightQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".WEIGHT." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woWeightQry)) > 0)
	{
		$woWeight = mysql_query($woWeightQry) or die(mysql_error());
	}
	else
	{
		$woWeight = mysql_query($pfWeightQry) or die(mysql_error());
	}

	while($weightrs = mysql_fetch_array($woWeight))
	{
		if($weightrs['Value'])
		{
			//$stagemachine = $weightrs['StageID']."".$weightrs['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>weight[]" id="<?php echo $stagemachine;?>weight" value="<?php echo $weightrs['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--DENSITY-->
	<a href="javascript:addDensity(<?php echo $stagemachine; ?>+'density')" id="Density" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Density" src="images/density.png" width="16px" height="16px"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>density">
	<tbody>
	<?php
	
	$woDensityQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".DENSITY." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfDensityQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".DENSITY." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woDensityQry)) > 0)
	{
		$woDensity = mysql_query($woDensityQry) or die(mysql_error());
	}
	else
	{
		$woDensity = mysql_query($pfDensityQry) or die(mysql_error());
	}

	while($densityrs = mysql_fetch_array($woDensity))
	{
		if($densityrs['Value'])
		{
			//$stagemachine = $densityrs['StageID']."".$densityrs['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>density[]" id="<?php echo $stagemachine;?>density" value="<?php echo $densityrs['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	<?php
	if($pfStagers['MachineID'])
	{
	?>
	<!--HARDNESS-->
	<a href="javascript:addHardness(<?php echo $stagemachine; ?>+'hardness')" id="Hardness" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"></a><img title="Hardness" src="images/hardness.png" width="16px" height="16px"/>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>hardness">
	<tbody>
	<?php
	
	$woHardnessQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = ".HARDNESS." OR wos.AttributeID IS NULL) AND wos.MachineID = ".$pfStagers['MachineID'];
	
	$pfHardnessQry = "SELECT tss.StageID, tss.AttributeID, tss.Value, tss.MachineID FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$pfStagers['StandardID']." AND tss.StageID = ".$pfStagers['StageID']." AND tss.AttributeID = ".HARDNESS." AND tss.MachineID = ".$pfStagers['MachineID'];
	
	if(mysql_num_rows(mysql_query($woHardnessQry)) > 0)
	{
		$woHardness = mysql_query($woHardnessQry) or die(mysql_error());
	}
	else
	{
		$woHardness = mysql_query($pfHardnessQry) or die(mysql_error());
	}

	while($hardnessrs = mysql_fetch_array($woHardness))
	{
		if($hardnessrs['Value'])
		{
			//$stagemachine = $hardnessrs['StageID']."".$hardnessrs['MachineID'];
	?>
		<span><input type="text"  name="<?php echo $stagemachine; ?>hardness[]" id="<?php echo $stagemachine;?>hardness" value="<?php echo $hardnessrs['Value'];?>" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;"></a></span>&nbsp;
	<?php
		}
	}
	?>
	</tbody>
	</table>
	<?php
	}
	?>
	</td>
	<td>
	<?php
	if($pfStagers['MachineID'])
	{
		$stdTargetQry = "SELECT tst.Target FROM ".APP."txnstandardtarget tst WHERE tst.StandardID = ".$pfStagers['StandardID']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID = ".$pfStagers['MachineID'];
		$woTargetQry = "SELECT tst.Target FROM ".APP."txnworkordertarget tst WHERE tst.WorkOrderID = ".$_REQUEST['woid']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID = ".$pfStagers['MachineID'];		
	}
	else
	{
		$stdTargetQry = "SELECT tst.Target FROM ".APP."txnstandardtarget tst WHERE tst.StandardID = ".$pfStagers['StandardID']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID IS NULL";
		$woTargetQry = "SELECT tst.Target FROM ".APP."txnworkordertarget tst WHERE tst.WorkOrderID = ".$_REQUEST['woid']." AND tst.StageID = ".$pfStagers['StageID']." AND tst.MachineID IS NULL";
	}
	
	
	if(mysql_num_rows(mysql_query($woTargetQry)) > 0)
	{
		$woTarget = mysql_query($woTargetQry) or die(mysql_error());
	}
	else
	{
		$woTarget = mysql_query($stdTargetQry) or die(mysql_error());
	}

	$stdTargetRS = mysql_fetch_array($woTarget);
	?>
	<input type="text" id="<?php echo $stagemachine; ?>target[]" name="<?php echo $stagemachine; ?>target[]" style="width:50px;" value="<?php echo $stdTargetRS['Target']; ?>" required readonly />
	</td>
	<input class ="sbox2" type='hidden' name='pfWorkflowID' id='pfWorkflowID' value='<?php echo $pfStagers['ID']; ?>' >
	
</tr>
<?php
	}

?>

</table>
				</form> 
<?php
 }
 
 ?>	
	</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>