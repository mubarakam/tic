<?php
include('meta_script_link.php');
?>
<head>
<script language="javascript" type="text/javascript">
function validatepassword()
{
	var npwd = $("#newpwd").val();
	var cpwd = $("#conpwd").val();
	
	
	if(npwd=="" && cpwd=="" )
	{
		 $("#newpwd").css({
				  'border': '1px dashed #FF3F3F',
				  "background": "#FAEBE7"
			  });	
			  
		$("#conpwd").css({
				  'border': '1px dashed #FF3F3F',
				  "background": "#FAEBE7"
			  });	
			  return false;
	}
	
	else if(npwd != cpwd){
		 $("#newpwd").css({
				  'border': '1px dashed #FF3F3F',
				  "background": "#FAEBE7"
			  });	
			  
		$("#conpwd").css({
				  'border': '1px dashed #FF3F3F',
				  "background": "#FAEBE7"
			  });	
			  alert("Confirm Password is not matching with new password");
			  return false;
			
	
	}
	else
	{
		  return true;
			
	}
}
</script>
<div class="main-container">
<?php
include('includes\header.php');
?>
</div>
<div class="bread-crums_wrap">
<div class="bread-crums"><a href="#">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Change Password</a> </div>
</div>
<div class="msg_wrap">
<?php
if($_REQUEST['v'] == '0')
{
?>
	<div class="msg_success">Password changed successfully!!!</div>
<?php
}
if($_REQUEST['v'] == 1)
{
?>
	<div class="msg_error">Error while update the password, please try again...</div>
<?php
}
?>	
</div>
<div id="dashlet-panel" class="dashlet-panel-full">
    <?php $sql = mysql_query("select * from ".APP."mstremployee where ID = ".$_SESSION['user_id']) or die(mysql_error());
				$sql_jobinfo = mysql_fetch_array($sql);?>
    <form name="changepwd" action="password.php?userid=<?php echo $_SESSION['user_id']?>" method="post" id="changepwd" onsubmit="return validatepassword()";>
      <input type="hidden" id="login" name="login" value="<?php echo $sql_jobinfo['PASSWORD']; ?>" />
      <table width="100%"  align="center" border="0" id="workflowtable">
        <tbody>
          <tr>
            <td>Current Password</td>
            <td><input  id="curpwd" class="username-field" required type="password" name="curpwd" placeholder="Password"    /></td>
          </tr>
		  <tr>
		    <td colspan="2">
		<i>Password must contain at least one number, one lowercase, one uppercase, one special symbol and length atleast 8 characters.<!-- Please dont use previous 4 passwords--></i>
		</td>
	    </tr>
          <tr>
            <td>New Password</td>
            <td><input  id="newpwd" class="username-field" required pattern="^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d\W])(?=.*[!@#\$%&/=?_\.,:;-\\]).*$"  type="password"   name="newpwd" placeholder="Password"  style="width:300px;"/></td>
          </tr>
          <tr>
            <td>Confirm New Password</td>
            <td><input  id="conpwd" class="username-field" required pattern="^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d\W])(?=.*[!@#\$%&/=?_\.,:;-\\]).*$" type="password"   name="conpwd" placeholder="Password"  style="width:300px;"/></td>
          </tr>
          <tr>
            <td colspan="2"><input type="submit"  name="chgpwd" value="Submit" id="chgpwd" align="center"/></td>
          </tr>
        </tbody>
      </table>
    </form>
  
</div>
<?php
include('includes\footer.php');
?>
</div>
</div>
<?php

if($_REQUEST['chgpwd'] == 'Submit')
{
	$userid = $_SESSION['UserID'];
	
	$sqlpwd = mysql_query("UPDATE ".APP."mstremployee SET PASSWORD = '".md5($_REQUEST['conpwd'])."', LastModOn = NOW(), LastModBy = ".$userid." WHERE ID = ".$userid) or die(mysql_error());
	
	if($sqlpwd)
	{
		header("location:password.php?v=999");
	}
	else
	{
		header("location:password.php?v=1");
	}
}
?>