<?php session_start();
ob_start();
include("config.php");
include("includes/classes/standardClass.php");
echo "<pre>";
//print_r($_REQUEST);
$pfCode = $_REQUEST['standardcode'];
$pfName = $_REQUEST['standardname'];
$pfDesc = $_REQUEST['description'];

$pfStageID = $_REQUEST['stage'];
$machineID = $_REQUEST['machine'];
$pfWorkflowID = $_REQUEST['pfid'];
//print_r($pfStageID);
//print_r($machineID);
$productionFlow = new standardClass();

if($_REQUEST['mode'] == 'add')
{
	$userid = $_SESSION['UserID'];
	$insStd = "INSERT INTO ".APP."mstrstandard (Code, WorkFlowID, Name, Description, CreatedBy, CreatedOn, LastModBy, LastModOn) VALUES ('".$pfCode."', ".$pfWorkflowID.", '".$pfName."', '".$pfDesc."', ".$userid.", NOW(), ".$userid.", NOW())";
	//echo $insStd;
	$insStdExe = mysql_query($insStd) or die(mysql_error());
	
	if($insStdExe)
	{
		$mstrStdId = mysql_insert_id();
		echo $mstrStdId;
		$updCfgDocType = mysql_query("UPDATE ".APP."cfgdocumenttype SET CurrentRange = CurrentRange + 1 WHERE ObjectTypeID = 9") or die(mysql_error());
		if($updCfgDocType)
		{			
			for($i = 0;$i < count($pfStageID);$i++)
			{
				$temperature = $_REQUEST[$pfStageID[$i].$machineID[$i]."temperature"];
				$pressure = $_REQUEST[$pfStageID[$i].$machineID[$i]."pressure"];
				$time = $_REQUEST[$pfStageID[$i].$machineID[$i]."time"];
				$weight = $_REQUEST[$pfStageID[$i].$machineID[$i]."weight"];
				$density = $_REQUEST[$pfStageID[$i].$machineID[$i]."density"];
				$hardness = $_REQUEST[$pfStageID[$i].$machineID[$i]."hardness"];
				$target = $_REQUEST[$pfStageID[$i].$machineID[$i]."target"];
				echo "funciton call starts...";
				echo "<br/>";
				$productionFlow->machineSetting($mstrStdId, $pfStageID[$i], $machineID[$i], $temperature, $pressure, $time, $weight, $density, $hardness, $target);
			}
			$_SESSION['prcmsg'] = 'ss';
			header("location:vwStandard.php");
		}
		else
		{
			header("location:ctrlStandard.php");			
		}
	}
	else
	{
		header("location:ctrlStandard.php");
	}
}

if($_REQUEST['mode'] == 'set')
{
	$userid = $_SESSION['UserID'];
	$updStd = "UPDATE ".APP."mstrstandard SET Name = '".$pfName."', Description = '".$pfDesc."', LastModBy = ".$userid.", LastModOn = NOW() WHERE ID = ".$_REQUEST['stdid'];
	echo $updStd;
	$delStdSetting = "DELETE FROM ".APP."txnstandardsetting WHERE StandardID = ".$_REQUEST['stdid'];
	$delStdTarget = "DELETE FROM ".APP."txnstandardtarget WHERE StandardID = ".$_REQUEST['stdid'];
	echo $delStdSetting;
	$delStdSettingExe = mysql_query($delStdSetting) or die(mysql_error());
	$delStdTargetExe = mysql_query($delStdTarget) or die(mysql_error());
	
	if($delStdSettingExe && $delStdTargetExe)
	{
		$mstrStdId = $_REQUEST['stdid'];

			
			for($i = 0;$i < count($pfStageID);$i++)
			{
				$temperature = $_REQUEST[$pfStageID[$i].$machineID[$i]."temperature"];
				$pressure = $_REQUEST[$pfStageID[$i].$machineID[$i]."pressure"];
				$time = $_REQUEST[$pfStageID[$i].$machineID[$i]."time"];
				$weight = $_REQUEST[$pfStageID[$i].$machineID[$i]."weight"];
				$density = $_REQUEST[$pfStageID[$i].$machineID[$i]."density"];
				$hardness = $_REQUEST[$pfStageID[$i].$machineID[$i]."hardness"];
				$target = $_REQUEST[$pfStageID[$i].$machineID[$i]."target"];
				echo "funciton call starts...";
				echo "<br/>";
				$productionFlow->machineSetting($mstrStdId, $pfStageID[$i], $machineID[$i], $temperature, $pressure, $time, $weight, $density, $hardness, $target);
			}
			$_SESSION['prcmsg'] = 'ss';
			header("location:vwStandard.php");
	}
	else
	{
		header("location:ctrlStandard.php");
	}
}

if($_REQUEST['mode'] == 'edit')
{
	$productionFlow->updateProductionFlow($pfMasterId, $pfName, $pfDesc, $selectedValue);
}

if($_REQUEST['mode'] == 'del')
{
	$productionFlow->deleteProductionFlow($pfMasterId);
}

if($_REQUEST['mode'] == 'setold')
{
	//mysql_query("START TRANSACTION");
	$delpfAttribute = mysql_query("DELETE wattr FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.WorkFlowID = ".$pfWorkflowID) or die(mysql_error());
	$delpfStageMachine = mysql_query("DELETE FROM ".APP."txnworkflowstagemachine WHERE WorkflowID = ".$pfWorkflowID) or die(mysql_error());
	
	
	if($delpfStageMachine && $delpfAttribute)
	{
		for($i = 0;$i < count($pfStageID);$i++)
		{
			$temperature = $_REQUEST[$pfStageID[$i]."temperature"];
			$pressure = $_REQUEST[$pfStageID[$i]."pressure"];
			$time = $_REQUEST[$pfStageID[$i]."time"];
			$weight = $_REQUEST[$pfStageID[$i]."weight"];
			$density = $_REQUEST[$pfStageID[$i]."density"];
			$hardness = $_REQUEST[$pfStageID[$i]."hardness"];
			$target = $_REQUEST[$pfStageID[$i].$machineID[$i]."target"];
			echo "mdl - ".$pfStageID[$i]."<br/>";
			echo "mdl - ".$machine[$i]."<br/>";
			$productionFlow->machineSetting($pfWorkflowID, $pfStageID[$i], $machine[$i], $temperature, $pressure, $time, $weight, $density, $hardness, $target);
		}
		//mysql_query("COMMIT");
		$_SESSION['prcmsg'] = 'ss';
		header("location:vwProductionFlow.php");
	}
	else
	{
		header("location:ctrlProductionFlow.php?mode=set&sid=".$pfMasterId);
	}
//	$productionFlow->machineSetting($pfWorkflowID, $pfStageID, $machine);
}

?>