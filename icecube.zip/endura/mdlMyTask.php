<?php
session_start();
ob_start();
include("config.php");
include("includes/classes/erpClass.php");
$erp = new erpClass();
echo "<pre>";
print_r($_REQUEST);

$select = $_REQUEST['taskcheck'];
if($_REQUEST['productionEntry'] == 'Production Entry')
{
	echo "production entry clicked";
	$url = "ctrlProdEntry.php?t=1&p=".$select;
	header("location:".$url);
}

if($_REQUEST['takeownership'] == 'Take OwnerShip')
{
	$url = "ctrlProdEntry.php?t=2&p=".$select;
	header("location:".$url);
}

if($_REQUEST['mode'] == 'pe')
{
	$mtStgId = $_REQUEST['mdstgid'];
	$seq = $_REQUEST['seq'];
	$InQty = $_REQUEST['InQty'];
	$OutQty = $_REQUEST['OutQty'];
	$RejQty = $_REQUEST['RejQty'];
	$PenQty = $_REQUEST['PenQty'];
	$temperature = $_REQUEST['Temperature'];
	$pressure = $_REQUEST['Pressure'];
	$weight = $_REQUEST['Weight'];
	$time = $_REQUEST['Time'];
	$density = $_REQUEST['Density'];
	$hardness = $_REQUEST['Hardness'];
	$employee = $_REQUEST['ddEmployee'];
	$fromdate = $_REQUEST['fromdate'];
	$starttime = $_REQUEST['fromtime'];
	$todate = $_REQUEST['todate'];
	$endtime = $_REQUEST['totime'];
	//$prodtime = strtotime($starttime);
	$startdatetime = date('Y-m-d', strtotime($fromdate))." ".$starttime;
	$enddatetime = date('Y-m-d', strtotime($todate))." ".$endtime;
	$machineid = $_REQUEST['machine'];
	$skipQty = $_REQUEST['SkipQty'];
	$skipTo = $_REQUEST['skipto'];
	$rollbackQty = $_REQUEST['RepQty'];
	$rollbackTo = $_REQUEST['rollback'];
	
	if(!$RejQty)
	{
		$RejQty = 0;
	}
	if(!$rollbackQty)
	{
		$rollbackQty = 0;
	}
	if(!$skipQty)
	{
		$skipQty = 0;
	}
	echo $startdatetime." - ".$enddatetime;
	//exit;
	$erp->productionEntry($mtStgId, $seq, $InQty, $OutQty, $RejQty, $PenQty, $temperature, $pressure, $weight, $time, $density, $hardness, $employee, $startdatetime, $enddatetime, $machineid, $skipQty, $skipTo, $rollbackQty, $rollbackTo);
}

?>