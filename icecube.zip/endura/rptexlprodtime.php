<?php
include('config.php');
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2012 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2012 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);

date_default_timezone_set('Europe/London');

/** Include PHPExcel */
require_once 'includes/classes/PHPExcel.php';


// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");


// Add some data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'WO Code')
            ->setCellValue('B1', 'Component')
            ->setCellValue('C1', 'Process')
			->setCellValue('D1', 'Machine')
			->setCellValue('E1', 'Target/Hour')
            ->setCellValue('F1', 'Prod. Date')
			->setCellValue('G1', 'Start Time')
			->setCellValue('H1', 'End Time')
			->setCellValue('I1', 'Tot. Time')
			->setCellValue('J1', 'Input Qty')
			->setCellValue('K1', 'Output Qty')
			->setCellValue('L1', 'Rej. Qty')
			->setCellValue('M1', 'Operator')
			->setCellValue('N1', 'Status')
			->setCellValue('O1', 'Efficiency (%)')
			->setCellValue('P1', 'Remarks');

$rptQuery = "SELECT DISTINCT wo.Code, mp.ProductName, s.StageName, msl.InputQuantity, msl.OutputQuantity, msl.RejectedQuantity, me.Name Employee, st.Description Status, TIMEDIFF(msl.EndTime, msl.StartTime) ProdTime, DATE_FORMAT(msl.StartTime, '%H:%i:%s') StartTime, DATE_FORMAT(msl.EndTime, '%H:%i:%s') EndTime, DATE_FORMAT(msl.StartTime, '%Y-%m-%d') ProdDate, m.MachineName, wot.Target
, wot.Target, (wot.Target/3600) TargetPerSec
, TIME_TO_SEC(TIMEDIFF(msl.EndTime, msl.StartTime)) ActProdInSecs
, msl.OutputQuantity/TIME_TO_SEC(TIMEDIFF(msl.EndTime, msl.StartTime)) OutputPerSec
, CAST(((msl.OutputQuantity/TIME_TO_SEC(TIMEDIFF(msl.EndTime, msl.StartTime)))/(wot.Target/3600))*100 AS DECIMAL(5, 2)) Efficiency
, NULL Remarks
FROM ".APP."txnworkorder wo
INNER JOIN ".APP."txnmetadatastage ms ON ms.WorkOrderID = wo.ID
INNER JOIN ".APP."txnmetadatastagelog msl ON msl.MetadataStageID = ms.ID
INNER JOIN ".APP."mstremployee me ON me.ID = msl.DoneBy
INNER JOIN ".APP."mstrproduct mp ON mp.ID = wo.ProductID
INNER JOIN ".APP."lustage s ON s.ID = ms.StageID
INNER JOIN ".APP."lustatus st ON st.ID = ms.StatusID
LEFT OUTER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageLogID = msl.ID
LEFT OUTER JOIN ".APP."lumachine m ON m.ID = sl.MachineID
LEFT OUTER JOIN ".APP."txnworkordertarget wot ON wot.WorkOrderID = wo.ID AND wot.WorkflowID = ms.WorkflowID AND wot.StageID = ms.StageID AND IF(wot.MachineID IS NULL, 1, wot.MachineID) = IF(sl.MachineID IS NULL, 1, sl.MachineID)
WHERE CAST(msl.StartTime AS DATE) >= STR_TO_DATE('".$_REQUEST['cddf']."', '%d-%b-%Y')
AND CAST(msl.StartTime AS DATE) <= STR_TO_DATE('".$_REQUEST['cddt']."', '%d-%b-%Y')
UNION ALL
SELECT NULL Code, NULL ProductName, s.StageName
, NULL InputQuantity, NULL OutputQuantity, NULL RejectedQuantity
, me.Name Employee, st.Description Status
, TIMEDIFF(ts.EndTime, ts.StartTime) ProdTime, DATE_FORMAT(ts.StartTime, '%H:%i:%s') StartTime
, DATE_FORMAT(ts.EndTime, '%H:%i:%s') EndTime, DATE_FORMAT(ts.StartTime, '%Y-%m-%d') ProdDate
, m.MachineName MachineName, NULL Target, NULL Target, NULL TargetPerSec, NULL ActprodInSecs, NULL OutputPerSsec, NULL Efficiency
, ts.Remarks
FROM ".APP."txntimesheet ts
INNER JOIN ".APP."lustage s ON s.ID = ts.StageID
INNER JOIN ".APP."mstremployee me ON me.ID = ts.DoneBy
INNER JOIN ".APP."lustatus st ON st.ID = ts.StatusID
LEFT OUTER JOIN ".APP."lumachine m ON m.ID = ts.MachineID
WHERE CAST(ts.StartTime AS DATE) >= STR_TO_DATE('".$_REQUEST['cddf']."', '%d-%b-%Y')
AND CAST(ts.StartTime AS DATE) <= STR_TO_DATE('".$_REQUEST['cddt']."', '%d-%b-%Y')";

//echo $rptQuery;
$rptExe = mysql_query($rptQuery) or die(mysql_error());
$i = 2;
while($rs = mysql_fetch_array($rptExe))
{
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, $rs['Code'])
            ->setCellValue('B'.$i, $rs['ProductName'])
            ->setCellValue('C'.$i, $rs['StageName'])
			->setCellValue('D'.$i, $rs['MachineName'])
			->setCellValue('E'.$i, $rs['Target'])
            ->setCellValue('F'.$i, $rs['ProdDate'])
			->setCellValue('G'.$i, $rs['StartTime'])
			->setCellValue('H'.$i, $rs['EndTime'])
			->setCellValue('I'.$i, $rs['ProdTime'])
			->setCellValue('J'.$i, $rs['InputQuantity'])
			->setCellValue('K'.$i, $rs['OutputQuantity'])
			->setCellValue('L'.$i, $rs['RejectedQuantity'])
			->setCellValue('M'.$i, $rs['Employee'])
			->setCellValue('N'.$i, $rs['Status'])
			->setCellValue('O'.$i, $rs['Efficiency'])
			->setCellValue('P'.$i, $rs['Remarks']);
	$i = $i + 1;
}


// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle($_REQUEST['cddf']."to".$_REQUEST['cddt']);


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="ProductionTime.xlsx"');
header('Cache-Control: max-age=0');
PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
