<?php
 include('meta_script_link.php');
?><head>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
function selectDropdown()
{
	//alert(document.getElementById("productflow").value);
	var pf = document.getElementById("productflow").value;
	if (window.XMLHttpRequest)
	{
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	//alert(xmlhttp);
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("standarddiv").innerHTML=xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","ajaxRequest.php?req=pf&pf="+pf,true);
	xmlhttp.send();
}

function unitOfMeasure()
{
	var uom = document.getElementById("uom").value;
	if(uom == 1)
	{
		document.getElementById("uomnumber").style.display = 'block';
		document.getElementById("uomnumber").attributes["required"] = "required";
	}
	if(uom == 2)
	{
		document.getElementById("uomnumber").attributes["required"] = "";
		document.getElementById("uomnumber").style.display = 'none';		
	}
}

function validateparentchild(a)
{
	var val = $("#"+a).val();
	$.ajax({
		type: "post",
		url: "ajaxValidate.php?frm="+a+"&val="+val,
		success: function(data){
			if(data == "exist"){
				$("#"+a).css({
					'border': '1px dashed #FF3F3F',
					"background": "#FAEBE7"
				});
				document.getElementById('pcerrdiv').style.display='inline';
				$("#addbtn").attr('disabled','true')
			}
			else if(data != "exist"){
				$("#"+a).css({
					'border': '1px solid #C1C1C1',
					"background": "#F7F7F7"
				});
				document.getElementById('pcerrdiv').style.display='none';
				$("#addbtn").removeAttr('disabled');
			}
		}
	});
}

</script>
<div class="main-container">
<?php include('includes/header.php');
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Product</div>
<div class="backlink"><a href="vwProduct.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
 <?php
if($_REQUEST['mode'] == 'addpar')
{
?>
<form name="productform" action="mdlProduct.php?mode=addpar" method="post" id="productform" >
<table width="100%" border="0" id="workflowtable">
<tr>
<td width="14%">Parent Code<span class="validationerrornotify">&nbsp;*</span></td>
<td colspan="3">
<input style="width:150px;maxlength:255;" type="text" name="productcode" id="productcode" onChange="validate('productcode')" required />
<div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Parent already exists &nbsp;</div>
</td>
</tr>
  <tr>
    <td>Parent Item<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;" type="text" name="productname" id="productname"  required onChange="validateparentchild('productname');"/>
    <div id="pcerrdiv" class="msg_exists" style="display:none;">&nbsp;Parent already exists&nbsp;</div>
	</td>
	</tr>
  <tr>
    <td>Unit of measurement<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
	<select id="uom" name="uom" required onChange="unitOfMeasure()">
	<option value="">--Select--</option>
	<option value="1">Numbers</option>
	<option value="2">Sets</option>
	</select><input type="text" id="uomnumber" name="uomnumber" style="display:none;" required />
	</td>
	</tr>
	<tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn""/>
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
              
                         
				</form>
<?php			
 }

if($_REQUEST['mode'] == 'addci')
{?>					
	<form name="productform" action="mdlProduct.php?mode=addci" method="post" id="productform">
	<table width="100%" border="0" id="workflowtable">
	<tr>
	<td width="14%">Component Code</td>
	<td colspan="3">
	<input style="width:150px;maxlength:255;" type="text" name="productcode" id="productcode" onChange="validate('productcode')"/>
	<div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Component already exists &nbsp;</div>
	</td>
	</tr>
	<tr>
	<td>Component<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<input style="width:300px;maxlength:255;" type="text" name="productname" id="productname" required onChange="validateparentchild('productname');"/>
	<div id="pcerrdiv" class="msg_exists" style="display:none;">&nbsp;Component already exists&nbsp;</div>
	</td>
	</tr>

	<tr>
	<td>Parent<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="parentproduct" name="parentproduct" required >
	<option value="">--Select--</option>
	<?php
		$parent = mysql_query("SELECT ID, Code, ProductName FROM ".APP."mstrproduct WHERE IsActive = 1 AND IsParent = 1 ORDER BY ProductName ASC") or die(mysql_error());
		while($parentrs = mysql_fetch_array($parent))
		{
			?>
			<option value="<?php echo $parentrs['ID']; ?>" ><?php echo $parentrs['Code']." - ".$parentrs['ProductName']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>

	<tr>
	<td>Process Flow<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="productflow" name="productflow" required onChange="selectDropdown()">
	<option value="">--Select--</option>
	<?php
		$productflow = mysql_query("SELECT DISTINCT wf.ID, wf.Code, wf.WorkflowName FROM ".APP."mstrstandard ms JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID WHERE ms.IsActive = 1 ORDER BY wf.WorkflowName ASC") or die(mysql_error());
		while($productflowrs = mysql_fetch_array($productflow))
		{
			?>
			<option value="<?php echo $productflowrs['ID']; ?>" ><?php echo $productflowrs['Code']." - ".$productflowrs['WorkflowName']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>
	<tr>
	<td>Standard</td>
    <td colspan="3"><div id="standarddiv"></div></td>
	</tr>
	<tr>
	<td>Diamond<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="diamond" name="diamond" required >
	<option value="">--Select--</option>
	<?php
		$diamond = mysql_query("SELECT ID, Description FROM ".APP."ludiamond") or die(mysql_error());
		while($diamondrs = mysql_fetch_array($diamond))
		{
			?>
			<option value="<?php echo $diamondrs['ID']; ?>" ><?php echo $diamondrs['Description']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>

	<tr>
	<td>Bond<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="bond" name="bond" required >
	<option value="">--Select--</option>
	<?php
		$bond = mysql_query("SELECT ID, Description FROM ".APP."lubond") or die(mysql_error());
		while($bondrs = mysql_fetch_array($bond))
		{
			?>
			<option value="<?php echo $bondrs['ID']; ?>" ><?php echo $bondrs['Description']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>

	<tr>
	<td>Bottle Weight<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<input type="text"  size="5" name="bottleweight" id="bottleweight" required />
	</td>
	</tr>
	
	<tr>
	<td>&nbsp;</td>
	<td colspan="3">
	<input type="submit" name="addbtn" value="Submit" id="addbtn""/>
	&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
	</td>
	</tr>
	</table>
	</form>
<?php			
}

if($_REQUEST['mode'] == 'editci')
{
	$product = mysql_query("SELECT * FROM ".APP."mstrproduct prj WHERE prj.ID = ".$_REQUEST['sid']) or die(mysql_error());
	$productrs = mysql_fetch_array($product);
	

	?>					
	<form name="productform" action="mdlProduct.php?mode=editci" method="post" id="productform">
	<table width="100%" border="0" id="workflowtable">
	<tr>
	<td width="14%">Component Code</td>
	<td colspan="3">
	<?php echo $productrs['Code']; ?><input type="hidden" id="ciid" name="ciid" value="<?php echo $_REQUEST['sid']; ?>"/>
	</td>
	</tr>
	<tr>
	<td>Component<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<input style="width:300px;maxlength:255;" type="text" name="productname" id="productname"  required onChange="validateparentchild('productname');" value="<?php echo $productrs['ProductName']; ?>"/>
	<div id="pcerrdiv" class="msg_exists" style="display:none;">&nbsp;Component already exists&nbsp;</div>
	</td>
	</tr>

	<tr>
	<td>Parent<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="parentproduct" name="parentproduct" required >
	<option value="">--Select--</option>
	<?php
		$parent = mysql_query("SELECT ID, Code, ProductName FROM ".APP."mstrproduct WHERE IsActive = 1 AND IsParent = 1 ORDER BY ProductName ASC") or die(mysql_error());
		while($parentrs = mysql_fetch_array($parent))
		{
			?>
			<option value="<?php echo $parentrs['ID']; ?>" <?php if($parentrs['ID'] == $productrs['ParentID']) { ?> selected <?php } ?> ><?php echo $parentrs['Code']." - ".$parentrs['ProductName']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>

	<tr>
	<td>Process Flow<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="productflow" name="productflow" required >
	<option value="">--Select--</option>
	<?php
		$productflow = mysql_query("SELECT wf.ID, wf.Code, wf.WorkflowName FROM ".APP."mstrstandard ms JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID WHERE ms.IsActive = 1 ORDER BY wf.WorkflowName ASC") or die(mysql_error());
		while($productflowrs = mysql_fetch_array($productflow))
		{
			?>
			<option value="<?php echo $productflowrs['ID']; ?>" <?php if($productflowrs['ID'] == $productrs['WorkFlowID']) { ?> selected <?php } ?> ><?php echo $productflowrs['Code']." - ".$productflowrs['WorkflowName']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>
	<tr>
	<td>Standard</td>
    <td colspan="3">
	<select id="standard" name="standard" required >
	<option selected="selected" value="">--Select--</option>
	<?php
	$stdQry = "SELECT * FROM ".APP."mstrstandard WHERE WorkflowID = ".$productrs['WorkFlowID'];
	$stdExe = mysql_query($stdQry) or die(mysql_error());
	while($stdRS = mysql_fetch_array($stdExe))
	{
	?>
	<option value="<?php echo $stdRS['ID']; ?>" <?php if($stdRS['ID'] == $productrs['StandardID']) { ?> selected <?php } ?> ><?php echo $stdRS['Code']." - ".$stdRS['Name']; ?></option>
	<?php
	}
	?>
	</select>
	</td>
	</tr>
	<tr>
	<td>Diamond<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="diamond" name="diamond" required >
	<option value="">--Select--</option>
	<?php
		$diamond = mysql_query("SELECT ID, Description FROM ".APP."ludiamond") or die(mysql_error());
		while($diamondrs = mysql_fetch_array($diamond))
		{
			?>
			<option value="<?php echo $diamondrs['ID']; ?>" <?php if($diamondrs['ID'] == $productrs['DiamondID']) { ?> selected <?php } ?> ><?php echo $diamondrs['Description']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>

	<tr>
	<td>Bond<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<select id="bond" name="bond" required >
	<option value="">--Select--</option>
	<?php
		$bond = mysql_query("SELECT ID, Description FROM ".APP."lubond") or die(mysql_error());
		while($bondrs = mysql_fetch_array($bond))
		{
			?>
			<option value="<?php echo $bondrs['ID']; ?>" <?php if($bondrs['ID'] == $productrs['BondID']) { ?> selected <?php } ?> ><?php echo $bondrs['Description']; ?></option>
			<?php
		}
	?></select>
	</td>
	</tr>

	<tr>
	<td>Bottle Weight<span class="validationerrornotify">&nbsp;*</span></td>
	<td colspan="3">
	<input type="text"  size="5" name="bottleweight" id="bottleweight" required value="<?php echo $productrs['BottleWeight']; ?>"/>
	</td>
	</tr>


	<tr>
	<td>&nbsp;</td>
	<td colspan="3">
	<input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn""/>
	&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
	</td>
	</tr>
	</table>
	</form>
<?php			
 }


if($_REQUEST['mode'] == 'editpar')
{
	$product = mysql_query("SELECT * FROM ".APP."mstrproduct prj WHERE prj.ID = ".$_REQUEST['sid']) or die(mysql_error());
	$productrs = mysql_fetch_array($product);
?>
				<form name="Productform" action="mdlProduct.php?mode=editpar" method="post" id="Productform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Parent Code</td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;" type="text" name="productcode" id="productcode" value="<?php echo $productrs['Code']; ?>" readonly="readonly"/><input type="hidden" name="ciid" id="ciid" value="<?php echo $productrs['ID']; ?>" >
    </td>
    </tr>
  <tr>
    <td>Parent Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;" type="text" name="productname" value="<?php echo $productrs['ProductName']; ?>" id="productname" required onChange="validateparentchild('productname')"/>
    <div id="pcerrdiv" class="msg_exists" style="display:none;">&nbsp;Parent already exists &nbsp;</div>
	</tr>

  <tr>
    <td>Unit of measurement<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
	<select id="uom" name="uom" required onChange="unitOfMeasure()">
	<option value="">--Select--</option>
	<option value="1" <?php if($productrs['DeliveryMode'] == 1) { ?> selected <?php } ?> >Numbers</option>
	<option value="2" <?php if($productrs['DeliveryMode'] == 2) { ?> selected <?php } ?> >Sets</option>
	</select>
	<?php if($productrs['DeliveryMode'] == 1) { ?>
	<input type="text" id="uomnumber" name="uomnumber" required value="<?php echo $productrs['DeliveryMode']; ?>" />
	<?php } ?>
	</td>
	</tr>

	<tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }

 if($_REQUEST['mode'] == 'set')
{
?>
	<form name="ProductionFlowformSetting" action="mdlProductionFlow.php?mode=set" method="post" id="ProductionFlowformSetting" >
	
	<table width="100%" border="0" id="workflowtable">
	<tr>
	<td colspan="4" align="center"><b>Setting</b></td>
	</tr>
	<tr>
	<td>Stage</td>
	<td>Machine</td>
	<td colspan="2">&nbsp;</td>
	</tr>
<?php
	$productionFlow = mysql_query("select `ID`, `Code`, `WorkflowMasterName`,`Description` from ".APP."mstrworkflow where ID = ".$_REQUEST['sid']) or die(mysql_error());
	$productionFlowrs = mysql_fetch_array($productionFlow);
	
	$pfStage = mysql_query("SELECT ws.StageID, s.StageName, w.ID, wsm.MachineID, m.MachineName FROM ".APP."luworkflow w JOIN ".APP."txnworkflowstage ws ON ws.WorkFlowID = w.ID LEFT OUTER JOIN ".APP."txnworkflowstagemachine wsm ON wsm.WorkflowID = w.ID AND wsm.StageID = ws.StageID JOIN ".APP."lustage s ON s.ID = ws.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wsm.MachineID WHERE w.MasterID = ".$productionFlowrs['ID']." ORDER BY ws.StageSequence ASC") or die(mysql_error());
	
	while($pfStagers = mysql_fetch_array($pfStage))
	{		
?>
<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='pfStageID[]' id='pfStageID<?php echo $pfStagers['StageID']; ?>' value='<?php echo $pfStagers['StageID']; ?>' ><?php echo $pfStagers['StageName']." - ".$pfStagers['StageID']; ?></td>
	<td><select id="machine" name="machine[]"><option value="" >--Select--</option>
	<?php
		$machine = mysql_query("SELECT ID, CONCAT(Code, ' - ', MachineName) Machine FROM ".APP."lumachine WHERE IsActive = 1 ORDER BY CONCAT(Code, ' - ', MachineName) ASC") or die(mysql_error());
		while($machiners = mysql_fetch_array($machine))
		{
			?>
			<option value="<?php echo $machiners['ID']; ?>" <?php if($machiners['ID'] == $pfStagers['MachineID']) { ?> selected <?php } ?> ><?php echo $machiners['Machine']; ?></option>
			<?php
		}
	?></select>
	</td>
	<td colspan="2"><a href="javascript:addTemp(<?php echo $pfStagers['StageID']; ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;">Temperature</a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>temperature">
	<tbody>
	<?php
	$temperatureQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 1") or die(mysql_error());
	
	while($temperaturers = mysql_fetch_array($temperatureQry))
	{
	?>
	<span><input type="text"  name="<?php echo $temperaturers['StageID']; ?>temperature[]" id="<?php echo $temperaturers['StageID'];?>temperature" value="<?php echo $temperaturers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	</tbody>
	</table>
	&nbsp;
	<a href="javascript:addPress(<?php echo $pfStagers['StageID']; ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;">Pressure</a>
	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>pressure">
	<tbody>
	<?php
	$pressureQry = mysql_query("SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 2") or die(mysql_error());
	
	while($pressurers = mysql_fetch_array($pressureQry))
	{
	?>
	<span><input type="text"  name="<?php echo $pressurers['StageID']; ?>pressure[]" id="<?php echo $pressurers['StageID'];?>pressure" value="<?php echo $pressurers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	?>	
	
	
	</tbody>
	</table>&nbsp;
	
	</td>
	<input class ="sbox2" type='hidden' name='pfWorkflowID' id='pfWorkflowID' value='<?php echo $pfStagers['ID']; ?>' >
</tr>
<?php
	}

?>

  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }


 if($_REQUEST['mode']=='view')
 {
	
 $stage = mysql_query("select `STAGE_ID`,`CODE`,`STAGE_NAME`,`DESCRIPTION` from ".APP."stage where stage_id =".$_REQUEST['sid']) or die(mysql_error());
$sid = mysql_fetch_array($stage);
 ?>
				<form name="stageform" action="stage_store.php?mode=edit" method="post" id="stageform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Stage Code</td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="stagecode" value="<?php echo $sid['CODE']; ?>" readonly="readonly"/><input type="hidden" name="sid" id="sid" value="<?php echo $sid['STAGE_ID']; ?>" readonly >
    </td>
    </tr>
  <tr>
    <td>Stage Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="stageame" value="<?php echo $sid['STAGE_NAME']; ?>" id="stage"  required onChange="validate();" readonly/>
    <div id="roleerr" class="msg_exists" style="display:none;">&nbsp;Already Exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
     <textarea name="description" cols="36" rows="3" readonly><?php echo $sid['DESCRIPTION']; ?></textarea>
      </td>
  </tr>
  <tr>
    <td>Select Role&nbsp;<span class="validationerrornotify">&nbsp;*</span></td>
    <td width="20%">
   <select id="sbox1" name="sbox1" size="10" style="width:210px; height:200px;"  multiple="multiple" disabled="disabled">
									<?php
                                	$stage =mysql_query("select r.ID,r.NAME from ".APP."ROLE_ENUM r where not exists (select `ROLE` from ".APP."stage_role s where s.stage =".$_REQUEST['sid']." and s.role = r.ID )") or die(mysql_error());
                                	while($row = mysql_fetch_array($stage)){?>
                                	<option value='<?php echo $row['ID']; ?>'><?php echo $row['NAME']; ?></option>
                        			<?php }?>
                         			</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " disabled="disabled" />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " disabled="disabled" />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " disabled="disabled" />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" disabled="disabled" /></td>
    <td width="63%">
     <select id="sbox2" name="sbox2" size="10" style="width:210px; height:200px;" multiple="multiple" disabled="disabled" >           
                                    <?php
                                	$estage =mysql_query("select r.ID,r.NAME from ".APP."ROLE_ENUM r where exists (select `ROLE` from ".APP."stage_role s where s.stage =".$_REQUEST['sid']." and s.role = r.ID )") or die(mysql_error());
                                	while($srow = mysql_fetch_array($estage)){?>
                                	<option value='<?php echo $srow['ID']; ?>'><?php echo $srow['NAME']; ?></option>
                        			<?php }?>
                          			</select>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
     <a href="liststage.php">
        <input name="Cancel" type="button"  value="OK"/>
</a></td>
    </tr>
</table>
                         
				</form> 

<?PHP } ?>
			
	</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>