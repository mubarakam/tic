<?php
 include('meta_script_link.php');
?><head>
<link href="css/jquery.ui.all.css" rel="stylesheet"/>
<link href="css/jquery.ui.tabs.css" rel="stylesheet"/>
<link href="css/demos.css" rel="stylesheet"/>

<script src="js/jquery.ui.core.js"></script> 
<script src="js/jquery.ui.widget.js"></script> 
<script src="js/jquery.ui.tabs.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script type="text/javascript" src="script/jquery-ui.min.js"></script> 
<script type="text/javascript" src="script/jquery.multiselect.min.js"></script>

<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
function getMachine()
{
	var prsvalue = document.getElementById('process').value;
	//alert(prsvalue);
	if (window.XMLHttpRequest)
	{
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			//alert(xmlhttp.responseText);
			document.getElementById("machine").innerHTML = xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","ajaxRequest.php?req=getprs&prs="+prsvalue, true);
	xmlhttp.send();
}

function getToHour()
{
	var frmHr = document.getElementById('fromhour').value;
	
	if (window.XMLHttpRequest)
	{
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("tohour").innerHTML = xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","ajaxRequest.php?req=gettohr&frmhr="+frmHr, true);
	xmlhttp.send();
}
function getToMinute()
{
	var frmHr = document.getElementById('fromhour').value;
	var frmMin = document.getElementById('fromminute').value;
	if(frmHr)
	{
		if (window.XMLHttpRequest)
		{
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
		else
		{
			// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange=function(){
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
				document.getElementById("tominute").innerHTML = xmlhttp.responseText;
			}
		}
		xmlhttp.open("GET","ajaxRequest.php?req=gettomin&frmhr="+frmHr+"&frmmin="+frmMin, true);
		xmlhttp.send();
	}
	else
	{
		document.getElementById('fromminute').value = "";
		alert('Please select the Hour & proceed.');
		return false;
	}

}


$(document).ready(function() {
	
	var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	
	$(".kpress").keypress(function (e)
	{
		e.preventDefault();
	});
	$("input[aria-controls=example]").focus();
	
	jQuery(function(){
                jQuery('#proddate').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
					  jQuery( this ).datepicker('option','maxDate', jQuery('#endtime').val() );
						
                    }
                });
                jQuery('#endtime').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
                        jQuery( this ).datepicker('option','minDate', jQuery('#proddate').val() );
                    }
                });
            })
		});

function clearDateElement(ele,n)
{
	var inputeles = document.getElementsByTagName("input");
	for(var i=0;i<inputeles.length;i++)
	{
		if(inputeles[i].type == "text" && inputeles[i] != ele  && inputeles[i] != n)
		{
			inputeles[i].value = "";
		}
	}
}

</script>
<div class="main-container">
<?php
include('includes/header.php');
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Production</a>&nbsp;&raquo;&nbsp;Longue Activity</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
<div id="dashlet-panel" class="dashlet-panel-full">
<form name="longueform" action="mdllongue.php" method="post" id="longueform" onSubmit="return btnSubmit();">
<?php
$processQry = mysql_query("SELECT ID ProcessID, StageName ProcessName FROM ".APP."lustage WHERE IsActive = 1 ORDER BY StageName") or die(mysql_error());
?>
<table width="100%" border="0" id="workflowtable">
<tr>
<td><select id="process" name="process" required onChange="getMachine()">
<option value="">--Process--</option>
<?php
while($prcrs = mysql_fetch_array($processQry))
{
?>
<option value="<?php echo $prcrs['ProcessID']; ?>"><?php echo $prcrs['ProcessName']; ?></option>
<?php
}
?>
</select>
</td>
<td><select id="machine" name="machine" >
<option value="">--Machine--</option>
</select>
</td>
<td>
<?php
	$empList = "SELECT ID, Name FROM ".APP."mstremployee WHERE IsActive = 1";
	$empListExe = mysql_query($empList) or die(mysql_error());
	?>
	<select id="ddEmployee" name="ddEmployee" class="required" required >
	<option value="">--Operator--</option>
	<?php

	while($emprs = mysql_fetch_array($empListExe))
	{
	?>
	<option value="<?php echo $emprs['ID']; ?>"><?php echo $emprs['Name']; ?></option>
	<?php
	}
	?>
	</select>
</td>
<td>Production Hour</td>
<td colspan="7">
<div id="div1" style="display:block;">
            <input type="text" name="proddate" class="kpress" style="width:100px;" id="proddate" required placeholder="Select Date" />,&nbsp;
			<?php
			$hr = mysql_query("SELECT Value FROM ".APP."luhour ORDER BY Value ASC") or die(mysql_error());
			$min = mysql_query("SELECT Value FROM ".APP."luminute ORDER BY Value ASC") or die(mysql_error());
			?>
			From&nbsp;<select id="fromhour" name="fromhour" required onChange="getToHour()">
			<option value="">--HH--</option>
			<?php
			while($hrs = mysql_fetch_array($hr))
			{
			?>
			<option value="<?php echo $hrs['Value']; ?>"><?php echo $hrs['Value']; ?></option>
			<?php
			}
			?>
			</select>
			<select id="fromminute" name="fromminute" required onChange="getToMinute()">
			<option value="">--MM--</option>
			<?php
			while($mrs = mysql_fetch_array($min))
			{
			?>
			<option value="<?php echo $mrs['Value']; ?>"><?php echo $mrs['Value']; ?></option>
			<?php
			}
			$min = mysql_query("SELECT Value FROM ".APP."luminute ORDER BY Value ASC") or die(mysql_error());
			?>
			</select>
			To&nbsp;<select id="tohour" name="tohour" required >
			<option value="">--HH--</option>
			</select>
			<select id="tominute" name="tominute" required >
			<option value="">--MM--</option>
			</select>
          </div>
</td>
</tr>
<tr>
<td colspan="8" style="text-align:center;">
<textarea id="remark" name="remark" required ></textarea>
</td>
</tr>
<tr>
<td colspan="8" style="text-align:center;">
<input type="submit" class="stage" name="prodEntry" value="Submit" id="prodEntry""/>
&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
</td>
</tr>
</table>


</form>

</div>
</div>
<?php include('includes/footer.php'); ?>
</div>
</body>
</html>