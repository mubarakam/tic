<?php
 include('meta_script_link.php');
?><head>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
function validate(a){var val = $("#"+a).val();$.ajax({type: "post",url: "ajaxValidate.php?frm="+a+"&val="+val,success: function(data){if(data == "exist"){$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});document.getElementById('errdiv').style.display='inline';$("#addbtn").attr('disabled','true')}else if(data != "exist"){$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});document.getElementById('errdiv').style.display='none';$("#addbtn").removeAttr('disabled');}}});}
function getProcess()
{
	window.location = "ctrlStandard.php?pfid="+document.getElementById("processflow").value+"&mode=add";
}

function addTemp(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addtemperature&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}

function addPress(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addpressure&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addTime(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addtime&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addWeight(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addweight&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addDensity(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=adddensity&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addHardness(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addhardness&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
</script>

<div class="main-container">
<?php include('includes/header.php');


####### Need to declare########
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Standard</div>
<div class="msg_wrap">
<?php 
   if($_REQUEST['msg']=='done')
        {?>
        <div class="msg_success">
           Workflow Created Successfully !!
        </div>
	<?php }	
        if($_REQUEST['msg']=='fail')
        {?>
        <div class="msg_error">
            Workflow Creation Failed !!
        </div>
       	<?php } ?></div>
<div class="backlink">
                 <a href="vwStandard.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
	
		 
        	
  		
        

 <?php
if($_REQUEST['mode'] == 'add')
{
   $wcode = mysql_query("SELECT CONCAT(`CODE`,`CurrentRange` + 1) as code from ".APP."cfgdocumenttype where `ObjectTypeId` = 9") or die(mysql_error());
   $code = mysql_fetch_array($wcode); ?>					
                    <form name="standardform" action="mdlStandard.php?mode=add" method="post" id="stageform" >
                        
                        <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Standard Code</td>
    <td colspan="3">
      <input style="width:60px;"  type="text"  maxlength="255" name="standardcode" value="<?php echo $code['code']; ?>" readonly="readonly"/>
    </td>
    </tr>
	<tr>
    <td>Process Flow<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
	<input type='hidden' name='pfid' id='pfid' value='<?php echo $_REQUEST['pfid']; ?>' />
	<select id="processflow" required onchange="getProcess()">
	<option value="">--Select--</option>
	<?php
	$getProcessQry = mysql_query("SELECT ID, WorkflowName FROM ".APP."luworkflow WHERE IsActive = 1") or die(mysql_error());
	while($rs = mysql_fetch_array($getProcessQry))
	{
	?>
	<option value="<?php echo $rs['ID']; ?>" <?php if($_REQUEST['pfid'] == $rs['ID']) { ?> selected <?php }?>  ><?php echo $rs['WorkflowName']; ?></option>	
	<?php
	}
	?>
	</select>
	</td>
    </tr>
	<tr>
    <td>Standard Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
	<input style="width:300px;maxlength:255px;" type="text" name="standardname" id="standardname" required onChange="validate('standardname');"/>
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Standard already exists &nbsp;</div></td>
    </tr>
	<tr>
    <td>Description</td>
    <td colspan="3">
	<textarea name="description" cols="34" rows="3"></textarea>
	</td>
	</tr>
  <tr>
  <td colspan="4" style="text-align:center">Setting(s)</td>
  </tr>
  <tr>
  <td style="text-align:center" width="25%">Process</td>
  <td style="text-align:center" width="25%">Machine</td>
  <td style="text-align:center" width="25%">Std. Value(s)</td>
  <td style="text-align:center" width="25%">Target/Hour</td>
  </tr>
  <?php
if($_REQUEST['pfid'])
{
	$pfStageQry = "SELECT ws.StageID, s.StageName, w.ID, sm.MachineID, IFNULL(m.MachineName, 'NA') MachineName FROM ".APP."luworkflow w JOIN ".APP."txnworkflowstage ws ON ws.WorkFlowID = w.ID LEFT OUTER JOIN ".APP."txnstagemachine sm ON sm.StageID = ws.StageID JOIN ".APP."lustage s ON s.ID = ws.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = sm.MachineID WHERE w.ID = ".$_REQUEST['pfid']." ORDER BY ws.StageSequence ASC";
	$pfStageExe = mysql_query($pfStageQry) or die(mysql_error());
	
	while($pfResult = mysql_fetch_array($pfStageExe))
	{
		//echo $pfResult['StageName']." - ".$pfResult['MachineName'];
		$stagemachine = $pfResult['StageID']."".$pfResult['MachineID'];
	?>
	<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='stage[]' id='stage<?php echo $pfResult['StageID']; ?>' value='<?php echo $pfResult['StageID']; ?>' /><?php echo $pfResult['StageName']; ?></td>
	<td align="center"><input class ="sbox2" type='hidden' name='machine[]' id='machine<?php echo $pfResult['MachineID']; ?>' value='<?php echo $pfResult['MachineID']; ?>' ><?php echo $pfResult['MachineName']; ?></td>
	<td width="25%">
	<?php
	if($pfResult['MachineID'])
	{
	?>
	<!--TEMPERATURE-->
	<a href="javascript:addTemp(<?php echo $stagemachine ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Temperature" src="images/temperature.png"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>temperature">
	<tbody></tbody>
	<!--<tbody><span><input type="text"  name="<?php echo $stagemachine ?>temperature[]" id="<?php echo $stagemachine ?>temperature" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>-->
	</table>&nbsp;
	<!--PRESSURE-->
	<a href="javascript:addPress(<?php echo $stagemachine ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Pressure" src="images/pressure.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>pressure">
	<tbody></tbody>
	<!--<tbody><span><input type="text"  name="<?php echo $stagemachine ?>pressure[]" id="<?php echo $stagemachine ?>pressure" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>-->
	</table>&nbsp;
	<!--TIME-->
	<a href="javascript:addTime(<?php echo $stagemachine ?>+'time')" id="Time" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Time" src="images/time.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>time">
	<tbody></tbody>
	</table>&nbsp;
	<!--<tbody><span><input type="text"  name="<?php echo $stagemachine ?>time[]" id="<?php echo $stagemachine ?>time" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>-->
	<!--WEIGHT-->
	<a href="javascript:addWeight(<?php echo $stagemachine ?>+'weight')" id="Weight" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Weight" src="images/weight.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>weight">
	<tbody></tbody>
	</table>&nbsp;
	<!--<tbody><span><input type="text"  name="<?php echo $stagemachine ?>weight[]" id="<?php echo $stagemachine ?>weight" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>-->
	<!--DENSITY-->
	<a href="javascript:addWeight(<?php echo $stagemachine ?>+'density')" id="Density" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Density" src="images/density.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>density">
	<tbody></tbody>
	</table>&nbsp;
	<!--<tbody><span><input type="text"  name="<?php echo $stagemachine ?>density[]" id="<?php echo $stagemachine ?>density" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>-->
	<!--HARDNESS-->
	<a href="javascript:addWeight(<?php echo $stagemachine ?>+'hardness')" id="Hardness" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Hardness" src="images/hardness.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>hardness">
	<tbody></tbody>
	</table>
	<!--<tbody><span><input type="text"  name="<?php echo $stagemachine ?>hardness[]" id="<?php echo $stagemachine ?>hardness" size="5" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>-->
	<?php
	}
	?>
	</td>
	<td width="25%"><input type="text" id="<?php echo $stagemachine; ?>target[]" name="<?php echo $stagemachine; ?>target[]" style="width:50px;" /></td>
	</tr>
	<?php
	}
}

?>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
              
                         
				</form>
<?php			
 }

if($_REQUEST['mode'] == 'set')
{
	$standardValue = mysql_fetch_array(mysql_query("SELECT ms.Code, ms.WorkflowID, ms.Name, ms.Description, wf.WorkflowName FROM ".APP."mstrstandard ms JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID WHERE ms.ID = ".$_REQUEST['sid'])) or die(mysql_error());
?>
<form name="standardform" action="mdlStandard.php?mode=set" method="post" id="stageform" >
<table width="100%" border="0" id="workflowtable">
<tr>
    <td width="14%">Standard Code</td>
    <td colspan="3"><?php echo $standardValue['Code']; ?><input type='hidden' name='stdid' id='stdid' value='<?php echo $_REQUEST['sid']; ?>' />
    </td>
    </tr>
	<tr>
    <td>Process Flow</td>
    <td colspan="3"><?php echo $standardValue['WorkflowName']; ?>
	<input type='hidden' name='pfid' id='pfid' value='<?php echo $standardValue['WorkflowID']; ?>' />
	</td>
    </tr>
	<tr>
    <td>Standard Name</td>
    <td colspan="3"><?php echo $standardValue['Name']; ?></td><input type='hidden' name='standardname' id='standardname' value='<?php echo $standardValue['Name']; ?>' />
    </tr>
	<tr>
    <td>Description</td>
    <td colspan="3">
	<textarea name="description" cols="34" rows="3"><?php echo $standardValue['Description']; ?></textarea>
	</td>
	</tr>
  <tr>
  <td colspan="4" style="text-align:center">Setting(s)</td>
  </tr>
  <tr>
  <td style="text-align:center" width="25%">Process</td>
  <td style="text-align:center" width="25%">Machine</td>
  <td style="text-align:center" width="25%">Std. Value(s)</td>
  <td style="text-align:center" width="25%">Target/Hour</td>
  </tr>
  <?php
if($_REQUEST['sid'])
{
	$stdStageQry = "SELECT DISTINCT ms.ID StandardID, IF(tss.StageID IS NULL, tws.StageID, tss.StageID) StageID, s.StageName, IF(tss.MachineID IS NULL, tsm.MachineID, IF(tss.MachineID = tsm.MachineID, tss.MachineID, tsm.MachineID)) MachineID, IFNULL(m.MachineName, 'NA') MachineName FROM ".APP."mstrstandard ms JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID JOIN ".APP."txnworkflowstage tws ON tws.WorkflowID = wf.ID LEFT OUTER JOIN ".APP."txnstandardsetting tss ON tss.StandardID = ms.ID AND tss.StageID = tws.StageID JOIN ".APP."lustage s ON s.ID = IF(tss.StageID IS NULL, tws.StageID, tss.StageID) LEFT OUTER JOIN ".APP."txnstagemachine tsm ON tsm.StageID = IF(tss.StageID IS NULL, tws.StageID, tss.StageID) LEFT OUTER JOIN ".APP."lumachine m ON m.ID = tsm.MachineID WHERE ms.ID = ".$_REQUEST['sid']." ORDER BY tws.StageSequence ASC";
	//$stdStageQry = "SELECT DISTINCT ms.ID StandardID, tss.StageID, s.StageName, tss.MachineID, IFNULL(m.MachineName, 'NA') MachineName FROM mstrstandard ms JOIN txnstandardsetting tss ON tss.StandardID = ms.ID JOIN lustage s ON s.ID = tss.StageID LEFT OUTER JOIN lumachine m ON m.ID = tss.MachineID WHERE ms.ID = ".$_REQUEST['sid']." ORDER BY tss.ID ASC";
	//echo $stdStageQry;
	$stdStageExe = mysql_query($stdStageQry) or die(mysql_error());
	
	while($stdResult = mysql_fetch_array($stdStageExe))
	{
		//echo $pfResult['StageName']." - ".$pfResult['MachineName'];
		$stagemachine = $stdResult['StageID']."".$stdResult['MachineID'];
	?>
	<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='stage[]' id='stage<?php echo $stdResult['StageID']; ?>' value='<?php echo $stdResult['StageID']; ?>' /><?php echo $stdResult['StageName']; ?></td>
	<td align="center"><input class ="sbox2" type='hidden' name='machine[]' id='machine<?php echo $stdResult['MachineID']; ?>' value='<?php echo $stdResult['MachineID']; ?>' ><?php echo $stdResult['MachineName']; ?></td>
	<td>
	<?php
	if($stdResult['MachineID'])
	{
	?>
	<!--TEMPERATURE-->
	<a href="javascript:addTemp(<?php echo $stagemachine ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Temperature" src="images/temperature.png"/></a>
	<?php
	$stdTempQry = "SELECT tss.StandardID, tss.AttributeID, tss.Value FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$stdResult['StandardID']." AND tss.StageID = ".$stdResult['StageID']." AND tss.MachineID = ".$stdResult['MachineID']." AND tss.AttributeID = ".TEMPERATURE;
	$stdTempExe = mysql_query($stdTempQry) or die(mysql_error());
	
	if(mysql_num_rows($stdTempExe))
	{
		while($stdTempRS = mysql_fetch_array($stdTempExe))
		{
		?>
			<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>temperature">
			<tbody><span><input type="text"  name="<?php echo $stagemachine ?>temperature[]" id="<?php echo $stagemachine ?>temperature" size="5" value="<?php echo $stdTempRS['Value']; ?> " required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>
			</table>&nbsp;
		<?php
		}		
	}
	else
	{
	?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>temperature">
		<tbody></tbody>
		</table>&nbsp;
	<?php
	}
	?>
	<!--PRESSURE-->
	<a href="javascript:addPress(<?php echo $stagemachine ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Pressure" src="images/pressure.png" width="16px" height="16px"/></a>
	<?php
	$stdPressQry = "SELECT tss.StandardID, tss.AttributeID, tss.Value FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$stdResult['StandardID']." AND tss.StageID = ".$stdResult['StageID']." AND tss.MachineID = ".$stdResult['MachineID']." AND tss.AttributeID = ".PRESSURE;
	$stdPressExe = mysql_query($stdPressQry) or die(mysql_error());
	
	if(mysql_num_rows($stdPressExe))
	{
		while($stdPressRS = mysql_fetch_array($stdPressExe))
		{
		?>
			<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>pressure">
			<tbody><span><input type="text"  name="<?php echo $stagemachine ?>pressure[]" id="<?php echo $stagemachine ?>pressure" size="5" value="<?php echo $stdPressRS['Value']; ?>" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>
			</table>&nbsp;
		<?php
		}
	}
	else
	{
	?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>pressure">
		<tbody></tbody>
		</table>&nbsp;
	<?php
	}
	?>
	<!--TIME-->
	<a href="javascript:addTime(<?php echo $stagemachine ?>+'time')" id="Time" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Time" src="images/time.png" width="16px" height="16px"/></a>
	<?php
	$stdTimeQry = "SELECT tss.StandardID, tss.AttributeID, tss.Value FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$stdResult['StandardID']." AND tss.StageID = ".$stdResult['StageID']." AND tss.MachineID = ".$stdResult['MachineID']." AND tss.AttributeID = ".TIME;
	$stdTimeExe = mysql_query($stdTimeQry) or die(mysql_error());
	
	if(mysql_num_rows($stdTimeExe))
	{
		while($stdTimeRS = mysql_fetch_array($stdTimeExe))
		{
		?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>time">
		<tbody><span><input type="text"  name="<?php echo $stagemachine ?>time[]" id="<?php echo $stagemachine ?>time" size="5" value="<?php echo $stdTimeRS['Value']; ?>" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>
		</table>&nbsp;
		<?php
		}
	}
	else
	{
	?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>time">
		<tbody></tbody>
		</table>&nbsp;
	<?php
	}
	?>
	<!--WEIGHT-->
	<a href="javascript:addWeight(<?php echo $stagemachine ?>+'weight')" id="Weight" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Weight" src="images/weight.png" width="16px" height="16px"/></a>

	<?php
	$stdWeightQry = "SELECT tss.StandardID, tss.AttributeID, tss.Value FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$stdResult['StandardID']." AND tss.StageID = ".$stdResult['StageID']." AND tss.MachineID = ".$stdResult['MachineID']." AND tss.AttributeID = ".WEIGHT;
	$stdWeightExe = mysql_query($stdWeightQry) or die(mysql_error());
	if(mysql_num_rows($stdWeightExe))
	{
		while($stdWeightRS = mysql_fetch_array($stdWeightExe))
		{
		?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>weight">
		<tbody><span><input type="text"  name="<?php echo $stagemachine ?>weight[]" id="<?php echo $stagemachine ?>weight" size="5" value="<?php echo $stdWeightRS['Value']; ?>" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>
		</table>&nbsp;
		<?php
		}		
	}
	else
	{
	?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>weight">
		<tbody></tbody>
		</table>&nbsp;
	<?php
	}
	?>
	<!--DENSITY-->
	<a href="javascript:addWeight(<?php echo $stagemachine ?>+'density')" id="Density" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Density" src="images/density.png" width="16px" height="16px"/></a>
	<?php
	$stdDensityQry = "SELECT tss.StandardID, tss.AttributeID, tss.Value FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$stdResult['StandardID']." AND tss.StageID = ".$stdResult['StageID']." AND tss.MachineID = ".$stdResult['MachineID']." AND tss.AttributeID = ".DENSITY;
	$stdDensityExe = mysql_query($stdDensityQry) or die(mysql_error());
	if(mysql_num_rows($stdDensityExe))
	{
		while($stdDensityRS = mysql_fetch_array($stdDensityExe))
		{
		?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>density">
		<tbody><span><input type="text"  name="<?php echo $stagemachine ?>density[]" id="<?php echo $stagemachine ?>density" size="5" value="<?php echo $stdDensityRS['Value']; ?>" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>
		</table>&nbsp;
		<?php
		}
	}
	else
	{
	?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>density">
		<tbody></tbody>
		</table>&nbsp;
	<?php
	}
	?>
	<!--HARDNESS-->
	<a href="javascript:addWeight(<?php echo $stagemachine ?>+'hardness')" id="Hardness" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Hardness" src="images/hardness.png" width="16px" height="16px"/></a>
	<?php
	$stdHardnessQry = "SELECT tss.StandardID, tss.AttributeID, tss.Value FROM ".APP."txnstandardsetting tss WHERE tss.StandardID = ".$stdResult['StandardID']." AND tss.StageID = ".$stdResult['StageID']." AND tss.MachineID = ".$stdResult['MachineID']." AND tss.AttributeID = ".HARDNESS;
	$stdHardnessExe = mysql_query($stdHardnessQry) or die(mysql_error());
	if(mysql_num_rows($stdHardnessExe))
	{
		while($stdHardnessRS = mysql_fetch_array($stdHardnessExe))
		{
		?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>hardness">
		<tbody><span><input type="text"  name="<?php echo $stagemachine ?>hardness[]" id="<?php echo $stagemachine ?>hardness" size="5" value="<?php echo $stdHardnessRS['Value']; ?>" required />&nbsp;<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span></tbody>
		</table>
		<?php
		}
	}
	else
	{
	?>
		<table width="100%" border="0" id="workflowtable<?php echo $stagemachine; ?>" class="example<?php echo $stagemachine; ?>hardness">
		<tbody></tbody>
		</table>
	<?php
	}
	}
	?>
	</td>
	<td>
	<?php
	if($stdResult['MachineID'])
	{
		$stdTargetQry = "SELECT tst.Target FROM ".APP."txnstandardtarget tst WHERE tst.StandardID = ".$stdResult['StandardID']." AND tst.StageID = ".$stdResult['StageID']." AND tst.MachineID = ".$stdResult['MachineID'];
	}
	else
	{
		$stdTargetQry = "SELECT tst.Target FROM ".APP."txnstandardtarget tst WHERE tst.StandardID = ".$stdResult['StandardID']." AND tst.StageID = ".$stdResult['StageID']." AND tst.MachineID IS NULL";
	}

	//echo $stdTargetQry;
	$stdTargetRS = mysql_fetch_array(mysql_query($stdTargetQry)) or die(mysql_error());
	?>
	<input type="text" id="<?php echo $stagemachine; ?>target[]" name="<?php echo $stagemachine; ?>target[]" style="width:50px;" value="<?php echo $stdTargetRS['Target']; ?>"/>
	</td>
	</tr>
	<?php
	}
}

?>
<tr>
<td>&nbsp;</td>
<td colspan="3"><input type="submit" class="stage" name="addstage" value="Submit" id="addstage" />&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
</td>
</tr>
</table>
</form>

<?php
}


 if($_REQUEST['mode']=='view')
 {
	
 $stage = mysql_query("select `STAGE_ID`,`CODE`,`STAGE_NAME`,`DESCRIPTION` from ".APP."stage where stage_id =".$_REQUEST['sid']) or die(mysql_error());
$sid = mysql_fetch_array($stage);
 ?>
				<form name="stageform" action="stage_store.php?mode=edit" method="post" id="stageform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Stage Code</td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="stagecode" value="<?php echo $sid['CODE']; ?>" readonly="readonly"/><input type="hidden" name="sid" id="sid" value="<?php echo $sid['STAGE_ID']; ?>" readonly >
    </td>
    </tr>
  <tr>
    <td>Stage Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;  font-family:Arial, Helvetica, sans-serif;"  type="text"  maxlength="255" name="stageame" value="<?php echo $sid['STAGE_NAME']; ?>" id="stage"  required onChange="validate();" readonly/>
    <div id="roleerr" class="msg_exists" style="display:none;">&nbsp;Already Exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
     <textarea name="description" cols="36" rows="3" readonly><?php echo $sid['DESCRIPTION']; ?></textarea>
      </td>
  </tr>
  <tr>
    <td>Select Role&nbsp;<span class="validationerrornotify">&nbsp;*</span></td>
    <td width="20%">
   <select id="sbox1" name="sbox1" size="10" style="width:210px; height:200px;"  multiple="multiple" disabled="disabled">
									<?php
                                	$stage =mysql_query("select r.ID,r.NAME from ".APP."ROLE_ENUM r where not exists (select `ROLE` from ".APP."stage_role s where s.stage =".$_REQUEST['sid']." and s.role = r.ID )") or die(mysql_error());
                                	while($row = mysql_fetch_array($stage)){?>
                                	<option value='<?php echo $row['ID']; ?>'><?php echo $row['NAME']; ?></option>
                        			<?php }?>
                         			</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " disabled="disabled" />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " disabled="disabled" />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " disabled="disabled" />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" disabled="disabled" /></td>
    <td width="63%">
     <select id="sbox2" name="sbox2" size="10" style="width:210px; height:200px;" multiple="multiple" disabled="disabled" >           
                                    <?php
                                	$estage =mysql_query("select r.ID,r.NAME from ".APP."ROLE_ENUM r where exists (select `ROLE` from ".APP."stage_role s where s.stage =".$_REQUEST['sid']." and s.role = r.ID )") or die(mysql_error());
                                	while($srow = mysql_fetch_array($estage)){?>
                                	<option value='<?php echo $srow['ID']; ?>'><?php echo $srow['NAME']; ?></option>
                        			<?php }?>
                          			</select>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input class ="sbox2" type='hidden' name='sbox_value' id='sbox_value' value='' >
     <a href="liststage.php">
        <input name="Cancel" type="button"  value="OK"/>
</a></td>
    </tr>
</table>
                         
				</form> 

<?PHP } ?>
			
	</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>