<?php
include('meta_script_link.php');
//print_r($_REQUEST); ?>
<style>
input.error {
	border: 2px thin red;
	background-color:#F00 !important;
}
<!--table#example tr td   { border:1px groove black; }-->

</style>
<script type="text/javascript" src="script/jquery.chosen.min.js"></script>
<script type="text/javascript" src="script/jquery-ui.min.js"></script>
<script type="text/javascript" src="script/jquery.multiselect.min.js"></script>
<script>
$(document).ready(function() {
	$('#example').dataTable().fnDestroy();
	
	$('#example').dataTable({
			"bJQueryUI" : true, 
			"bFilter": true,
			"aaSorting": [],
			"bPaginate": false,
			"sScrollX": "100%",
			"sScrollXInner": "100%",
			"sScrollY": "400px",
			"sScrollYInner": "100%",
			"bScrollCollapse": true,
            });
	
	var oTable = $('#example').dataTable();
	$("#example tbody tr").live("click", function(event){
			$(this).toggleClass( 'row_selected' );
			});
});

function projectbindd()
{
	
	var rid=document.getElementById("rid").value
		var date=document.getElementById("date").value
		var rddf=document.getElementById("rddf").value
		var rddt=document.getElementById("rddt").value
		var cddf=document.getElementById("cddf").value
		var cddt=document.getElementById("cddt").value
		var dddf=document.getElementById("dddf").value
		var dddt=document.getElementById("dddt").value
	 window.location = "report_project.php?date="+document.getElementById("date").value+"&rid="+rid


}
</script>
<div class="main-container">
  <?php include('includes/header.php');?>
</div>
<div class="bread-crums_wrap">
  <div class="bread-crums"><a href="dashboard.php">Home</a> &raquo; <a href="#">Production</a> &raquo; Std. vs Prod. Setting</div>
  <div class="msg_wrap"> </div>
  <div class="backlink"><a href="dashboard.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a></div>
</div>
<div class="clear"></div>
<div id="dashlet-panel" class="dashlet-panel-full">
  <form action="" id="report" class="" name="report" onSubmit="projectbindd()" method="post"  >
    <table class="" id="workflowtable" width="100%" >
      <tr>
        <td width="10%" height="26" rowspan="3">Work Order :</td>
        <td width="13%" rowspan="3">
					<?php 					 
					 $round = mysql_query("SELECT ID, Code FROM ".APP."txnworkorder WHERE IsActive = 1 ORDER BY Code ASC");
					 ?>
          <select name="rid" id="rid" required >
            <option value="0" selected="selected">Choose one </option>
            <? while($rs =mysql_fetch_array($round))
						{?>
            <option value="<? echo $rs['ID']?>" <? if($_REQUEST['rid'] == $rs['ID']) {  ?> selected="selected" <? }?> > <? echo $rs['Code']; ?> </option>
            <? }?>
        </select>&nbsp;&nbsp;<input type="submit" id="sub" onClick="return validation();" value="get detail(s)" name="submit" /></td>
         
           <td width="17%" align="right"><a href="rptexlstdvsprod.php?rid=<?php echo $_REQUEST['rid'] ?>" ><img src="images/xcel.png" style="border:none;margin-top:5px;" width="20" height="20" alt="Download Report" title="Download Report"> </a>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		</tr>
    </table>
  </form>
<br/>
<?php
$wo = $_REQUEST['rid'];
$columnqry = mysql_query("SELECT DISTINCT sl.CreatedOn CreatedOn, sl.MetadataStageID FROM ".APP."txnmetadatastage tms
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID
WHERE tms.WorkOrderID = ".$wo."
ORDER BY sl.CreatedOn ASC");

$rptExe = mysql_query($rptQuery);
?>
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" width="100%" border="0" class="display" id="example">
        <thead>
          
          <tr>
            <th width="4%">WO Code</th>
            <th width="10%">Parameter Name</th>
            <th width="7%">Stage Name</th>
			<th width="5%">Machine Name</th>
            <th width="5%">Std. Setting</th>
            <th width="5%">WO Setting</th>
			<?php
			while($columnrs = mysql_fetch_array($columnqry))
			{
				?>
				<th width="5%"><?php echo $columnrs['CreatedOn']; ?></th>
				<?php
			}
			?>
			</tr>
		</thead>
        <tbody>
<?php
$mainqry = mysql_query("SELECT DISTINCT wo.ID, wo.Code, wos.AttributeID, wa.Description Attribute, wos.StageID, ws.StageName StageName, wos.Value WOValue, tss.Value StandardValue, wos.MachineID, wm.MachineName, sl.ValueSequence
FROM ".APP."txnworkorder wo
INNER JOIN ".APP."txnworkordersetting wos ON wos.WorkOrderID = wo.ID
INNER JOIN ".APP."mstrstandard ms ON ms.ID = wo.StandardID
INNER JOIN ".APP."txnstandardsetting tss ON tss.StandardID = ms.ID AND tss.StageID = wos.StageID AND tss.MachineID = wos.MachineID AND tss.AttributeID = wos.AttributeID AND tss.ValueSequence = wos.ValueSequence
INNER JOIN ".APP."luattribute wa ON wa.ID = wos.AttributeID
INNER JOIN ".APP."lustage ws ON ws.ID = wos.StageID
INNER JOIN ".APP."lumachine wm ON wm.ID = wos.MachineID
INNER JOIN ".APP."txnmetadatastage tms ON tms.WorkOrderID = wo.ID AND tms.StageID = wos.StageID
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID AND sl.AttributeID = wos.AttributeID AND sl.MachineID = wos.MachineID AND sl.ValueSequence = wos.ValueSequence
WHERE wo.ID = ".$wo." AND wos.AttributeID IS NOT NULL");
while($rs = mysql_fetch_array($mainqry))
{
?>

<tr>
<td><?php echo $rs['Code']; ?></td>
<td><?php echo $rs['Attribute']; ?></td>
<td><?php echo $rs['StageName']; ?></td>
<td><?php echo $rs['MachineName']; ?></td>
<td><?php echo $rs['StandardValue']; ?></td>
<td><?php echo $rs['WOValue']; ?></td>
<?php
$columnqry = mysql_query("SELECT DISTINCT sl.CreatedOn CreatedOn, sl.MetadataStageID FROM ".APP."txnmetadatastage tms
INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID
WHERE tms.WorkOrderID = ".$wo."
ORDER BY sl.CreatedOn ASC");
while($columnrs = mysql_fetch_array($columnqry))
{
	$getValueQry = "SELECT sl.Value FROM ".APP."txnmetadatastage tms INNER JOIN ".APP."txnsettinglog sl ON sl.MetadataStageID = tms.ID WHERE sl.MetadataStageID = ".$columnrs['MetadataStageID']." AND sl.AttributeID = ".$rs['AttributeID']." AND sl.MachineID = ".$rs['MachineID']." AND sl.CreatedOn = '".$columnrs['CreatedOn']."' AND tms.StageID = ".$rs['StageID']." AND sl.ValueSequence = ".$rs['ValueSequence'];
	$getValuers = mysql_fetch_array(mysql_query($getValueQry));
?>
<td><?php echo $getValuers['Value']; ?></td>
<!--<td><?php echo $rs['AttributeID'] ." - ". $rs['MachineID'] ." - ". $columnrs['MetadataStageID'] ." - ". $columnrs['CreatedOn']; ?></td>-->
<?php
}
?>
</tr>

<?php
}
?>
        </tbody>
      </table>
</div>
</div>
</td>
</tr>
</td>
</tr>
</div>
</div>
</div>
<?php include('includes/footer.php'); ?>
</div>
</body></html>