<?php session_start();
ob_start();
include("config.php");
include("includes/classes/productClass.php");
echo "<pre>";
print_r($_REQUEST);

$productcode = $_REQUEST['productcode'];
$productname = $_REQUEST['productname'];

$parentproduct = $_REQUEST['parentproduct'];
$productflow = $_REQUEST['productflow'];
$productid = $_REQUEST['ciid'];
$diamond = $_REQUEST['diamond'];
$bond = $_REQUEST['bond'];
$bottleweight = $_REQUEST['bottleweight'];
$standard = $_REQUEST['standard'];
$deliverymode = $_REQUEST['uom'];
$uomnumber = $_REQUEST['uomnumber'];
//exit;
$product = new productClass();

if($_REQUEST['mode'] == "addpar")
{
	//$product->addProduct($productcode, $productname, $parentproductflag, $parentproduct, $productflow);
	$product->addParent($productcode, $productname, $deliverymode, $uomnumber);
}

if($_REQUEST['mode'] == "editpar")
{
	echo "editpar";
	//$product->updateProduct($productid, $productname, $parentproductflag, $parentproduct, $productflow);
	$product->updateParent($productid, $productname, $deliverymode, $uomnumber);
}

if($_REQUEST['mode'] == "addci")
{
	$product->addProduct($productcode, $productname, $parentproduct, $productflow, $diamond, $bond, $bottleweight, $standard);
}

if($_REQUEST['mode'] == "editci")
{
	$product->updateProduct($productid, $productname, $parentproduct, $productflow, $diamond, $bond, $bottleweight, $standard);
}
?>