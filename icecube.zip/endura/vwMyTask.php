<?php
include('meta_script_link.php');
?>
<div class="main-container">
<?php
include('includes/header.php');
?>
<!-- Bread-Crumb Starts -->

<script type="text/javascript">
function checkboxvalidate(a)
{
	document.getElementById("productionEntry").disabled = false;
}

function getWorkOrderID()
{
	window.location = "vwMyTask.php?woid="+document.getElementById("wolist").value+"&disp=1";
}
</script>

<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Production</a>&nbsp;&raquo;&nbsp;My Task</div>
	<div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<div class="dashlet-panel-full">
<div class="clear"></div>
<form action="mdlMyTask.php" method="post"  name="projectbin" id="projectbin">
<table class="display" id="workflowtable">
<tr>
<td colspan="2">Select Work Order:&nbsp;&nbsp;
<?php
	$woQry = mysql_query("SELECT Code, ID FROM ".APP."txnworkorder WHERE StatusID = ".INPROGRESS." AND IsActive = 1");
?>
<select name="wolist" id="wolist" onChange="getWorkOrderID()">
<option value="0" selected="selected">--Select--</option>
<?php
while($rs = mysql_fetch_array($woQry))
{
?>
	<option value="<?php echo $rs['ID']?>" <?php if($_REQUEST['woid'] == $rs['ID']) {  ?> selected="selected" <?php } ?> > <?php echo $rs['Code']; ?></option>
<?php
}
?>
</select>          
</td>
</tr>
<?php
if($_REQUEST['disp'] == 1)
{
	$sumQry = "SELECT SUM(CASE StatusID WHEN 1 THEN Quantity END) YetToMix, SUM(CASE StatusID WHEN 2 THEN Quantity END) InProgress FROM ".APP."txnmetadata WHERE WorkOrderID = ".$_REQUEST['woid']." AND StatusID = ".INPROGRESS;
	
	$woid = $_REQUEST['woid'];
	$userid = $_SESSION['UserID'];
	//$mysqli->next_result();
	$taskQry = "SELECT ms.ID MetadataStageID, wo.ProductID, p.ProductName ProductName, wo.ID WorkOrderID, wo.Code WorkOrderCode, ms.StageID, s.StageName, IF(ms.StatusID = ".COMPLETED.", ms.PendingQuantity, IF(ms.PendingQuantity = 0, ms.InputQuantity, ms.PendingQuantity)) Pieces, st.Description CurrentStatus, NULL JobOwner, NULL AssignTo, ms.RejectedQuantity, ms.StatusID FROM ".APP."txnworkorder wo JOIN ".APP."txnmetadatastage ms ON ms.WorkOrderID = wo.ID JOIN ".APP."mstrproduct p ON p.ID = wo.ProductID JOIN ".APP."lustage s ON s.ID = ms.StageID JOIN ".APP."lustatus st ON st.ID = ms.StatusID WHERE wo.ID = ".$woid." AND wo.StatusID = ".INPROGRESS." AND ms.PendingQuantity > 0 ORDER BY ms.Sequence ASC";
	//echo $taskQry;
	$taskList = mysql_query($taskQry);
	$taskcnt = mysql_num_rows($taskList);
	//echo $taskcnt;
	if($taskcnt > 0)
	{
	?>
	<tr>
	<td colspan="2"><input type="submit" name="productionEntry" id="productionEntry" disabled="disabled" value="Production Entry" /></td>
	</tr>
	<?php
	}	
?>

<tr>
<td colspan="2">
	<table cellspacing="0" cellpadding="5" border="0" width="100%" id="workflowtable" style="cellspacing:25%;">
	<thead>
	<tr>
		<th width="2%">&nbsp;</th>
		<th width="12%">Component</th>
		<th width="11%">Work Order Code</th>
		<th width="11%">Quantity</th>
		<th width="11%">Rejected Qty</th>
		<th width="15%">Current Position</th>
		<th width="13%">Status</th>
	</tr>
	</thead>
	
	<?php
		
		//echo $sumQry;
		//$sumRS = mysql_fetch_array(mysql_query($sumQry));
	?>
	
	<tbody>
	<?php

	
		while($woList = mysql_fetch_array($taskList))
		{
	?>
		<tr>
		<td><?php if(($woList['StatusID'] != COMPLETED) && ($woList['StatusID'] != NEWACTIVITY)) { ?><input type="radio" id="taskcheck<?php echo $woList['MetadataStageID']; ?>" name="taskcheck" value="<?php echo $woList['MetadataStageID']; ?>" onClick="checkboxvalidate('<?php echo $woList['MetadataStageID']; ?>')"/><?php } ?></td>
		<td><?php echo $woList['ProductName']; ?></td>
		<td><?php echo $woList['WorkOrderCode']; ?></td>
		<td><?php echo $woList['Pieces']; ?></td>
		<td><?php echo $woList['RejectedQuantity']; ?></td>
		<td><?php echo $woList['StageName']; ?></td>
		<td><?php echo $woList['CurrentStatus']; ?></td>
		</tr>
	<?php
		}
		
		if($taskcnt == 0)
		{
		?>
		<tr>
		<td colspan="7" style="text-align:center;">No row(s) found</td>
		</tr
		<?php
		}
	?>
	</tbody>
	</table>
</td>
</tr>
	<?php
	}
	?>
</table>
</form>
</div>
<!-- Dashlet-Panel Ends -->
<?php include('footer.php'); ?> 
</div>