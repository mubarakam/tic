<?php
 include('meta_script_link.php');
?><head>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery('#bottleall').click(function() {
    if(this.checked) {
        jQuery('input:checkbox').attr('checked', 'checked');		
        jQuery('#example > tbody ').find('input:checkbox').closest('tr').css('background-color', '#AFDCEC');
    }
    else {
        jQuery('input:checkbox').removeAttr('checked');
		jQuery('select').removeAttr('required');
		jQuery('select').removeAttr('class','');
		 jQuery('#example > tbody > tr').css('background-color', '');
    }
});

jQuery(document).ready(function(){
	document.getElementById("finishedQty").focus();
	});


function getPendingQty()
{
	var pendingQty = document.getElementById('woQty').value - document.getElementById('finishedQty').value;
	document.getElementById('pendingQty').value = pendingQty;
	
	if(pendingQty < 0)
	{
		alert('Finished Quantity exceeds the actual quantity');
		document.getElementById('finishedQty').value = '';
		document.getElementById('pendingQty').value = '';
		return false;
	}
}

</script>
<div class="main-container">
<?php include('includes/header.php');
?>
<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="">Pre-Production</a>&nbsp;&raquo;&nbsp;Weighing</div>
<div class="backlink"><a href="vwWeighing.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
	<div id="dashlet-panel" class="dashlet-panel-full">
 <?php
 $woQry = mysql_fetch_array(mysql_query("SELECT wo.ID, wo.Code, wo.ProductID, p.ProductName, wo.Quantity, wo.Pieces, wo.WorkflowID, w.WorkflowName, (wo.Quantity - wo.QuantityFinished) ActualPending, wo.QuantityFinished ActualFinishedQty, BottleWeight FROM ".APP."txnworkorder wo JOIN ".APP."mstrproduct p ON p.ID = wo.ProductID JOIN ".APP."luworkflow w ON w.ID = wo.WorkflowID WHERE wo.ID = ".$_REQUEST['woid'])) or die(mysql_error());

 if($_REQUEST['mode'] == 'edit')
 {
?>
<form name="workorderSetting" action="mdlWeighing.php?mode=edit" method="post" id="workorderSetting" >
<table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="25%">Work Order Code</td>
    <td width="25%"><?php echo $woQry['Code']; ?></td>
	<td width="25%">Product Name</td>
    <td width="25%"><?php echo $woQry['ProductName']; ?>
	<input type="hidden" id="productid" name="productid" value="<?php echo $woQry['ProductID']; ?>" />
	<input type="hidden" id="bottleweight" name="bottleweight" value="<?php echo $woQry['BottleWeight']; ?>" />
	</td>
    </tr>
    <tr>
    <td>Quantity</td>
    <td><?php echo $woQry['ActualPending']; ?>&nbsp;Bottle(s)</td>
	<input type="hidden" id="woQty" name="woQty" value="<?php echo $woQry['ActualPending']; ?>"/>
	<input type="hidden" id="ActualPending" name="ActualPending" value="<?php echo $woQry['ActualPending']; ?>"/>
	<input type="hidden" id="ActualFinishedQty" name="ActualFinishedQty" value="<?php echo $woQry['ActualFinishedQty']; ?>"/>
	
	
    <td>Piece(s)/Bottle</td>
    <td><?php echo $woQry['Pieces']; ?></td>
	<input type="hidden" id="woPieces" name="woPieces" value="<?php echo $woQry['Pieces']; ?>"/>
	</tr>
 </tr>
  <tr>
   <td>Production Flow</td>
   <td colspan="3">
   <input type="hidden" id="pfselect" name="pfselect" value="<?php echo $woQry['WorkflowID']; ?>" />
   <input type="hidden" id="workorderid" name="workorderid" value="<?php echo $_REQUEST['woid']; ?>" />
   <?php
   echo $woQry['WorkflowName'];
   ?>
   </td>
  </tr>
  <tr>
  <td>Finished Bottle(s)</td>
  <td><input type="number" id="finishedQty" name="finishedQty" onChange="getPendingQty()" required onkeypress="return isNumberKey(event)" />
  <td>Pending Bottle(s)</td>
  <td><input type="text" id="pendingQty" name="pendingQty" readonly />
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addworkorder" value="Submit" id="addworkorder""/>
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>

  </table>
</form>
<?php
 }
 
 
if($_REQUEST['mode'] == 'set')
{
?>
	<form name="workorderSetting" action="mdlWorkOrder.php?mode=set" method="post" id="workorderSetting" >

<table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="14%">Work Order Code</td>
    <td colspan="3">
      <?php echo $woQry['Code']; ?>
    </td>
    </tr>
  <tr>
    <td>Product Name</td>
    <td colspan="3">
	<?php echo $woQry['ProductName']; ?>
    </td>
    </tr>
    <tr>
    <td>Quantity</td>
    <td colspan="3">
	<?php echo $woQry['Quantity']; ?>&nbsp;Bottle(s)
    </td>
  </tr>
 </tr>
    <tr>
    <td>Piece(s)/Bottle<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td colspan="3">
	<?php echo $woQry['Pieces']; ?>
    </td>
  </tr>
  <tr>
   <td>Production Flow</td>
   <td colspan="3">
   <?php
   //echo "SELECT p.WorkFlowID, wf.WorkflowName FROM mstrproduct p JOIN luworkflow wf ON wf.ID = p.WorkFlowID WHERE p.ID = ".$_REQUEST['prdid'];
   $pfrs = mysql_fetch_array(mysql_query("SELECT p.WorkFlowID, wf.WorkflowName FROM ".APP."mstrproduct p JOIN ".APP."luworkflow wf ON wf.ID = p.WorkFlowID WHERE p.ID = ".$woQry['ProductID'])) or die(mysql_error());
   ?>
   <input type="hidden" id="pfselect" name="pfselect" value="<?php echo $pfrs['WorkFlowID']; ?>" />
   <input type="hidden" id="workorderid" name="workorderid" value="<?php echo $_REQUEST['woid']; ?>" />
   <input type="hidden" id="productid" name="productid" value="<?php echo $woQry['ProductID']; ?>" />
   <?php
   echo $pfrs['WorkflowName'];
   ?>
   </td>
  </tr>
 	<tr>
	<td style="text-align:center;">Stage</td>
	<td align="center">Machine</td>
	<td colspan="2" align="center">Setting</td>
	</tr>
<?php

	$woStageQry = "SELECT DISTINCT wos.StageID, s.StageName, wos.WorkflowID ID, wos.MachineID, m.MachineName FROM ".APP."txnworkordersetting wos JOIN ".APP."lustage s ON s.ID = wos.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wos.MachineID WHERE wos.WorkflowID = ".$woQry['WorkFlowID'];
	$pfStageQry = "SELECT ws.StageID, s.StageName, w.ID, wsm.MachineID, m.MachineName FROM ".APP."luworkflow w JOIN ".APP."txnworkflowstage ws ON ws.WorkFlowID = w.ID LEFT OUTER JOIN ".APP."txnworkflowstagemachine wsm ON wsm.WorkflowID = w.ID AND wsm.StageID = ws.StageID JOIN ".APP."lustage s ON s.ID = ws.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = wsm.MachineID WHERE w.ID = ".$woQry['WorkFlowID']." ORDER BY ws.StageSequence ASC";

	if(mysql_num_rows(mysql_query($woStageQry)) > 0)
	{
		$pfStage = mysql_query($woStageQry) or die(mysql_error());
	}
	else
	{
		$pfStage = mysql_query($pfStageQry) or die(mysql_error());
	}

	while($pfStagers = mysql_fetch_array($pfStage))
	{
		
?>
<tr>
	<td align="center"><input class ="sbox2" type='hidden' name='pfStageID[]' id='pfStageID<?php echo $pfStagers['StageID']; ?>' value='<?php echo $pfStagers['StageID']; ?>' ><?php echo $pfStagers['StageName']; ?></td>
	<td><select id="machine" name="machine[]"><option value="" >--Select--</option>
	<?php
		$machine = mysql_query("SELECT ID, CONCAT(Code, ' - ', MachineName) Machine FROM ".APP."lumachine WHERE IsActive = 1 ORDER BY CONCAT(Code, ' - ', MachineName) ASC") or die(mysql_error());
		while($machiners = mysql_fetch_array($machine))
		{
			?>
			<option value="<?php echo $machiners['ID']; ?>" <?php if($machiners['ID'] == $pfStagers['MachineID']) {?> selected <?php } ?> ><?php echo $machiners['Machine']; ?></option>
			<?php
		}
	?></select>
	</td>
	<td colspan="2"><a href="javascript:addTemp(<?php echo $pfStagers['StageID']; ?>+'temperature')" id="Temperature" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Temperature" src="images/temperature.png"/></a>

	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>temperature">
	<tbody>
	<?php
	
	$woTemperatureQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = 1 OR wos.AttributeID IS NULL)";
	
	$pfTemperatureQry = "SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 1";
	
	if(mysql_num_rows(mysql_query($woTemperatureQry)) > 0)
	{
		$woTemperature = mysql_query($woTemperatureQry) or die(mysql_error());
	}
	else
	{
		$woTemperature = mysql_query($pfTemperatureQry) or die(mysql_error());
	}

	while($temperaturers = mysql_fetch_array($woTemperature))
	{
		if($temperaturers['Value']) {
	?>
	<span><input type="text"  name="<?php echo $temperaturers['StageID']; ?>temperature[]" id="<?php echo $temperaturers['StageID'];?>temperature" value="<?php echo $temperaturers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	}
	?>	
	
	</tbody>
	</table>
	&nbsp;
	<a href="javascript:addPress(<?php echo $pfStagers['StageID']; ?>+'pressure')" id="Pressure" style="float:left;margin:0 0 5px 12px;color:#4E9ACF;font-weight:bold;display:block;"><img title="Pressure" src="images/pressure.png" width="16px" height="16px"/></a>
	<table width="100%" border="0" id="workflowtable<?php echo $pfStagers['StageID']; ?>" class="example<?php echo $pfStagers['StageID']; ?>pressure">
	<tbody>
	<?php

	$woPressureQry = "SELECT wos.StageID, wos.AttributeID, wos.Value FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ".$_REQUEST['woid']." AND wos.StageID = ".$pfStagers['StageID']." AND (wos.AttributeID = 2 OR wos.AttributeID IS NULL)";
	
	$pfPressureQry = "SELECT wsm.StageID, wattr.AttributeID, wattr.Value FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.StageID = ".$pfStagers['StageID']." AND wsm.WorkFlowID = ".$pfStagers['ID']." AND wattr.AttributeID = 2";
	
	if(mysql_num_rows(mysql_query($woPressureQry)) > 0)
	{
		$woPressure = mysql_query($woPressureQry) or die(mysql_error());
	}
	else
	{
		$woPressure = mysql_query($pfPressureQry) or die(mysql_error());
	}
	
	while($pressurers = mysql_fetch_array($woPressure))
	{
		if($pressurers['Value'])
		{
	?>
	<span><input type="text"  name="<?php echo $pressurers['StageID']; ?>pressure[]" id="<?php echo $pressurers['StageID'];?>pressure" value="<?php echo $pressurers['Value'];?>" size="5"/>&nbsp;
<a alt="Delete" title="Delete" style="cursor:pointer" onclick="javascript:if(confirm('Are you sure you want to delete?')){$(this).closest('span').remove();chapDel();return true;}return false;">X</a></span>&nbsp;&nbsp;
<?php
	}
	}
	?>	
	
	
	</tbody>
	</table>&nbsp;
	
	</td>
	<input class ="sbox2" type='hidden' name='pfWorkflowID' id='pfWorkflowID' value='<?php echo $pfStagers['ID']; ?>' >
	
</tr>
<?php
	}

?>

  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
      <input type="submit" class="stage" name="addstage" value="Submit" id="addstage" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }
?>	
	</div>
</div>
<?php include('footer.php'); ?>
</div>
</body>
</html>