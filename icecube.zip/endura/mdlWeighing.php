<?php session_start();
ob_start();
include("config.php");
echo "<pre>";
print_r($_REQUEST);
print_r($_SESSION);
$userid = $_SESSION['UserID'];
$finishedQty = $_REQUEST['finishedQty'];
$productid = $_REQUEST['productid'];
$workorderid = $_REQUEST['workorderid'];
$pieces = $_REQUEST['woPieces'];
$ActualFinishedQty = $_REQUEST['ActualFinishedQty'];
$bottleweight = $_REQUEST['bottleweight'];

//echo "UPDATE txnworkorder SET QuantityFinished = ".$_REQUEST['finishedQty'].", LastModBy = ".$userid.", LastModOn = NOW() WHERE ID = ".$workorderid;

$updateWO = mysql_query("UPDATE ".APP."txnworkorder SET StatusID = ".INPROGRESS.", QuantityFinished = QuantityFinished + ".$finishedQty.", LastModBy = ".$userid.", LastModOn = NOW() WHERE ID = ".$workorderid) or die(mysql_error());

//$insTimeSheet = mysql_query("INSERT INTO txntimesheet (ProductID, WorkOrderID, StageID, StatusID, DoneBy, Quantity) VALUES (".$productid.", ".$workorderid.", ".WEIGHING.", 3, ".$userid.", ".$finishedQty.")");
//if($updateWO && $insTimeSheet)
if($updateWO)
{
	for($b = 1;$b <= $finishedQty;$b++)
	{
		echo "INSERT INTO ".APP."txnmetadata (ProductID, WorkOrderID, Metadata, Quantity, CreatedBy, CreatedOn, LastModBy, LastModOn, StageID, StatusID) VALUES (".$productid.", ".$workorderid.", 'Bottle-".($ActualFinishedQty + $b)."', ".$pieces.", ".$userid.", NOW(), ".$userid.", NOW(), ".MIXING.", ".OPEN.")";
		$insMetadata = mysql_query("INSERT INTO ".APP."txnmetadata (ProductID, WorkOrderID, Metadata, Quantity, CreatedBy, CreatedOn, LastModBy, LastModOn, StageID, StatusID, BottleWeight) VALUES (".$productid.", ".$workorderid.", 'Bottle-".($ActualFinishedQty + $b)."', ".$pieces.", ".$userid.", NOW(), ".$userid.", NOW(), ".MIXING.", ".OPEN.", ".$bottleweight.")") or die(mysql_error());
		
		if(!$insMetadata)
		{
			header('location:ctrlWeighing.php?mode=edit&woid='.$workorderid);
		}
	}
	header('location:vwWeighing.php');
}
else
{
	header('location:ctrlWeighing.php?mode=edit&woid='.$workorderid);
}

?>