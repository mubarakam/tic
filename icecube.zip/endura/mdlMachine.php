<?php session_start();
ob_start();
include("config.php");
include("includes/classes/machineClass.php");

$machineCode = $_REQUEST['Machinecode'];
$machineName = $_REQUEST['Machinename'];
$machineDesc = $_REQUEST['description'];
$machineId = $_REQUEST['sid'];

$machine = new machineClass();

if($_REQUEST['mode'] == 'add')
{
	$machine->addMachine($machineCode, $machineName, $machineDesc);
}

if($_REQUEST['mode'] == 'edit')
{
	$machine->updateMachine($machineId, $machineName, $machineDesc);
}

if($_REQUEST['mode'] == 'del')
{
	$machine->deleteMachine($machineId);
}
?>