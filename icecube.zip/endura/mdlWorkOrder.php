<?php session_start();
ob_start();
include("config.php");
include("includes/classes/workOrderClass.php");
echo "<pre>";
print_r($_REQUEST);

$workordercode = $_REQUEST['workordercode'];
$productid = $_REQUEST['product'];
$woquantity = $_REQUEST['woquantity'];
$pfselect = $_REQUEST['pfselect'];
$stdselect = $_REQUEST['stdselect'];
$workorderid = $_REQUEST['workorderid'];
$pfStageID = $_REQUEST['pfStageID'];
$machine = $_REQUEST['machine'];
$wopieces = $_REQUEST['wopieces'];
$woduedate = date('Y-m-d', strtotime($_REQUEST['woduedate']));
$woid = $_REQUEST['workorderid'];
$userid = $_SESSION['UserID'];

$workOrder = new workOrderClass();

if($_REQUEST['mode'] == "add")
{
	$workOrder->addWorkOrder($workordercode, $productid, $woquantity, $pfselect, $wopieces, $stdselect, $woduedate);
}

if($_REQUEST['mode'] == "edit")
{
	$workOrder->updateWorkOrder($woid, $wopieces, $woquantity, $userid, $woduedate);
}

if($_REQUEST['mode'] == 'set')
{
	$delWOAttribute = mysql_query("DELETE FROM ".APP."txnworkordersetting WHERE WorkOrderID = ".$workorderid) or die(mysql_error());
	$delWOTarget = mysql_query("DELETE FROM ".APP."txnworkordertarget WHERE WorkOrderID = ".$workorderid) or die(mysql_error());
	
	if($delWOAttribute && $delWOTarget)
	{
		for($i = 0;$i < count($pfStageID);$i++)
		{
			$temperature = $_REQUEST[$pfStageID[$i].$machine[$i]."temperature"];
			$pressure = $_REQUEST[$pfStageID[$i].$machine[$i]."pressure"];
			$time = $_REQUEST[$pfStageID[$i].$machine[$i]."time"];
			$weight = $_REQUEST[$pfStageID[$i].$machine[$i]."weight"];
			$density = $_REQUEST[$pfStageID[$i].$machine[$i]."density"];
			$hardness = $_REQUEST[$pfStageID[$i].$machine[$i]."hardness"];
			$target = $_REQUEST[$pfStageID[$i].$machine[$i]."target"];
			$workOrder->updateWorkOrderSetting($workorderid, $pfselect, $pfStageID[$i], $machine[$i], $temperature, $pressure, $productid, $time, $weight, $density, $hardness, $i, $target);
		}
		//mysql_query("COMMIT");
		$_SESSION['prcmsg'] = 'ss';
		header("location:vwWorkOrder.php");
	}
	else
	{
		header("location:ctrlWorkOrder.php?mode=set&woid=".$workorderid);
	}
//	$productionFlow->machineSetting($pfWorkflowID, $pfStageID, $machine);
}

?>