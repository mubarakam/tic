<?php
include('meta_script_link.php');?>
<div class="main-container">
	<?php include('includes/header.php');?>
<!-- Bread-Crumb Starts -->
<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Product</div>
	<div class="msg_wrap">
    <?php 
   if($_SESSION['prcmsg'] == 'dones')
        {?>
        <div class="msg_success">
           Product Created Successfully !!
        </div>
	<?php }	
        if($_SESSION['prcmsg'] == 'donef')
        {?>
        <div class="msg_error">
            Product Creation Failed !!
        </div>
       	<?php }
		if($_SESSION['prcmsg'] == 'upds')
        {?>
        <div class="msg_success">
           Product Updated Successfully !!
        </div>
		<?php }	
		if($_SESSION['prcmsg'] == 'ds')
        {?>
        <div class="msg_success">
           Product deleted Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'ss')
        {?>
        <div class="msg_success">
           Setting updated Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'sf')
        {?>
        <div class="msg_success">
           Setting updation failed !!
        </div>
        <?php } ?>


        </div>
    
    <div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>

<div class="clear"></div>
<!-- Bread-Crumb Ends -->
        <div class="dashlet-panel-full">

                <div class="backlink">
						<?php
						if($_REQUEST['mode'] == 'ci')
						{
						?>
						<a href="ctrlProduct.php?mode=addci"><img src="images/new.png" title="Add Parent" border="0" />&nbsp;Component</a>
						<?php
						}
						else
						{
						?>
						<a href="ctrlProduct.php?mode=addpar"><img src="images/new.png" title="Add Parent" border="0" />&nbsp;New Parent</a>
						<?php
						}
						?>				
                    
                </div> 
        <div class="clear"></div>
   			<div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; left: 0px; top: 0px;">				
					<div class="ui-widget-header ui-corner-top">
						<h2 class="arial12-nrml-medium-dark-gry">
						<?php
						if($_REQUEST['mode'] == 'ci')
						{
						?>
						Component
						<?php
						}
						else
						{
						?>
						Parent Item
						<?php
						}
						?>
						</h2>						
					</div>	
						 <!--<form name="listUser" action="" method="post" >	-->						
							<table cellspacing="0" cellpadding="0" border="0" width="100%" class="display" id="example">
								<thead>
									<tr>
										<th>Code</th>
										<th>Parent Item</th>
										<?php
										if($_REQUEST['mode'] == 'ci') {
										?>
										<th>Component</th>
										<th>Process Flow</th>
										<th>Std. Setting</th>
										<th>Diamond</th>
										<th>Bond</th>
										<th>Bottle Weight</th>
										<?php } ?>
										<th>Active</th>
										<th>Action</th>															
									</tr>
								</thead>                                                    
								<tbody>
								<?php
								
								$parentqry = "SELECT prj.ID, prj.Code, prj.ProductName, if(prj.IsActive = 1, 'Yes', 'No') as active FROM ".APP."mstrproduct prj WHERE prj.IsParent = 1 ORDER BY prj.IsActive DESC, prj.ProductName ASC";
								
								$childqry = "SELECT ci.ID, ci.Code, p.ProductName Parent, ci.ProductName Component, wf.WorkflowName, if(ci.IsActive = 1, 'Yes', 'No') as active, d.Description Diamond, b.Description Bond, ci.BottleWeight, s.Name StandardName FROM ".APP."mstrproduct ci JOIN ".APP."mstrproduct p ON ci.ParentID = p.ID JOIN ".APP."luworkflow wf ON wf.ID = ci.WorkFlowID LEFT OUTER JOIN ".APP."ludiamond d ON d.ID = ci.DiamondID LEFT OUTER JOIN ".APP."lubond b ON b.ID = ci.BondID LEFT OUTER JOIN ".APP."mstrstandard s ON s.ID = ci.StandardID WHERE ci.IsParent = 0 ORDER BY ci.IsActive DESC, ci.ProductName ASC";
								//echo $childqry;
								if($_REQUEST['mode'] == 'ci')
								{
									$getProductList = mysql_query($childqry);
								}
								else
								{
									$getProductList = mysql_query($parentqry);
								}
								while($rs = mysql_fetch_array($getProductList)){
									?>
									<tr>
										<td align="center"><?php echo $rs['Code']; ?></td>
                                        <td><?php if($_REQUEST['mode'] == 'ci') { echo $rs['Parent']; } else { echo $rs['ProductName']; } ?></td>
										<?php
										if($_REQUEST['mode'] == 'ci') {
										?>
										<td><?php echo $rs['Component']; ?></td>
										<td><?php echo $rs['WorkflowName']; ?></td>
										<td><?php echo $rs['StandardName']; ?></td>
										<td><?php echo $rs['Diamond']; ?></td>
										<td><?php echo $rs['Bond']; ?></td>
										<td><?php echo $rs['BottleWeight']; ?></td>
										<?php } ?>
										<td align="center"><?php echo $rs['active']; ?></td>
										<td style="font-weight:bold" align="center" width="10%">
                                        <?php
										if($_REQUEST['mode'] == 'ci') {
										?>
										<a href="ctrlProduct.php?mode=editci&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a>&nbsp;
										<?php
										}
										else
										{
										?>
										<a href="ctrlProduct.php?mode=editpar&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a>
										<?php
										}
										?>
										
                                        <a onclick="javascript:if(confirm('Are you sure you want to delete?')){return true;}return false;" href="mdlProduct.php?mode=del&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/del.png" title="Delete" border="0" /> </a>
										</td>															
									</tr>									
								<?php $i++; } ?>								
								</tbody>
							</table>
												
			</div>
   </div>
   
   <!-- Dashlet-Panel Ends -->	
   <?php include('footer.php'); ?> 
</div>