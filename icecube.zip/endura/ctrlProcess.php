<?php
 include('meta_script_link.php');
?><head>
<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>
<script type="text/javascript">

	//Machine selection
	$(function() {
            $("#right, #left").click(function(event) {
            var id = $(event.target).attr("id");
			var selectFrom = id == "right" ? "#sbox1" : "#selectedMachine";
			var moveTo = id == "right" ? "#selectedMachine" : "#sbox1";
			
			var selectedItems = $(selectFrom + " :selected").toArray();
			$(moveTo).append(selectedItems);
			selectedItems.remove;
			
			var myOpts = new Array();
			myOpts  = document.getElementById('selectedMachine').options;
			
			var select_box_length = myOpts.length;

			var  str_val = "";
			for(var i=0; i<myOpts.length; i++)
			{
				if(i == 0)
					str_val += myOpts[i].value;
				else
					str_val += ","+myOpts[i].value;
			}
			
			$(".selectedMachineValue").val(str_val);
			$(".t1").val(str_val);
		});
	});
	
	//Role
	$(function() {
            $("#roleright, #roleleft").click(function(event) {
            var roleid = $(event.target).attr("id");
			var roleselectFrom = roleid == "roleright" ? "#availableRole" : "#selectedRole";
			var rolemoveTo = roleid == "roleright" ? "#selectedRole" : "#availableRole";
			
			var roleselectedItems = $(roleselectFrom + " :selected").toArray();
			$(rolemoveTo).append(roleselectedItems);
			roleselectedItems.remove;
			
			var rolemyOpts = new Array();
			rolemyOpts  = document.getElementById('selectedRole').options;
			var roleselect_box_length = rolemyOpts.length;

			var  rolestr_val = "";
			for(var i=0; i<rolemyOpts.length; i++)
			{
				if(i == 0)
					rolestr_val += rolemyOpts[i].value;
				else
					rolestr_val += ","+rolemyOpts[i].value;
			}
			$(".selectedRoleValue").val(rolestr_val);
			//$(".t1").val(rolestr_val);
		});
	});



function listbox_move(listID, direction) {

    var listbox = document.getElementById(listID);
    var selIndex = listbox.selectedIndex;

    if(-1 == selIndex) {
        alert("Please select an option to move.");
        return;
    }
 
    var increment = -1;
    if(direction == 'up')
        increment = -1;
    else
        increment = 1;
 
    if((selIndex + increment) < 0 ||
        (selIndex + increment) > (listbox.options.length-1)) {
        return;
    }
 
    var selValue = listbox.options[selIndex].value;
    var selText = listbox.options[selIndex].text;
    listbox.options[selIndex].value = listbox.options[selIndex + increment].value
    listbox.options[selIndex].text = listbox.options[selIndex + increment].text
    	
		
    listbox.options[selIndex + increment].value = selValue;
    listbox.options[selIndex + increment].text = selText;
 
    listbox.selectedIndex = selIndex + increment;
	
	var myOpts = new Array();	
				myOpts  = document.getElementById('selectedMachine').options;
				//alert(myOpts[0].value+"length = "+myOpts.length); 
				
				var select_box_length = myOpts.length;
				var  str_val = "";
				for(var i=0; i<myOpts.length; i++) {
					
					if(i == 0)
						str_val += myOpts[i].value;
					else
						str_val += ","+myOpts[i].value;
				}
				
				//alert(str_val);	
				$(".selectedMachineValue").val(str_val); 
				$(".t1").val(str_val);
				

	
}

function listbox_move_edit(listID, direction) {

    var listbox = document.getElementById(listID);
    var selIndex = listbox.selectedIndex;

    if(-1 == selIndex) {
        alert("Please select an option to move.");
        return;
    }
 
    var increment = -1;
    if(direction == 'up')
        increment = -1;
    else
        increment = 1;
 
    if((selIndex + increment) < 0 ||
        (selIndex + increment) > (listbox.options.length-1)) {
        return;
    }
 
    var selValue = listbox.options[selIndex].value;
    var selText = listbox.options[selIndex].text;
    listbox.options[selIndex].value = listbox.options[selIndex + increment].value
    listbox.options[selIndex].text = listbox.options[selIndex + increment].text
    	
		
    listbox.options[selIndex + increment].value = selValue;
    listbox.options[selIndex + increment].text = selText;
 
    listbox.selectedIndex = selIndex + increment;
	
	var myOpts = new Array();	
				myOpts  = document.getElementById('sbox4').options;
				//alert(myOpts[0].value+"length = "+myOpts.length); 
				
				var select_box_length = myOpts.length;
				var  str_val = "";
				for(var i=0; i<myOpts.length; i++) {
					
					if(i == 0)
						str_val += myOpts[i].value;
					else
						str_val += ","+myOpts[i].value;
				}
				
				//alert(str_val);	
				$(".sbox4").val(str_val); 
				$(".t1").val(str_val);
}
function validate(a){var val = $("#"+a).val();$.ajax({type: "post",url: "ajaxValidate.php?frm="+a+"&val="+val,success: function(data){if(data == "exist"){$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});document.getElementById('errdiv').style.display='inline';$("#addbtn").attr('disabled','true')}else if(data != "exist"){$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});document.getElementById('errdiv').style.display='none';$("#addbtn").removeAttr('disabled');}}});}
</script>

<div class="main-container">
<?php include('includes/header.php');


####### Need to declare########
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Process</div>
<div class="msg_wrap">
<?php 
   if($_REQUEST['msg']=='done')
        {?>
        <div class="msg_success">
           Workflow Created Successfully !!
        </div>
	<?php }	
        if($_REQUEST['msg']=='fail')
        {?>
        <div class="msg_error">
            Workflow Creation Failed !!
        </div>
       	<?php } ?></div>
<div class="backlink">
                 <a href="vwProcess.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
   		 <div id="dashlet-panel" class="dashlet-panel-full">
         <div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; padding-bottom: 5px;">	
  		
                 <div style="padding:10px;">

 <?php
if($_REQUEST['mode'] == 'add')
{
   $wcode = mysql_query("SELECT CONCAT(`CODE`,`CurrentRange` + 1) as code from ".APP."cfgdocumenttype where `ObjectTypeId` = 3") or die(mysql_error());
   $code = mysql_fetch_array($wcode); ?>					
                    <form name="processform" action="mdlProcess.php?mode=add" method="post" id="stageform" >
                        
                        <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Process Code</td>
    <td colspan="3">
      <input style="width:60px;"  type="text"  maxlength="255" name="processcode" value="<?php echo $code['code']; ?>" readonly="readonly"/>
    </td>
    </tr>
  <tr>
    <td>Process Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;" type="text"  maxlength="255" name="processname" value="<?php $workflowName ?>" id="processname"  required onChange="validate('processname');"/>
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Process already exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
      <textarea name="description" cols="34" rows="3"></textarea>
      </td>
  </tr>
  <tr>
    <td>Select Machine<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td width="20%">
	<?php
	$machineListQry = "SELECT ID, MachineName FROM ".APP."lumachine WHERE IsActive = 1";
	$machineListExe = mysql_query($machineListQry) or die(mysql_error());
	?>
	<select id="sbox1" name="sbox1" size="10" style="width:210px; height:175px;"  multiple="multiple" >
	<?php
	while($row = mysql_fetch_array($machineListExe))
	{
	?>
	<option value='<?php echo $row['ID']; ?>'><?php echo $row['MachineName']; ?></option>
	<?php
	}
	?>
	</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" /></td>
    <td width="63%">
      <select id="selectedMachine" name="selectedMachine" size="10" style="width:210px; height:175px;" multiple="multiple">
      </select>
</td>
  </tr>
<!--
<tr>
<td>Select Role<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
<td width="20%">
<?php
$roleListQry = "SELECT ID, Description Name FROM lurole WHERE IsActive = 1";
$roleListExe = mysql_query($roleListQry)
?>
<select id="availableRole" name="availableRole" size="10" style="width:210px; height:175px;"  multiple="multiple">
<?php
while($row = mysql_fetch_array($roleListExe))
{
?>
<option value='<?php echo $row['ID']; ?>'><?php echo $row['Name']; ?></option>
<?php
}
?>
</select>
</td>
<td width="6%" align="center"><input id="roleright" style="width:50px;" type="button" size="10px" value=" >> " />
<br/>
<br/>
<input id="roleleft" style="width:50px;" type="button" value=" << " />
<br/>
<br/>
<input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " />
<br/>
<br/>
<input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" /></td>
<td width="63%">
<select required id="selectedRole" name="selectedRole" size="10" style="width:210px; height:175px;" multiple="multiple">
</select>
</td>
</tr>
-->

  <tr>
    <td>&nbsp;</td>
    <td colspan="3"><input type='hidden' name='selectedMachineValue' id='selectedMachineValue' class='selectedMachineValue' />
	<input type='hidden' name='selectedRoleValue' id='selectedRoleValue' class='selectedRoleValue' />
      <input type="submit" class="stage" name="addbtn" value="Submit" id="addbtn" />
      &nbsp;         <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
              
                         
				</form>
<?php			
 }
if($_REQUEST['mode'] == 'edit')
{
	$process = mysql_query("select `ID`, `Code`, `StageName`,`Description`, IsActive Active from ".APP."lustage where ID = ".$_REQUEST['sid']);
	$processrs = mysql_fetch_array($process);
?>
				<form name="processform" action="mdlProcess.php?mode=edit" method="post" id="processform" >
                
                
                <table width="100%" border="0" id="workflowtable">
  <tr>
    <td width="11%">Process Code</td>
    <td colspan="3">
      <input class="code" type="text"  maxlength="255" name="processcode" value="<?php echo $processrs['Code']; ?>" readonly="readonly"/><input type="hidden" name="sid" id="sid" value="<?php echo $processrs['ID']; ?>" >
    </td>
    </tr>
  <tr>
    <td>Process Name<span class="validationerrornotify">&nbsp;*</span></td>
    <td colspan="3">
      <input style="width:300px;maxlength:255;"  type="text" name="processname" value="<?php echo $processrs['StageName']; ?>" id="processname"  required onChange="validate('processname')" />
    <div id="errdiv" class="msg_exists" style="display:none;">&nbsp;Process already exists &nbsp;</div></td>
    </tr>
  <tr>
    <td>Description</td>
    <td colspan="3">
     <textarea name="description" cols="36" rows="3"><?php echo $processrs['Description']; ?></textarea>
      </td>
  </tr>
  <tr>
    <td>Select Machine<span class="validationerrornotify">&nbsp;*</span>&nbsp;</td>
    <td width="20%">
	<?php
	$machineListQry = "SELECT m.ID, m.MachineName FROM ".APP."lumachine m WHERE m.IsActive = 1 AND NOT EXISTS (SELECT 1 FROM ".APP."txnstagemachine sm WHERE sm.MachineID = m.ID AND sm.StageID = ".$_REQUEST['sid'].")";
	$machineListExe = mysql_query($machineListQry)
	?>
	<select id="sbox1" name="sbox1" size="10" style="width:210px; height:175px;"  multiple="multiple" >
	<?php
	while($row = mysql_fetch_array($machineListExe))
	{
	?>
	<option value='<?php echo $row['ID']; ?>'><?php echo $row['MachineName']; ?></option>
	<?php
	}
	?>
	</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" /></td>
<td width="63%">
<select id="selectedMachine" name="selectedMachine" size="10" style="width:210px; height:175px;" multiple="multiple">
<?php
$estage =mysql_query("SELECT m.ID, m.MachineName NAME FROM ".APP."lumachine m WHERE EXISTS (SELECT MachineID FROM ".APP."txnstagemachine sm WHERE sm.StageID = ".$_REQUEST['sid']." AND sm.MachineID = m.ID)");
while($srow = mysql_fetch_array($estage)){?>
<option value='<?php echo $srow['ID']; ?>'><?php echo $srow['NAME']; ?></option>
<?php }?>
</select>
</td>
  </tr>
  
  
  <tr>
    <td>Active</td>
    <td colspan="3">
	<select id="active" name="active">
	<option value="1" <?php if($processrs['Active'] == 1) {?>selected <?php } ?> >Yes</option>
	<option value="0" <?php if($processrs['Active'] == 0) {?>selected <?php } ?> >No</option>
	</select>
	</td>
</tr>
<!--
  <tr>
    <td>Select Role&nbsp;</td>
    <td width="20%">
   <select id="sbox1" name="sbox1" size="10" style="width:210px; height:200px;"  multiple="multiple">
									<?php
                                	$stageRole = mysql_query("SELECT r.ID, r.Description Role FROM lurole r WHERE r.IsActive = 1 AND NOT EXISTS (SELECT RoleID FROM txnstagerole sr WHERE sr.StageID = ".$_REQUEST['sid']." AND sr.RoleID = r.ID)");
                                	while($row = mysql_fetch_array($stageRole)){?>
                                	<option value='<?php echo $row['ID']; ?>'><?php echo $row['Role']; ?></option>
                        			<?php }?>
                         			</select>
    </td>
    <td width="6%" align="center"><input id="right" style="width:50px;" type="button" size="10px" value=" >> " />
      <br/>
      <br/>
      <input id="left" style="width:50px;" type="button" value=" << " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'up')" value="  UP " />
      <br/>
      <br/>
      <input type="button" style="width:50px;" onClick="listbox_move('sbox2', 'down')" value="Down" /></td>
    <td width="63%">
     <select required id="selectedRole" name="selectedRole" size="10" style="width:210px; height:200px;" multiple="multiple" >           
                                    <?php
                                	$estage =mysql_query("SELECT r.ID, r.Description NAME FROM lurole r WHERE EXISTS (SELECT RoleID FROM txnstagerole sr WHERE sr.StageID = ".$_REQUEST['sid']." AND sr.RoleID = r.ID)");
                                	while($srow = mysql_fetch_array($estage)){?>
                                	<option value='<?php echo $srow['ID']; ?>'><?php echo $srow['NAME']; ?></option>
                        			<?php }?>
                          			</select>
    </td>
  </tr>
  -->
  <tr>
    <td>&nbsp;</td>
    <td colspan="3">
	<input class ="selectedRoleValue" type='hidden' name='selectedRoleValue' id='selectedRoleValue' value='' >
	<input class ="selectedMachineValue" type='hidden' name='selectedMachineValue' id='selectedMachineValue' value='' >
      <input type="submit" class="stage" name="addstage" value="Submit" id="addstage" />
      &nbsp; 
        <input name="Cancel" type="button"  value="Cancel"/>
</td>
    </tr>
</table>
				</form> 
<?php
 }
?>
</div>
<?php include('includes/footer.php'); ?>
</div>
</body>
</html>