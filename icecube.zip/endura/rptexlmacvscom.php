<?php
include('config.php');
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2012 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2012 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);

date_default_timezone_set('Europe/London');

/** Include PHPExcel */
require_once 'includes/classes/PHPExcel.php';


// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);

$styleArray = array(
  'borders' => array(
    'allborders' => array(
      'style' => PHPExcel_Style_Border::BORDER_THIN
    )
  )
);

$objPHPExcel->getActiveSheet()->getStyle('A2:B3')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('A1:C1')->applyFromArray($styleArray);

$columnQry = mysql_query("SELECT DISTINCT sl.MachineID, CONCAT(m.Code, ' - ', m.MachineName) Machine
FROM ".APP."txnsettinglog sl
INNER JOIN ".APP."lumachine m ON m.ID = sl.MachineID
WHERE sl.CreatedOn BETWEEN DATE_SUB(NOW(), INTERVAL 1 MONTH) AND NOW()
ORDER BY 2 ASC") or die(mysql_error());

$machineid = array();
$machinename = array();
while($rs = mysql_fetch_array($columnQry))
{
	array_push($machineid, $rs['MachineID']);
	array_push($machinename, $rs['Machine']);
}

$excelColumn = array("G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1");
$excelDataColumn = array("C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG");
$row = 5;

$date = mysql_fetch_array(mysql_query("SELECT CAST(DATE_SUB(NOW(), INTERVAL 1 MONTH) AS DATE) fromdate, CAST(NOW() AS DATE) todate"));

$objPHPExcel->getActiveSheet()->mergeCells('A1:C1');
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->getStyle("A1")->getFont()->setBold(true);
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Component vs Machine')
            ->setCellValue('A2', 'From Date')
            ->setCellValue('A3', 'To Date')
			->setCellValue('B2', $date['fromdate'])
			->setCellValue('B3', $date['todate']);

$objPHPExcel->getActiveSheet()->getStyle("A".$row.":B".$row)->getFont()->setBold(true);
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, 'WO')
            ->setCellValue('B'.$row, 'Component');
$objPHPExcel->getActiveSheet()->getStyle('A'.$row)->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B'.$row)->applyFromArray($styleArray);

for($c=0;$c<COUNT($machineid);$c++)
{
	$objPHPExcel->getActiveSheet()->getColumnDimension($excelDataColumn[$c])->setWidth(15);
	$objPHPExcel->getActiveSheet()->getStyle($excelDataColumn[$c].$row)->getFont()->setBold(true);
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue($excelDataColumn[$c].$row, $machinename[$c]);
	$objPHPExcel->getActiveSheet()->getStyle($excelDataColumn[$c].$row)->applyFromArray($styleArray);	
}
$row = $row + 1;

$compwoqry = mysql_query("SELECT DISTINCT ms.ProductID, p.ProductName Component, GROUP_CONCAT(DISTINCT wo.Code) WOCode
FROM ".APP."txnsettinglog sl
INNER JOIN ".APP."txnmetadatastage ms ON ms.ID = sl.MetadataStageID
INNER JOIN ".APP."mstrproduct p ON p.ID = ms.ProductID
INNER JOIN ".APP."txnworkorder wo ON wo.ID = ms.WorkOrderID
WHERE sl.CreatedOn BETWEEN DATE_SUB(NOW(), INTERVAL 1 MONTH) AND NOW()
GROUP BY ms.ProductID, p.ProductName
ORDER BY 2 ASC");

while($compwors = mysql_fetch_array($compwoqry))
{
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, $compwors['WOCode'])
			->setCellValue('B'.$row, $compwors['Component']);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$row)->applyFromArray($styleArray);
	$objPHPExcel->getActiveSheet()->getStyle('B'.$row)->applyFromArray($styleArray);
	
	for($c=0;$c<COUNT($machineid);$c++)
	{
		$getValueQry = "SELECT msl.OutputQuantity
						FROM ".APP."txnsettinglog sl
						INNER JOIN ".APP."txnmetadatastage ms ON ms.ID = sl.MetadataStageID
						INNER JOIN ".APP."txnmetadatastagelog msl ON msl.MetadataStageID = ms.ID AND msl.ID = sl.MetadataStageLogID
						WHERE sl.CreatedOn BETWEEN DATE_SUB(NOW(), INTERVAL 1 MONTH) AND NOW()
						AND ms.ProductID = ".$compwors['ProductID']."
						AND sl.MachineID = ".$machineid[$c];
		$getValuers = mysql_fetch_array(mysql_query($getValueQry));
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue($excelDataColumn[$c].$row, $getValuers['OutputQuantity']);
		$objPHPExcel->getActiveSheet()->getStyle($excelDataColumn[$c].$row)->applyFromArray($styleArray);
	}
	$row++;
}
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle("ComponentVsMachine");

// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="ComponentVsMachine.xlsx"');
header('Cache-Control: max-age=0');
PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
