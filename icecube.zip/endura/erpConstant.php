<?php
////// NOTE: MENTION THE DEFINING NAME DETAILS CLEARLY IN A COMMENT, FOLLOW THE ABOVE FORMAT//////
define("WEIGHING", "42");   //Weighing Stage ID
define("MIXING", "43");   //Mixing Stage ID

define("OPEN", "1");   //Staus Open ID
define("INPROGRESS", "2");   //Staus inprogress ID
define("COMPLETED", "3");   //Staus Completed ID

define("NEWACTIVITY", "5");   //Staus newactivity ID
define("AVAILABLE", "4");   //Staus newactivity ID

define("TEMPERATURE", "1");   //Attribute TEMPERATURE ID
define("PRESSURE", "2");   //Attribute PRESSUERE ID
define("WEIGHT", "3");   //Attribute WEIGHT ID
define("TIME", "4");   //Attribute TIME ID
define("DENSITY", "5");   //Attribute DENSITY ID
define("HARDNESS", "6");   //Attribute HARDNESS ID

define("POCREATED", "6");   //PO Created
define("POCLOSED", "7");   //PO Closed
define("POHOLD", "8");   //PO Hold
define("POREJECTED", "9");   //PO Rejected
define("POAPPROVED", "10");   //PO Rejected

define("NULLVALUE", "NULL");
define("APP", "endura");
////// NOTE: MENTION THE DEFINING NAME DETAILS CLEARLY IN A COMMENT, FOLLOW THE ABOVE FORMAT//////
?>