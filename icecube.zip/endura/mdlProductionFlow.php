<?php session_start();
ob_start();
include("config.php");
include("includes/classes/productionFlowClass.php");
echo "<pre>";
print_r($_REQUEST);

$pfCode = $_REQUEST['ProductionFlowcode'];
$pfName = $_REQUEST['ProductionFlowname'];
$pfDesc = $_REQUEST['description'];
$pfMasterId = $_REQUEST['sid'];
$selectedValue = $_REQUEST['sbox_value'];
$pfStageID = $_REQUEST['pfStageID'];
$machine = $_REQUEST['machine'];
$pfWorkflowID = $_REQUEST['pfWorkflowID'];

$productionFlow = new productionFlowClass();

if($_REQUEST['mode'] == 'add')
{
	$productionFlow->addProductionFlow($pfCode, $pfName, $pfDesc, $selectedValue);
}

if($_REQUEST['mode'] == 'edit')
{
	$productionFlow->updateProductionFlow($pfMasterId, $pfName, $pfDesc, $selectedValue);
}

if($_REQUEST['mode'] == 'del')
{
	$productionFlow->deleteProductionFlow($pfMasterId);
}

if($_REQUEST['mode'] == 'set')
{
	//mysql_query("START TRANSACTION");
	$delpfAttribute = mysql_query("DELETE wattr FROM ".APP."txnworkflowstagemachine wsm JOIN ".APP."txnworkflowattributesetting wattr ON wattr.WorkflowStageMachineID = wsm.ID WHERE wsm.WorkFlowID = ".$pfWorkflowID) or die(mysql_error());
	$delpfStageMachine = mysql_query("DELETE FROM ".APP."txnworkflowstagemachine WHERE WorkflowID = ".$pfWorkflowID) or die(mysql_error());
	
	
	if($delpfStageMachine && $delpfAttribute)
	{
		for($i = 0;$i < count($pfStageID);$i++)
		{
			$temperature = $_REQUEST[$pfStageID[$i]."temperature"];
			$pressure = $_REQUEST[$pfStageID[$i]."pressure"];
			$time = $_REQUEST[$pfStageID[$i]."time"];
			$weight = $_REQUEST[$pfStageID[$i]."weight"];
			$density = $_REQUEST[$pfStageID[$i]."density"];
			$hardness = $_REQUEST[$pfStageID[$i]."hardness"];
			echo "mdl - ".$pfStageID[$i]."<br/>";
			echo "mdl - ".$machine[$i]."<br/>";
			$productionFlow->machineSetting($pfWorkflowID, $pfStageID[$i], $machine[$i], $temperature, $pressure, $time, $weight, $density, $hardness);
		}
		//mysql_query("COMMIT");
		$_SESSION['prcmsg'] = 'ss';
		header("location:vwProductionFlow.php");
	}
	else
	{
		header("location:ctrlProductionFlow.php?mode=set&sid=".$pfMasterId);
	}
//	$productionFlow->machineSetting($pfWorkflowID, $pfStageID, $machine);
}

?>