<?php
ob_start();
error_reporting(0);
include("erpConstant.php");
//Connection 2
/*
$hostname = "localhost";	//Host name of the Server
$username = "lwaijuvv_mes";	//User Name of the Server
$password = "XG?q{#Dz+8_5";	//Password of the Server
$dbname = "lwaijuvv_mes";	//Database Name of the server
*/
//Connection 3

$hostname = "localhost";	//Host name of the Server
$username = "crescentadmin";	//User Name of the Server
$password = "crescentadmin";	//Password of the Server
$dbname = "crescentems";	//Database Name of the server

$connect = mysql_connect("$hostname", "$username", "$password") or die("Unable to connect to Database server");
@mysql_select_db($dbname, $connect) or die("Unable to select database");
/*
$mysqli = new mysqli("$hostname", "$username", "$password", $dbname, 3306);

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
*/
/*
function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}
define('CURRENT_URL',curPageURL());
define('CURRENT_PAGE',basename(curPageURL()));
define('CURRENT_PAGE_ONLY',basename($_SERVER['SCRIPT_FILENAME'],".php"));
*/
 
?>