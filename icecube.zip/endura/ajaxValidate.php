<?php
session_start();
ob_start();
include('config.php');

if($_REQUEST['frm'] == 'Machinename')
{	
	$selqry = mysql_query("SELECT 1 FROM ".APP."lumachine WHERE MachineName = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'processname')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."lustage WHERE StageName = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'ProductionFlowname')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."luworkflow WHERE WorkflowName = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'standardname')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."mstrstandard WHERE Name = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'productcode')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."mstrproduct WHERE Code = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'productname')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."mstrproduct WHERE ProductName = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'contnum')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."luemployeedetail WHERE ContactNumber = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'itemname')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."luitem WHERE Name = '".$_REQUEST['val']."' AND ItemCategoryID = ".$_REQUEST['ic']) or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}

if($_REQUEST['frm'] == 'suppliername')
{
	$selqry = mysql_query("SELECT 1 FROM ".APP."mstrsupplier WHERE Name = '".$_REQUEST['val']."'") or die(mysql_error());
	if(mysql_num_rows($selqry) != 0)
	{
		echo "exist";
	}
}
?>