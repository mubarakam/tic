<?php
 include('meta_script_link.php');
?><head>
<link href="css/jquery.ui.all.css" rel="stylesheet"/>
<link href="css/jquery.ui.tabs.css" rel="stylesheet"/>
<link href="css/demos.css" rel="stylesheet"/>

<script src="js/jquery.ui.core.js"></script> 
<script src="js/jquery.ui.widget.js"></script> 
<script src="js/jquery.ui.tabs.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script type="text/javascript" src="script/jquery-ui.min.js"></script> 
<script type="text/javascript" src="script/jquery.multiselect.min.js"></script>

<script src="js/jquery.validate.js" type="text/javascript"></script>
<script src="script/erp.js" type="text/javascript"></script>

<script src="js/jquery.validate.js" type="text/javascript"></script>
<script type="text/javascript" src="script/jquery.chosen.min.js"></script>
<script type="text/javascript" src="script/jquery-ui.min.js"></script>
 <script type="text/javascript" src="js/jquery.blockUI.js"></script>
<script src="script/erp.js" type="text/javascript"></script>

<script type="text/javascript">
function testcall()
{
	alert('test');
		var startdate = $("#fromdate").val() + ' ' + $("#fromtime").val();
		//var enddate = $("#todate").val();
		var enddate = $("#todate").val() + ' ' + $("#totime").val();
		//var endtime = $("#totime").val();
		alert(startdate);
		//alert(starttime);
		alert(enddate);
		//alert(endtime);

		var cfd = Date.parse(startdate);
		var ctd = Date.parse(enddate);
		
		alert(cfd);
		alert(ctd);

		var date1 = new Date(cfd); 
		var date2 = new Date(ctd);

		if(date1 > date2) { 
			alert("FROM DATE SHOULD BE MORE THAN TO DATE");
		}
		
	}
function getToHour()
{
	var frmHr = document.getElementById('fromhour').value;
	
	if (window.XMLHttpRequest)
	{
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("tohour").innerHTML = xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","ajaxRequest.php?req=gettohr&frmhr="+frmHr, true);
	xmlhttp.send();
}
function getToMinute()
{
	var frmHr = document.getElementById('fromhour').value;
	var frmMin = document.getElementById('fromminute').value;
	if(frmHr)
	{
		if (window.XMLHttpRequest)
		{
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
		else
		{
			// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange=function(){
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
				document.getElementById("tominute").innerHTML = xmlhttp.responseText;
			}
		}
		xmlhttp.open("GET","ajaxRequest.php?req=gettomin&frmhr="+frmHr+"&frmmin="+frmMin, true);
		xmlhttp.send();
	}
	else
	{
		document.getElementById('fromminute').value = "";
		alert('Please select the Hour & proceed.');
		return false;
	}

}
function getSetting()
{
	var mid = document.getElementById('machine').value;
	var mdstgid = document.getElementById('mdstgid').value;
	window.location = "ctrlProdEntry.php?t=1&p="+mdstgid+"&mid="+mid;
}

function getPendingQty()
{
	var rejQty = document.getElementById('RejQty').value;
	var repQty = document.getElementById('RepQty').value;
	var outQty = document.getElementById('OutQty').value;
	var inQty = document.getElementById('InQty').value;
	var skipQty = document.getElementById('SkipQty').value;
	
	var promacid = document.getElementById('macid').value;
		
	if(promacid > 0)
	{
		var selmacID = document.getElementById('machine').value;
		if(!selmacID)
		{
			alert("Please select the Machine & proceed.");
			document.getElementById('OutQty').value = '';
			document.getElementById("machine").focus();
			return false;
		}
	}
	
		var pendingQty = inQty - outQty - rejQty - repQty - skipQty;
		document.getElementById('PenQty').value = pendingQty;
}

$(document).ready(function() {
	
	var customDateDDMMMYYYYToOrd = function (date) {
		"use strict"; //let's avoid tom-foolery in this function
		// Convert to a number YYYYMMDD which we can use to order
		var dateParts = date.split(/-/);
		if(dateParts[1] !== undefined){
		return (dateParts[2] * 10000) + ($.inArray(dateParts[1].toUpperCase(), ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]) * 100) + dateParts[0];
		}
	};
	
	$(".kpress").keypress(function (e)
	{
		e.preventDefault();
	});
	$("input[aria-controls=example]").focus();
	
	jQuery(function(){
                jQuery('#fromdate').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
					  jQuery( this ).datepicker('option','maxDate', jQuery('#endtime').val() );
						
                    }
                });
                jQuery('#todate').datepicker({
					dateFormat: 'dd-M-yy',
					changeMonth: true,
			changeYear: true,
                    beforeShow : function(){
                        jQuery( this ).datepicker('option','minDate', jQuery('#proddate').val() );
                    }
                });
            })
});

$(function(){

				$('#PEPopup').dialog({
                    autoOpen: false,
                    width: 400,
                    modal: true,
                    resizable: false,
                    buttons: {
                        "Confirm": function() {
                            document.workorderform.submit();
                        },
                        "Cancel": function() {
                            $(this).dialog("close");
                        }
                    }
                });
				
	$('form#workorderform').submit(function(e){
        e.preventDefault();
		var startdate = $("#fromdate").val() + ' ' + $("#fromtime").val();
		var enddate = $("#todate").val() + ' ' + $("#totime").val();

		var cfd = Date.parse(startdate);
		var ctd = Date.parse(enddate);

		var date1 = new Date(cfd); 
		var date2 = new Date(ctd);

		if(date1 > date2) { 
			alert("FROM("+startdate+") time should be less than/equal to TO("+enddate+") time...");
			return false;
		}
		else
		{
			
			var iq = document.getElementById('InQty').value;
			var oq = document.getElementById('OutQty').value;
			
			if(oq > iq)
			{
				opqty.innerHTML = oq.fontcolor("red");	
			}
			else
			{
				opqty.innerHTML = oq;
			}
			wocode.innerHTML = document.getElementById("workordercode").value;
			wocomponent.innerHTML = document.getElementById("workorderitem").value;
			process.innerHTML = document.getElementById("workorderpro").value;
			
			var promacid = document.getElementById('macid').value;
			if(promacid > 0)
			{
				var pemachine = document.getElementById('machine');
				var machinetext = pemachine.options[pemachine.selectedIndex].innerHTML;
			}
			else
			{
				machinetext = "Not Required";
			}
			womachine.innerHTML = machinetext;
			
			rejqty.innerHTML = document.getElementById('RejQty').value;
			ipqty.innerHTML = iq;

			var empobj = $("#ddEmployee option:selected");
			var selemptext = "";
			empobj.each(function () {
				selemptext += $(this).text() + ",";
			});
			emp.innerHTML = selemptext;
			//prodhr.innerHTML = $("#proddate").val() + " & " +$("#fromhour").val()+":"+$("#fromminute").val() + " - " +$("#tohour").val()+":"+$("#tominute").val();
			prodhr.innerHTML = startdate+ " to " +enddate;

			var selTemperature = "";
			$('input[name="Temperature[]"]').each(function()
			{
				selTemperature += $(this).val() + "; ";
			});
			wotemperature.innerHTML = selTemperature;
			
			var selPressure = "";
			$('input[name="Pressure[]"]').each(function()
			{
				selPressure += $(this).val() + "; ";
			});
			wopressure.innerHTML = selPressure;

			var selWeight = "";
			$('input[name="Weight[]"]').each(function()
			{
				selWeight += $(this).val() + "; ";
			});
			woweight.innerHTML = selWeight;

			var selTime = "";
			$('input[name="Time[]"]').each(function()
			{
				selTime += $(this).val() + "; ";
			});
			wotime.innerHTML = selTime;

			var selDensity = "";
			$('input[name="Density[]"]').each(function()
			{
				selDensity += $(this).val() + "; ";
			});
			wodensity.innerHTML = selDensity;

			var selHardness = "";
			$('input[name="Hardness[]"]').each(function()
			{
				selHardness += $(this).val() + "; ";
			});
			wohardness.innerHTML = selHardness;
		}
		$('#PEPopup').dialog('open');
	});


			});

function clearDateElement(ele,n)
{
	var inputeles = document.getElementsByTagName("input");
	for(var i=0;i<inputeles.length;i++)
	{
		if(inputeles[i].type == "text" && inputeles[i] != ele  && inputeles[i] != n)
		{
			inputeles[i].value = "";
		}
	}
}
</script>
<div class="main-container">
<?php include('includes/header.php');

if($_REQUEST['t'] == 1)
{
	$breadcrum = "Production Entry";
}

if($_REQUEST['t'] == 2)
{
	$breadcrum = "Take Ownership";
}
$p = $_REQUEST['p'];

$getMachineCnt = mysql_fetch_array(mysql_query("SELECT COUNT(DISTINCT tss.MachineID) MachineCnt FROM ".APP."txnmetadatastage ms JOIN ".APP."txnworkordersetting tss ON tss.WorkOrderID = ms.WorkOrderID AND tss.StageID = ms.StageID WHERE ms.ID = ".$p)) or die(mysql_error());

//echo $getMachineCnt['MachineCnt'];

$getData = "SELECT ms.ID, ms.ProductID, ms.WorkOrderID, ms.WorkflowID, ms.StageID, ms.MachineID, ms.Sequence, IF(ms.PendingQuantity = 0, ms.InputQuantity, ms.PendingQuantity) InputQuantity, wo.Code, p.ProductName, wf.WorkflowName, s.StageName, IF(m.MachineName IS NULL, 'Not Required', m.MachineName) MachineName, ms.Sequence, (SELECT COUNT(1) Cnt FROM ".APP."txnworkordersetting wos WHERE wos.WorkOrderID = ms.WorkOrderID AND wos.WorkflowID = ms.WorkflowID AND wos.StageID = ms.StageID AND wos.MachineID IS NOT NULL) MachineFlag FROM ".APP."txnmetadatastage ms JOIN ".APP."txnworkorder wo ON wo.ID = ms.WorkOrderID JOIN ".APP."mstrproduct p ON p.ID = ms.ProductID JOIN ".APP."luworkflow wf ON wf.ID = ms.WorkflowID JOIN ".APP."lustage s ON s.ID = ms.StageID LEFT OUTER JOIN ".APP."lumachine m ON m.ID = ms.MachineID WHERE ms.ID = ".$p;
//echo $getData;
$getrs = mysql_fetch_array(mysql_query($getData)) or die(mysql_error());
//print_r($getrs);
?>

<div class="bread-crums_wrap">
<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Production</a>&nbsp;&raquo;&nbsp;<?php echo $breadcrum; ?></div>
<div class="backlink"><a href="vwMyTask.php"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>
</div>
</div>
<div class="clear"></div>
<!-- Bread-Crumb Ends -->
<!-- Middle-Container Starts -->
<div class="middle-container">
<div id="dashlet-panel" class="dashlet-panel-full">
<div id="PEPopup" style="width:700px;height:150px;">
<h4>Production Entry Summary</h4>
<p>Work Order Code : <span id="wocode"></span></p>
<p>Component : <span id="wocomponent"></span></p>
<p>Process : <span id="process"></span>;&nbsp;Machine : <span id="womachine"></span></p>
<p>Input Quantity : <span id="ipqty"></span>;&nbsp;Output Quantity : <span id="opqty"></span></p>
<p>Rejected Quantity : <span id="rejqty"></span></p>
<p>Temperature : <span id="wotemperature"></span></p>
<p>Pressure : <span id="wopressure"></span></p>
<p>Weight : <span id="woweight"></span></p>
<p>Time : <span id="wotime"></span></p>
<p>Density : <span id="wodensity"></span></p>
<p>Hardness : <span id="wohardness"></span></p>
<p>Employee(s) : <span id="emp"></span></p>
<p>Prod. Date & Hour : <span id="prodhr"></span></p>
</div>
<form name="workorderform" action="mdlMyTask.php?mode=pe" method="post" id="workorderform" onSubmit="return btnSubmit();">
<input type="hidden" id="mdstgid" name="mdstgid" value="<?php echo $p; ?>"/>
<input type="hidden" id="seq" name="seq" value="<?php echo $getrs['Sequence']; ?>"/>
<input type="hidden" id="woid" name="woid" value="<?php echo $getrs['WorkOrderID']; ?>"/>
<input type="hidden" id="macid" name="macid" value="<?php echo $getrs['MachineFlag']; ?>"/>
<input type="hidden" id="workordercode" name="workordercode" value="<?php echo $getrs['Code']; ?>"/>
<input type="hidden" id="workorderitem" name="workorderitem" value="<?php echo $getrs['ProductName']; ?>"/>
<input type="hidden" id="workorderpro" name="workorderpro" value="<?php echo $getrs['StageName']; ?>"/>
<table width="100%" border="0" id="workflowtable">
<tr>
<td>Work Order Code</td>
<td><?php echo $getrs['Code']; ?></td>
<td>Product/Component</td>
<td><?php echo $getrs['ProductName']; ?></td>
<td>Process</td>
<td><?php echo $getrs['StageName']; ?></td>
<td>Machine<span class="validationerrornotify">*</span></td>
<td>
<?php
if($getMachineCnt['MachineCnt'] >= 1)
{
	$getMachineListQry = "SELECT DISTINCT tss.MachineID, m.MachineName FROM ".APP."txnmetadatastage ms JOIN ".APP."txnworkordersetting tss ON tss.WorkOrderID = ms.WorkOrderID AND tss.StageID = ms.StageID JOIN ".APP."lumachine m ON m.ID = tss.MachineID WHERE ms.ID = ".$p;
	$getMachineListExe = mysql_query($getMachineListQry) or die(mysql_error());
?>
<select id="machine" name="machine" onChange="getSetting()" required >
<option value="">--Select--</option>
<?php
	while($getMachineListRS = mysql_fetch_array($getMachineListExe))
	{
?>
<option value="<?php echo $getMachineListRS['MachineID']; ?>" <?php if($_REQUEST['mid'] == $getMachineListRS['MachineID']) {?> selected <?php } ?> ><?php echo $getMachineListRS['MachineName']; ?></option>
<?php
	}
?>
</select>
<?php
$machineid = $_REQUEST['mid'];
}
else
{
	echo $getrs['MachineName'];
	$machineid = $getrs['MachineID'];
}
?>
</td>
</tr>
<tr>
<td>Expected Quantity</td>
<td><?php echo $getrs['InputQuantity']; ?><input type="hidden" id="InQty" name="InQty" value="<?php echo $getrs['InputQuantity']; ?>" /></td>
<td>Output Quantity<span class="validationerrornotify">*</span></td>
<td><input type="number" id="OutQty" min="0" style="width:60px;" name="OutQty" size="5" required onChange="getPendingQty()" onkeypress="return isNumberKey(event)"/></td>
<td>Rejected Quantity</td>
<td><input type="number" id="RejQty" min="0" style="width:60px;" name="RejQty" size="5" onChange="getPendingQty()" onkeypress="return isNumberKey(event)"/>
<span id="rollbacktodiv"></span>
</td>
<td>Pending Quantity</td>
<td><input type="text" id="PenQty" name="PenQty" size="5" readonly /></td>
</tr>

<?php

//if($getrs['Sequence'] != 1)
//{
?>
	<!--<tr <?php if($getrs['Sequence'] == 1) { ?> style="display:none;" <?php } ?> >-->
	<tr>
	<td>Reprocess Quantity</td>
	<td><input type="number" min="0" style="width:60px;" id="RepQty" name="RepQty" size="5" onChange="getPendingQty()" onkeypress="return isNumberKey(event)" />
	<td colspan="6">
		<select id="rollback" name="rollback">
		<option selected="selected" value="">--Select--</option>
		<?php
		$stdQry = "SELECT msa.ID MetaStageID, msa.Sequence, s.StageName FROM ".APP."txnmetadatastage ms JOIN ".APP."txnmetadatastage msa ON msa.WorkOrderID = ms.WorkOrderID AND msa.Sequence <= ms.Sequence JOIN ".APP."lustage s ON s.ID = msa.StageID WHERE ms.ID = ".$getrs['ID']." AND ms.WorkOrderID = ".$getrs['WorkOrderID'];
		$stdExe = mysql_query($stdQry) or die(mysql_error());
		while($stdRS = mysql_fetch_array($stdExe))
		{
		?>
		<option value="<?php echo $stdRS['MetaStageID']; ?>"><?php echo $stdRS['StageName']; ?></option>
		<?php
		}
		?>
		</select>
	</td>
	</tr>
<?php	
//}
?>

	<tr>
	<td>Quantity to skip</td>
	<td><input type="number" min="0" style="width:60px;" id="SkipQty" name="SkipQty" size="5" onChange="getPendingQty()" onkeypress="return isNumberKey(event)"/>
	<td colspan="6">
		<select id="skipto" name="skipto">
		<option selected="selected" value="">--Select--</option>
		<?php
		$skipQry = "SELECT msa.ID MetaStageID, msa.Sequence, s.StageName FROM ".APP."txnmetadatastage ms JOIN ".APP."txnmetadatastage msa ON msa.WorkOrderID = ms.WorkOrderID AND msa.Sequence > (ms.Sequence + 1) JOIN ".APP."lustage s ON s.ID = msa.StageID WHERE ms.ID = ".$getrs['ID']." AND ms.WorkOrderID = ".$getrs['WorkOrderID'];
		$skipExe = mysql_query($skipQry) or die(mysql_error());
		while($skipRS = mysql_fetch_array($skipExe))
		{
		?>
		<option value="<?php echo $skipRS['MetaStageID']; ?>"><?php echo $skipRS['StageName']; ?></option>
		<?php
		}
		?>
		</select>
	</td>
	</tr>

<?php
if($machineid)
{
	$getAttributeQry = "SELECT wos.AttributeID, a.Description Attribute, COUNT(1) Cnt FROM ".APP."txnmetadatastage ms JOIN ".APP."txnworkordersetting wos ON wos.WorkOrderID = ms.WorkOrderID AND wos.StageID = ms.StageID JOIN ".APP."luattribute a ON a.ID = wos.AttributeID WHERE ms.ID = ".$p." AND wos.MachineID = ".$machineid." GROUP BY wos.AttributeID, a.Description";
	$getAttributeExe = mysql_query($getAttributeQry) or die(mysql_error());
}
//echo $getAttributeQry;



if($getAttributeExe)
{
	?>
	<tr>
	<td style="width:100%;text-align:center;" colspan="8">Setting(s)</td>
	</tr>
	<?php
	while($getAttributers = mysql_fetch_array($getAttributeExe))
	{
	?>
	<tr>
	<td colspan="2"><?php echo $getAttributers['Attribute']; ?><span class="validationerrornotify">*</span></td>
	<td colspan="6">
	<?php
	for($a = 0;$a < $getAttributers['Cnt'];$a++)
	{
	?>
		<input type="text" name="<?php echo $getAttributers['Attribute']; ?>[]" id="<?php echo $getAttributers['Attribute'];?>" size="5" required />
	<?php
	}
	?>
	</td>
	</tr>
	<?php

	}	
}
?>
<tr>
<td>Operator(s)<span class="validationerrornotify">*</span></td>
<td colspan="7">
<?php
	$empList = "SELECT ID, Name FROM ".APP."mstremployee WHERE IsActive = 1";
	$empListExe = mysql_query($empList) or die(mysql_error());
	?>
	<select id="ddEmployee" name="ddEmployee[]" multiple="multiple"  class="required" required >
	<?php

	while($emprs = mysql_fetch_array($empListExe))
	{
	?>
	<!--<option value="1"<?php echo ( in_array( '1' , $serve ) ? 'selected="selected"' : '' ); ?> ><?php echo $emprs['Name']; ?></option>-->
	<option value="<?php echo $emprs['ID']; ?>"><?php echo $emprs['Name']; ?></option>
	<?php
	}
	?>
	</select>
</td>
<tr>
<td>Production Hour<span class="validationerrornotify">*</span></td>
<td colspan="7">
<div id="div1" style="display:block;">
            
			<input type="text" name="fromdate" class="kpress" style="width:100px;" id="fromdate" required placeholder="From Date" />&nbsp;<input type="time" name="fromtime" id="fromtime" required />&nbsp;-&nbsp;<input type="text" name="todate" class="kpress" style="width:100px;" id="todate" required placeholder="To Date" />&nbsp;<input type="time" name="totime" id="totime" required />
			<?php
			$hr = mysql_query("SELECT Value FROM ".APP."luhour ORDER BY Value ASC") or die(mysql_error());
			$min = mysql_query("SELECT Value FROM ".APP."luminute ORDER BY Value ASC") or die(mysql_error());
			?>
			<!--From&nbsp;<select id="fromhour" name="fromhour" required onChange="getToHour()">
			<option value="">--HH--</option>
			<?php
			while($hrs = mysql_fetch_array($hr))
			{
			?>
			<option value="<?php echo $hrs['Value']; ?>"><?php echo $hrs['Value']; ?></option>
			<?php
			}
			?>
			</select>
			<select id="fromminute" name="fromminute" required onChange="getToMinute()">
			<option value="">--MM--</option>
			<?php
			while($mrs = mysql_fetch_array($min))
			{
			?>
			<option value="<?php echo $mrs['Value']; ?>"><?php echo $mrs['Value']; ?></option>
			<?php
			}
			$min = mysql_query("SELECT Value FROM luminute ORDER BY Value ASC");
			?>
			</select>
			To&nbsp;<select id="tohour" name="tohour" required >
			<option value="">--HH--</option>
			</select>
			<select id="tominute" name="tominute" required >
			<option value="">--MM--</option>
			</select>-->
            <!--From&nbsp;<input type="text" name="fromhour" placeholder="HH"  id="fromhour" size="1" required />:<input type="text" name="fromminute" placeholder="MM" id="fromminute" size="1" required />
			To&nbsp;<input type="text" name="tohour" placeholder="HH"  id="tohour" size="1" required />:<input type="text" name="tominute" placeholder="MM" id="tominute" size="1" required />&nbsp;(time should be in 24 Hour format)-->
<!--            <input type="text" name="endtime" style="width:100px;" class="kpress" value=""  id="endtime" />-->
          </div>
</td>
</tr>
<tr>
<td>&nbsp;</td>
<td colspan="7">
<input type="submit" class="stage" name="prodEntry" value="Submit" id="prodEntry" />

<!--<input type="button" value="Test" onclick="testcall()" />-->
&nbsp;<input name="Cancel" type="button"  value="Cancel"/>
</td>
</tr>
</table>


</form>

</div>
</div>
<?php include('includes/footer.php'); ?>
</div>
</body>
</html>