<?php
include('meta_script_link.php');?>
<div class="main-container">
	<?php include('includes/header.php');?>
<!-- Bread-Crumb Starts -->
<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Machine</div>
	<div class="msg_wrap">
    <?php 
   if($_SESSION['prcmsg'] == 'dones')
        {?>
        <div class="msg_success">
           Machine Created Successfully !!
        </div>
	<?php }	
        if($_SESSION['prcmsg'] == 'donef')
        {?>
        <div class="msg_error">
            Machine Creation Failed !!
        </div>
       	<?php }
		if($_SESSION['prcmsg'] == 'upds')
        {?>
        <div class="msg_success">
           Machine Updated Successfully !!
        </div>
		<?php }	
		if($_SESSION['prcmsg'] == 'ds')
        {?>
        <div class="msg_success">
           Machine deleted Successfully !!
        </div>
        <?php } ?>
        </div>
    
    <div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>

<div class="clear"></div>
<!-- Bread-Crumb Ends -->
        <div class="dashlet-panel-full">

                <div class="backlink">            
                    <a href="ctrlMachine.php?mode=add"><img src="images/new.png" title="Add Machine" border="0" />&nbsp;New Machine</a>
                </div> 
        <div class="clear"></div>
   			<div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; left: 0px; top: 0px;">				
					<div class="ui-widget-header ui-corner-top">
						<h2 class="arial12-nrml-medium-dark-gry">Machine</h2>						
					</div>	
						 <!--<form name="listUser" action="" method="post" >	-->						
							<table cellspacing="0" cellpadding="0" border="0" width="100%" class="display" id="example">
								<thead>
									<tr>
										<th>Code</th>
                                        <th>Machine</th>
                                        <th>Description</th>
										<th>Active</th>
										<th>Action</th>															
									</tr>
								</thead>                                                    
								<tbody>
								<?php
								$i = 1;
								$getMachineList = mysql_query("SELECT ID, Code, MachineName, Description, if(IsActive = 1, 'Yes', 'No') as active from ".APP."lumachine order by MachineName");							
								while($rs = mysql_fetch_array($getMachineList)){
									?>
									<tr>
										<td align="center" width="10%"><?php echo $rs['Code']; ?></td>
                                        <td width="20%"><?php echo $rs['MachineName']; ?></td>
                                        <td align="center" width="40%"><?php echo $rs['Description']; ?></td>
                                        <td align="center" width="10%"><?php echo $rs['active']; ?></td>
										<td style="font-weight:bold" align="center" width="10%">
                                        
										<a href="ctrlMachine.php?mode=edit&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a> &nbsp; 
                                        
  										<!--<a href="ctrlMachine.php?mode=view&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/view.png" title="View" border="0" /> </a>--> &nbsp;

                                        <a onclick="javascript:if(confirm('Are you sure you want to delete?')){return true;}return false;" href="mdlMachine.php?mode=del&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/del.png" title="Delete" border="0" /> </a>
										</td>															
									</tr>									
								<?php $i++; } ?>								
								</tbody>
							</table>
												
			</div>
   </div>
   
   <!-- Dashlet-Panel Ends -->	
   <?php include('footer.php'); ?> 
</div>