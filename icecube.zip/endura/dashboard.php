<?php
include('meta_script_link.php');
include('site_meta_script_link.php');
?>
<head>
 <div class="main-container">
 	<?php 
	include('includes/header.php'); ?>
    <div class="bread-crums_wrap">
    <div class="bread-crums"><a href="#">Home</a> &raquo; Dashboard</div>
</div>
  <div class="msg_wrap">
	 <?php
	if($_REQUEST['result'] == 'success') {?>
    <div class="msg_success"> Password changed Successfully. </div>
    <?php } ?>
	</div>

        <div class="dashlet-panel-full">
        <div class="container_6">
		<!-- DUE TODAY -->
			<div draggable="true" id="widget-tickets" class="grid_3 portlet collapsible ui-widget ui-widget-content ui-corner-all">
			<header class="ui-widget-header ui-corner-top">
			<h2><b>Work order(s) due today</b></h2>
			<a role="button" class="portlet-collapse ui-corner-all" href="#"><span class="ui-icon ui-icon-circle-minus">Expand/Collapse</span></a></header>
			<section class="no-padding">
				<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="" class="display">
					<thead>
						<tr>
						<th width="30%">WO Code</th>
						<th width="30%"># of piece(s)</th>
						<th width="30%">Due Date</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$duetodayQry = "SELECT DATE_FORMAT(wo.DueDate, '%d-%b-%Y') DueDate, m.WorkOrderID, wo.Code, (wo.Quantity * wo.Pieces) Pieces, SUM(CASE m.StatusID WHEN 1 THEN m.Quantity END) YetToMix, SUM(CASE m.StatusID WHEN 2 THEN m.Quantity END) InProgress FROM ".APP."txnworkorder wo JOIN ".APP."txnmetadata m ON m.WorkOrderID = wo.ID WHERE wo.IsCompleted = 0 AND wo.DueDate = DATE(NOW()) GROUP BY wo.ID, wo.DueDate ORDER BY wo.DueDate ASC";
					//echo $duetodayQry;
					$duetodayExe = mysql_query($duetodayQry) or die(mysql_error());
					while($dtRS = mysql_fetch_array($duetodayExe))
					{
					?>
						<tr>
						<td><?php echo $dtRS['Code']; ?></td>
						<td><?php echo $dtRS['Pieces']; ?></td>
						<td><?php echo $dtRS['DueDate']; ?></td>
						</tr>
					<?php
					}
					?>
					</tbody>
				</table>
			</section>
			</div>
			<!-- OVER DUE -->
			<div draggable="true" id="widget-tickets" class="grid_3 portlet collapsible ui-widget ui-widget-content ui-corner-all">
			<header class="ui-widget-header ui-corner-top">
			<h2><b>Work order(s) over due</b></h2>
			<a role="button" class="portlet-collapse ui-corner-all" href="#"><span class="ui-icon ui-icon-circle-minus">Expand/Collapse</span></a></header>
			<section class="no-padding">
				<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="" class="display">
					<thead>
						<tr>
						<th>WO Code</th>
						<th># of piece(s)</th>
						<th>Due Date</th>
						<th># of day(s) due</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$duetodayQry = "SELECT DATEDIFF(NOW(), DueDate) DueDays, DATE_FORMAT(wo.DueDate, '%d-%b-%Y') DueDate, m.WorkOrderID, wo.Code, (wo.Quantity * wo.Pieces) Pieces, SUM(CASE m.StatusID WHEN 1 THEN m.Quantity END) YetToMix, SUM(CASE m.StatusID WHEN 2 THEN m.Quantity END) InProgress FROM ".APP."txnworkorder wo JOIN ".APP."txnmetadata m ON m.WorkOrderID = wo.ID WHERE wo.StatusID <> ".COMPLETED." AND DATEDIFF(NOW(), wo.DueDate) > 0 GROUP BY wo.ID, wo.DueDate ORDER BY wo.DueDate ASC";
					//echo $duetodayQry;
					$duetodayExe = mysql_query($duetodayQry) or die(mysql_error());
					while($dtRS = mysql_fetch_array($duetodayExe))
					{
					?>
						<tr>
						<td><?php echo $dtRS['Code']; ?></td>
						<td><?php echo $dtRS['Pieces']; ?></td>
						<td><?php echo $dtRS['DueDate']; ?></td>
						<td><?php echo $dtRS['DueDays']; ?></td>
						</tr>
					<?php
					}
					?>
					</tbody>
				</table>
			</section>
			</div>
			<!--
			<div draggable="true" id="widget-tickets" class="grid_3 portlet collapsible ui-widget ui-widget-content ui-corner-all">
			<header class="ui-widget-header ui-corner-top">
			<h2><b>Work order(s) over due</b></h2>
			<a role="button" class="portlet-collapse ui-corner-all" href="#"><span class="ui-icon ui-icon-circle-minus">Expand/Collapse</span></a></header>
			<section class="no-padding">
				<table width="100%" border="0" cellspacing="0" cellpadding="0" summary="" class="display">
					<thead>
						<tr>
						<th width="40%">Article Title</th>
						<th width="25%">Status</th>
						<th width="15%">Action</th>
						<th width="15%">Flag</th>
						</tr>
					</thead>
					<tbody>
						<tr style="font:Verdana, Geneva, sans-serif; color: #F60;">
						<td>Article</td>
						<td>Status</td>
						<td>Action</td>
						<td>Flag</td>
						</tr>
					</tbody>
				</table>
			</section>
			</div>

			</div>-->
		
		
</div>
	<input type="hidden" value="<?echo $isExpired ?>" id="isExpired"/>
<?php include('footer.php'); ?>  
</div>