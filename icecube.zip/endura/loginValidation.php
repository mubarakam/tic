<?php
session_start();
include("config.php");
include("includes/classes/loginClass.php");
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$login = new LoginClass();
$login->userAuthentic($username, $password, $rememberMe);
?>