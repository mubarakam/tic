<?php
ob_start();
error_reporting(0);
include("erpConstant.php");
//Connection 2

$hostname = "MYSQL5014.HostBuddy.com";	//Host name of the Server
$username = "9f4da2_mes";	//User Name of the Server
$password = "Bismillah";	//Password of the Server
$dbname = "db_9f4da2_mes";	//Database Name of the server

//Connection 3
/*
$hostname = "localhost";	//Host name of the Server
$username = "root";	//User Name of the Server
$password = "";	//Password of the Server
$dbname = "erplive";	//Database Name of the server
*/
$connect = mysql_connect("$hostname", "$username", "$password") or die("Unable to connect to Database server");
@mysql_select_db($dbname, $connect) or die("Unable to select database");
$mysqli = new mysqli("$hostname", "$username", "$password", $dbname);

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}
define('CURRENT_URL',curPageURL());
define('CURRENT_PAGE',basename(curPageURL()));
define('CURRENT_PAGE_ONLY',basename($_SERVER['SCRIPT_FILENAME'],".php"));

// 


 
?>