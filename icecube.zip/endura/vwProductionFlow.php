<?php
include('meta_script_link.php');?>
<div class="main-container">
	<?php include('includes/header.php');?>
<!-- Bread-Crumb Starts -->
<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="dashboard.php">Master</a>&nbsp;&raquo;&nbsp;Process Flow</div>
	<div class="msg_wrap">
    <?php 
   if($_SESSION['prcmsg'] == 'dones')
        {?>
        <div class="msg_success">
           Production Flow Created Successfully !!
        </div>
	<?php }	
        if($_SESSION['prcmsg'] == 'donef')
        {?>
        <div class="msg_error">
            Production Flow Creation Failed !!
        </div>
       	<?php }
		if($_SESSION['prcmsg'] == 'upds')
        {?>
        <div class="msg_success">
           Production Flow Updated Successfully !!
        </div>
		<?php }	
		if($_SESSION['prcmsg'] == 'ds')
        {?>
        <div class="msg_success">
           Production Flow deleted Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'ss')
        {?>
        <div class="msg_success">
           Setting updated Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'sf')
        {?>
        <div class="msg_success">
           Setting updation failed !!
        </div>
        <?php } ?>


        </div>
    
    <div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>

<div class="clear"></div>
<!-- Bread-Crumb Ends -->
        <div class="dashlet-panel-full">

                <div class="backlink">            
                    <a href="ctrlProductionFlow.php?mode=add"><img src="images/new.png" title="Add Process Flow" border="0" />&nbsp;New Process Flow</a>
                </div> 
        <div class="clear"></div>
   			<div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; left: 0px; top: 0px;">				
					<div class="ui-widget-header ui-corner-top">
						<h2 class="arial12-nrml-medium-dark-gry">Process Flow</h2>						
					</div>	
						 <!--<form name="listUser" action="" method="post" >	-->						
							<table cellspacing="0" cellpadding="0" border="0" width="100%" class="display" id="example">
								<thead>
									<tr>
										<th>Code</th>
                                        <th>Process Flow</th>
                                        <th>Description</th>
										<th>Active</th>
										<th>Action</th>															
									</tr>
								</thead>                                                    
								<tbody>
								<?php
								$i = 1;
								$getProductionFlowList = mysql_query("SELECT w.ID, w.Code, w.Description, w.WorkflowName WorkflowName, IF(w.IsActive = 1, 'Yes', 'No') AS active FROM ".APP."luworkflow w ORDER BY w.IsActive DESC, w.WorkflowName ASC");
								while($rs = mysql_fetch_array($getProductionFlowList)){
									?>
									<tr>
										<td align="center" width="10%"><?php echo $rs['Code']; ?></td>
                                        <td width="20%"><?php echo $rs['WorkflowName']; ?></td>
                                        <td align="center" width="40%"><?php echo $rs['Description']; ?></td>
                                        <td align="center" width="10%"><?php echo $rs['active']; ?></td>
										<td style="font-weight:bold" align="center" width="10%">
                                        
										<a href="ctrlProductionFlow.php?mode=edit&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a> &nbsp; 
										
                                        <!--<a href="ctrlProductionFlow.php?mode=set&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/settings.png" title="Setting" border="0" /></a> &nbsp; 
  										<!--<a href="ctrlProductionFlow.php?mode=view&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/view.png" title="View" border="0" /> </a> &nbsp;-->

                                        <a onclick="javascript:if(confirm('Are you sure you want to delete?')){return true;}return false;" href="mdlProductionFlow.php?mode=del&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/del.png" title="Delete" border="0" /> </a>
										</td>															
									</tr>									
								<?php $i++; } ?>								
								</tbody>
							</table>
												
			</div>
   </div>
   
   <!-- Dashlet-Panel Ends -->	
   <?php include('footer.php'); ?> 
</div>