<?php
include('meta_script_link.php');?>
<div class="main-container">
	<?php include('includes/header.php');?>
<!-- Bread-Crumb Starts -->
<div class="bread-crums_wrap">
	<div class="bread-crums"><a href="dashboard.php">Home</a>&nbsp;&raquo;&nbsp;<a href="#">HR</a>&nbsp;&raquo;&nbsp;Employee</div>
	<div class="msg_wrap">
    <?php 
   if($_REQUEST['code'])
        {?>
        <div class="msg_success">
           Employee Created Successfully !! (Employee Code - <?php echo $_REQUEST['code']; ?> & DOB is the password (YYYY-MM-DD))
        </div>
	<?php }	
        if($_REQUEST['v'] == '0')
        {
		?>
		<div class="msg_success">
           Employee updated successfully !!!
        </div>
		<?php
		//header("location: vwEmployee.php");
       	}
		if($_SESSION['prcmsg'] == 'upds')
        {?>
        <div class="msg_success">
           Product Updated Successfully !!
        </div>
		<?php }	
		if($_SESSION['prcmsg'] == 'ds')
        {?>
        <div class="msg_success">
           Product deleted Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'ss')
        {?>
        <div class="msg_success">
           Setting updated Successfully !!
        </div>
        <?php }
		if($_SESSION['prcmsg'] == 'sf')
        {?>
        <div class="msg_success">
           Setting updation failed !!
        </div>
        <?php } ?>


        </div>
    
    <div class="backlink">
	      <!--<a href="javascript: history.go(-1)"><img src="images/back-icon.png" title="Go Back" border="0" /> Back</a>-->
	</div>
</div>

<div class="clear"></div>
<!-- Bread-Crumb Ends -->
        <div class="dashlet-panel-full">

                <div class="backlink">            
                    <a href="ctrlEmployee.php?mode=add"><img src="images/new.png" title="Add Employee" border="0" />&nbsp;New Employee</a>
                </div> 
        <div class="clear"></div>
   			<div draggable="true" id="widget-tickets" class="portlet collapsible ui-widget-content ui-corner-all" style="position: relative; opacity: 1; left: 0px; top: 0px;">				
					<div class="ui-widget-header ui-corner-top">
						<h2 class="arial12-nrml-medium-dark-gry">Employee</h2>						
					</div>	
						 <!--<form name="listUser" action="" method="post" >	-->						
							<table cellspacing="0" cellpadding="0" border="0" width="100%" class="display" id="example">
								<thead>
									<tr>
										<th>Code</th>
                                        <th>Name</th>
										<th>Role</th>
										<th>Employment Type</th>
										<th>Contact #</th>
										<th>Active</th>
										<th>Action</th>															
									</tr>
								</thead>                                                    
								<tbody>
								<?php
								
								$employeeList = mysql_query("SELECT me.ID, me.RoleID, r.Description RoleName, me.EmployeeCode, me.Name, IF(me.IsActive = 1, 'Yes', 'No') Active, le.ContactNumber, let.Description EmploymentType FROM ".APP."mstremployee me JOIN ".APP."lurole r ON r.ID = me.RoleID JOIN ".APP."luemployeedetail le ON le.ID = me.ID JOIN ".APP."luemploymenttype let ON let.ID = le.EmploymentTypeID ORDER BY me.IsActive DESC, me.EmployeeCode ASC");
								while($rs = mysql_fetch_array($employeeList)){
									?>
									<tr>
										<td align="center" width="10%"><?php echo $rs['EmployeeCode']; ?></td>
                                        <td width="20%"><?php echo $rs['Name']; ?></td>
                                        <td width="20%"><?php echo $rs['RoleName']; ?></td>
										<td width="20%"><?php echo $rs['EmploymentType']; ?></td>
										<td width="20%"><?php echo $rs['ContactNumber']; ?></td>
										<td align="center" width="10%"><?php echo $rs['Active']; ?></td>
										<td style="font-weight:bold" align="center" width="10%">
										<a href="ctrlEmployee.php?mode=edit&eid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"><img src="images/edit.png" title="Edit" border="0" /></a> &nbsp; 
										<!--<a onclick="javascript:if(confirm('Are you sure you want to delete?')){return true;}return false;" href="mdlEmployee.php?mode=del&sid=<?php echo $rs['ID'];?>" style="color:#1190CB;font-weight:bold;"> <img src="images/del.png" title="Delete" border="0" /> </a>-->
										</td>															
									</tr>									
								<?php $i++; } ?>								
								</tbody>
							</table>
												
			</div>
   </div>
   
   <!-- Dashlet-Panel Ends -->	
   <?php include('footer.php'); ?> 
</div>