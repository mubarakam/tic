function addTemp(val)
{
	alert(val);
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addtemperature&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addPress(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addpressure&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addTime(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addtime&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addWeight(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addweight&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addDensity(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=adddensity&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function addHardness(val)
{
	/*alert(val);*/
	$(".example,#showBut").css('display','block');
	jQuery.ajax({type: "GET",url: "erpAjaxRequest.php?req=addhardness&stage="+val,async: false, dataType: "html",error: function(XMLHttpRequest, status, errorThrown) {},success: function (data, status) {/*alert(data);*/ jQuery('.example' +val+'> tbody').append( data ); $(function() {$(".select").chosen(); });},complete: function() {}});
}
function validate(a){
	var val = $("#"+a).val();
	$.ajax({type: "post",url: "ajaxValidate.php?frm="+a+"&val="+val,success: function(data)
	{
		if(data == "exist")
		{
			$("#"+a).css({'border': '1px dashed #FF3F3F',"background": "#FAEBE7"});
			document.getElementById('errdiv').style.display='inline';
			$("#addbtn").attr('disabled','true');
		}
		else if(data != "exist")
		{
			$("#"+a).css({'border': '1px solid #C1C1C1',"background": "#F7F7F7"});
			document.getElementById('errdiv').style.display='none';
			$("#addbtn").removeAttr('disabled');
		}
	}});
}
function btnSubmit()
{
	var fromhour = document.getElementById('fromhour').value;
	var fromminute = document.getElementById('fromminute').value;
	var tohour = document.getElementById('tohour').value;
	var tominute = document.getElementById('tominute').value;
	var starttime = fromhour+":"+fromminute;
	var endtime = tohour+":"+tominute;
	if(starttime > endtime)
	{
		alert("FROM("+starttime+") time should be less than/equal to TO("+endtime+") time...");
		return false;
	}
	else
	{
		return true;
	}
}
function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCodeif (charCode > 31 && (charCode < 48 || charCode > 57))return false;return true;
}