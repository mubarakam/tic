// HTML5 placeholder plugin version 0.3
// Enables cross-browser* html5 placeholder for inputs, by first testing
// for a native implementation before building one.
//
// USAGE: 
//$('input[placeholder]').placeholder();

(function ($) {
    $.fn.placeholder = function (options) {
        return this.each(function () {
            if (!("placeholder" in document.createElement(this.tagName.toLowerCase()))) {
                var $this = $(this), 
                placeholder = $this.attr('placeholder');
                $this.val(placeholder).data('color', $this.css('color')).css('color', '#aaa');
                $this
                .focus(function () {
                        if ($.trim($this.val()) === placeholder) {
                            $this.val('').css('color', $this.data('color'));
                        }
                    }) 
                .blur(function () {
                        if (!$.trim($this.val())) {
                            $this.val(placeholder).data('color', $this.css('color')).css('color', '#aaa');
                        }
                    });
                }
            });
        };
    }
    (jQuery)
);

var menuYloc = null;
var adminCookieExpiry = 365;
var sortableCookie = "sortable-order";
var sortableName = ".sortable";

// perform JavaScript after the document is scriptable.
$(document).ready(function () {
    
    /**
     * Setup superfish menu
     */
    if (typeof $("ul.sf-menu").superfish === 'function') {
        $("ul.sf-menu").supersubs({
                minWidth : 15, // minimum width of sub-menus in em units 
                maxWidth : 27, // maximum width of sub-menus in em units 
                extraWidth : 1// extra width can ensure lines don't sometimes turn over 
                // due to slight rounding differences and font-family 
            }).superfish(); // call supersubs first, then superfish, so that subs are 
        // not display:none when measuring. Call before initialising 
        // containing tabs for same reason.
    }
    
    if (typeof prettyPrint === 'function') {
        prettyPrint();
        $('.prettyprint').after('<div class="clear"></div>').hover(function () {
            if ($(this).css('width', 'auto').width() < $(this).parent().width()) {
                $(this).css('width', '100%');
            }
        }, function () {
        });
    }
    
    /**
     * Table Sorting, Row Selection and Pagination
     */

   
      var oTable =   $('.display').dataTable({
                "bJQueryUI" : true, 
				"aaSorting": [],
                "bPaginate": false,	
            });
   
	
	 $('.display2').dataTable({
                "bJQueryUI" : true, 
				"bFilter": true,
				"aaSorting": [],
               "bPaginate": false,	
            });
    
//	var oTable = $('.display').dataTable();
	//  var nNodes = oTable.fnGetNodes();
      
	//	jQuery('#check_all').click( function() {       
  // $('input', oTable.fnGetNodes()).each( function() {
	   
	//var chk = $('input', oTable.fnGetNodes()).attr('checked');  
    // if(chk == "checked")
	// {
//$('input', oTable.fnGetNodes()).attr('checked',true);
//$(this).closest("tr").css("background-color", this.checked ? "" : "");
	// }
	// else
	// {
	//$('input', oTable.fnGetNodes()).attr('checked',true);	
	//$(this).closest("tr").css("background-color", this.checked ? "#FFE9A4" : "");
 
	// }
	 
//} );
//return false; // to avoid refreshing the page
//} );	
  
  
    
 
   
    
    if ($(sortableName).sortable) {
        $(sortableName).sortable({
            cursor : 'move', 
            revert : 500, 
            opacity : 0.7, 
            appendTo : 'body', 
            handle : 'header', 
            items : '[draggable=true]', 
            placeholder : 'portlet-placeholder grid_2', 
            forcePlaceholderSize : true, 
            update : function (event, ui) {
                $.cookie && $.cookie(sortableCookie, $(this).sortable("toArray"), {
                        expires : adminCookieExpiry, 
                        path : "/"
                    });
            }
        }).disableSelection();
    }
    
    /**
     * restore the order of sortable widgets
     */
    $.cookie && restoreOrder(sortableName, sortableCookie);
    
    /**
     * restore saved background
     */
    $.cookie && $.cookie('background') && changeBackground($.cookie('background'));
    
    /**
     * restore saved css
     */
    $.cookie && $.cookie('css') && changeUicolor($.cookie("css"));
});

/**
 * Restores the sortable order from a cookie
 */
function restoreOrder(sortable, cookieName) {
    var list = $(sortable);
    if (!list) {
        return;
    }
    
    // fetch the saved cookie
    var cookie = $.cookie(cookieName);
    if (!cookie) {
        return;
    }
    
    // create array from cookie
    var IDs = cookie.split(","), 
    
    // fetch current order
    items = list.sortable("toArray"), 
    
    // create associative array from current order
    current = [];
    for (var v = 0; v < items.length; v++) {
        current[items[v]] = items[v];
    }
    
    for (var i = 0, n = IDs.length; i < n; i++) {
        // item id from saved order
        var itemID = IDs[i];
        
        if (itemID in current) {
            // select the item according to the saved order and reappend it to the list
            $(sortable).append($(sortable).children("#" + itemID));
        }
    }
}

function saveCollapsed(collapsed) {
    $.cookie && $.cookie('collapsedPortlets', collapsed, {
        expires : adminCookieExpiry, 
        path : "/"
    });
}

function changeBackground(newBackground) {
    $('body').removeClass($.cookie('background')).addClass(newBackground);
    $.cookie && $.cookie('background', newBackground, {
        expires : adminCookieExpiry, 
        path : "/"
    });
}

function changeUicolor(newcss) {
    $('link.uicolor').attr('href', newcss);
    $.cookie && $.cookie('css', newcss, {
        expires : adminCookieExpiry, 
        path : "/"
    });
}

/**
 * Custom jQuery Tools Overlay Effect, thanks to the great guys at flowplayer.org :)
 */
// create custom animation algorithm for jQuery called "drop" 
$.easing.drop = function (x, t, b, c, d) {
    return - c * (Math.sqrt(1 - (t /= d) * t) - 1) + b;
};


/**
 * Utility functions
 */
if (!Array.indexOf) {
    Array.prototype.indexOf = function (obj) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === obj) {
                return i;
            }
        }
        return - 1;
    };
}
Array.prototype.includes = function (value) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] === value) {
            return true;
        }
    }
    return false;
};
Array.prototype.remove = function (value) {
    var i = this.indexOf(value);
    if (i !== -1) {
        this.splice(i, 1);
    }
};
