// JavaScript Document
/* FIND AND REPLACE SCRIPTS */
function getCheckVal(type){
	var selector_checked = $("input[@name=case]:checked").length; 
	if(selector_checked == 0){
		alert("Please Select a Word !");
	}
  if(type == "-- Select --"){
	alert("Select a type !");  
  }
  var allVals = [];
     $("input[name=case]:checked").each(function() {
    var abv = $(this).val();
	var text =  $('#abb_ifr_ifr').contents().find('body').html();
	if(type == 'hypen'){
	rmVal = abv.replace('-', '');
	var regExp = new RegExp(abv,'g'); // g for global search
    text = text.replace(regExp, rmVal); //iteration 1
	
	rmVal1 = rmVal.replace(' ', '');
	var regExp1 = new RegExp(rmVal,'g'); // g for global search
    text = text.replace(regExp1, rmVal1); //iteration 2
	
	rmVal2 = rmVal1.replace(' ', '');
	var regExp2 = new RegExp(rmVal1,'g'); // g for global search
    text = text.replace(regExp2, rmVal2); //iteration 3
	 // allVals.push($(this).val());
	 	$("#msg").css('display','block');
		$("#msg").html('Hyphens Removed Successfully...');
	}
	else if(type == 'space'){
	rmVal = abv.replace(' ', '');
	var regExp = new RegExp(abv,'g'); // g for global search
    text = text.replace(regExp, rmVal); //iteration 1
	
	rmVal1 = rmVal.replace(' ', '');
	var regExp1 = new RegExp(rmVal,'g'); // g for global search
    text = text.replace(regExp1, rmVal1); //iteration 2
	$("#msg").css('display','block');
	$("#msg").html('Spaces Removed Successfully...');
	}
	$('#abb_ifr_ifr').contents().find('body').html(text);
	 });
}
function rmvThis(id){
	$("#rw_"+id).remove();
}
