$(document).ready(function(){
$('body').contents().find("div[tagname='FOOTREF'] > sup").click(function() {
  getId = $(this).parent("div[tagname='FOOTREF']").attr('id');	
   $('html,body').animate({
			  scrollTop: $("div[tagname='note'][id="+getId+"]").offset().top
	  });
  });	
});