function tabs(tabin){ 
  if(tabin == 'home'){ 
     document.getElementById('home').className = 'nav-link-active';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'block';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
	 
  }
  else if(tabin == 'journal'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link-active';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'block';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'article'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link-active';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'block';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'book'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link-active';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'block';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'collaborat'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link-active';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'block';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'message'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link-active';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'block';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'archives'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link-active';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'block';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'setting'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link-active';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'block';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'help'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link-active';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link1';
	 
	 document.getElementById('my_sub_network').style.display = 'none';
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'block';
	 document.getElementById('buy_sub_active').style.display = 'none';
  }
  else if(tabin == 'buy'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link-active';
	 document.getElementById('network').className = 'nav-link1';
	 
	 
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('my_sub_network').style.display = 'none';

	 document.getElementById('buy_sub_active').style.display = 'block';
  }
   else if(tabin == 'network'){ //alert(tabin);
     document.getElementById('home').className = 'nav-link1';
	 document.getElementById('journal').className = 'nav-link1';
	 document.getElementById('article').className = 'nav-link1';
	 document.getElementById('book').className = 'nav-link1';
	 document.getElementById('collaborat').className = 'nav-link1';
	 document.getElementById('message').className = 'nav-link1';
	 document.getElementById('archives').className = 'nav-link1';
	 document.getElementById('setting').className = 'nav-link1';
	 document.getElementById('help').className = 'nav-link1';
	 document.getElementById('buy').className = 'nav-link1';
	 document.getElementById('network').className = 'nav-link-active';
	 
	 document.getElementById('home_sub_active').style.display = 'none';
	 document.getElementById('journal_sub_active').style.display = 'none';
	 document.getElementById('article_sub_active').style.display = 'none';
	 document.getElementById('book_sub_active').style.display = 'none';
	 document.getElementById('collaborat_sub_active').style.display = 'none';
	 document.getElementById('message_sub_active').style.display = 'none';
	 document.getElementById('archives_sub_active').style.display = 'none';
	 document.getElementById('setting_sub_active').style.display = 'none';
	 document.getElementById('help_sub_active').style.display = 'none';
	 document.getElementById('buy_sub_active').style.display = 'none';
	  document.getElementById('my_sub_network').style.display = 'block';
  }
}