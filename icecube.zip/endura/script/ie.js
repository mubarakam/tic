$(function() {
    $('table').attr('cellpadding', 0).attr('cellspacing', 0).attr('border', 0);
});