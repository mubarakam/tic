<?php session_start();
ob_start();
include("config.php");
include("includes/classes/erpClass.php");
echo "<pre>";
print_r($_REQUEST);
print_r($_SESSION);
$bottleCount = COUNT($_REQUEST['bottle']);
$bottle = $_REQUEST['bottle'];
$productid = $_REQUEST['productid'];
$workorderid = $_REQUEST['workorderid'];
$erpClass = new erpClass();
//$erpClass->moveToProduction($productid, $workorderid, $bottle);
$erpClass->moveToProduction($productid, $workorderid, $bottle);
/*	for($b = 0;$b < $bottleCount;$b++)
	{
		echo "UPDATE txnmetadata SET LastModBy = ".$userid.", LastModOn = NOW(), StageID = NULL, StatusID = ".OPEN." WHERE ID = ".$bottle[$b];
		echo "<br/>";
		mysql_query("UPDATE txnmetadata SET LastModBy = ".$userid.", LastModOn = NOW(), StageID = NULL, StatusID = ".OPEN." WHERE ID = ".$bottle[$b]);
	}
	header('location:vwMixing.php');
}
else
{
	header('location:ctrlMixing.php?mode=edit&woid='.$workorderid);
}*/

?>