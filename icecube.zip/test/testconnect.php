<?php
//$db = new PDO('mysql:host=localhost;dbname=myapp;', 'root', '');
$db = new PDO('mysql:host=localhost;dbname=crescentems;', 'crescentadmin', 'crescentadmin');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
$stmt = $db->query('SELECT * FROM cfgapplication');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($results);
} catch(PDOException $ex) {
	echo "catch...". $ex->getMessage();
}

echo "<br/><br/><br/>";

//create function with an exception
function checkNum($number) {
  if($number>1) {
    throw new Exception("Value must be 1 or below");
  }
  return true;
}

//trigger exception in a "try" block
try {
  checkNum(-1);
  //If the exception is thrown, this text will not be shown
  echo 'If you see this, the number is 1 or below';
}

//catch exception
catch(Exception $e) {
  echo 'Message: ' .$e->getMessage();
}

?>