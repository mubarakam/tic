<?php
//phpinfo();
$amount = '100000.919098';
setlocale(LC_MONETARY, 'en_IN');
$amount = money_format('%i', $amount);
echo $amount;
?>